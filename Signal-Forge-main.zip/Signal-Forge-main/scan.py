#!/usr/bin/env python3
"""
scan.py — the market scan and the prediction brief for Liquid XYZ100.

WHAT THIS ACTUALLY DOES
-----------------------
It does not forecast price. Nothing can, and any tool that claims to is selling
something. What it does is turn the standing rulebook into arithmetic you can run
BEFORE the open, so that 16:45 EAT is a lookup instead of an opinion:

  1. REGIME SCAN      advisory risk-on / neutral / risk-off for tech, with every
                      contributor shown. Never an entry trigger (that is Quiver's
                      role, and even Quiver is advisory only).
  2. ZONE MAP         distance in pts and % to every level in config/levels.yaml.
  3. BASIS CHECK      the ~0.7% XYZ100-vs-NQ discount and the implied futures equivalent.
  4. SWING PROJECTION what the daily close must do, how far that is, what it costs
                      in funding, and WHICH daily close is even meant (ambiguous).
  5. FEASIBILITY BAND for every legal range width: the fee drag in R, the net R,
                      the break-even win rate and the max size for the $40 budget.
                      This is the single most useful table in the kit.
  6. SCENARIOS        pre-computed LONG / SHORT / NO-BREAK tickets for a given range,
                      so the gate call is instant.
  7. PREDICTION BRIEF conditional statements with their falsifiers, plus an explicit
                      list of what the scan cannot tell you.

Usage
-----
  python3 scan.py                      # scan from config/state.yaml
  python3 scan.py --at 16:20           # pin the EAT clock
  python3 scan.py --live               # fetch via liquid_feed.py first, then scan
  python3 scan.py --last 31020 --funding 0.0006 --oi 269700000 --nq -0.57 --ten-year 5.28
  python3 scan.py --range-high 31052 --range-low 30988      # project both break scenarios
  python3 scan.py --brief              # prediction brief only

Exit codes: 0 ok, 3 inputs too incomplete to scan, 1 error.

Educational tooling only — not financial advice. Leveraged perpetuals can liquidate fast.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from datetime import datetime, timedelta

from opslib import (
    EAT, OpsConfig, fee_filter_feasibility, hr, liq_price, max_notional_for_risk,
    min_r_for_fee_filter, money, price, pts, session_clock, taker_fees_round_trip,
    units,
)

HERE = os.path.dirname(os.path.abspath(__file__))
EXIT_OK, EXIT_ERROR, EXIT_INCOMPLETE = 0, 1, 3

# Venue daily-candle roll. Hyperliquid 1d candles are aligned to UTC midnight,
# which is 03:00 EAT — six hours AFTER the playbook's 23:00 flat deadline.
# Whether "DAILY CLOSE" means that, or the 23:00 EAT US cash close, is unresolved.
VENUE_DAILY_CLOSE_EAT = "03:00"
US_CASH_CLOSE_EAT = "23:00"


# --------------------------------------------------------------------------
# Fee arithmetic in R — closed form, size-invariant
# --------------------------------------------------------------------------
def fee_drag_r(entry: float, stop_pts: float, taker_pct: float = 0.09) -> float:
    """How much of an R the round-trip taker fee costs, independent of size.

        net_R = R_target - 2*taker/100 * entry / stop_pts
    """
    if stop_pts <= 0:
        return float("inf")
    return (2.0 * taker_pct / 100.0) * entry / stop_pts


def net_r(entry: float, stop_pts: float, r_target: float, taker_pct: float = 0.09) -> float:
    return r_target - fee_drag_r(entry, stop_pts, taker_pct)


def breakeven_win_rate(net_r_multiple: float) -> float | None:
    """Win rate needed for a win-`net_r` / lose-1R system to break even."""
    if net_r_multiple is None or net_r_multiple <= 0:
        return None
    return 100.0 / (1.0 + net_r_multiple)


# --------------------------------------------------------------------------
# 1. Regime scan (ADVISORY ONLY)
# --------------------------------------------------------------------------
def regime_scan(cfg: OpsConfig) -> dict:
    m = cfg.state.get("market", {}) or {}
    lim = cfg.get("limits", {}) or {}
    bl = lim.get("never_add_swing_risk_if", {}) or {}
    zones = {str(z.get("name")): z for z in cfg.get("zones", []) or {}}
    pivot = float((zones.get("pivot") or {}).get("level", 31000))
    s1 = zones.get("support_1") or {}
    r1 = zones.get("resistance_1") or {}
    ty_thresh = float(lim.get("ten_year_headwind_pct", 5.25))

    def num(k):
        v = m.get(k)
        try:
            return float(v) if v is not None and v != "" else None
        except (TypeError, ValueError):
            return None

    last, nq, ty = num("last"), num("nq_futures_pct"), num("ten_year_yield_pct")
    chg, funding, rsi = num("change_24h_pct"), num("funding_pct_per_hr"), num("rsi_daily")

    contribs = []

    def add(name, score, why):
        contribs.append({"name": name, "score": score, "why": why})

    if nq is not None:
        s = 2 if nq > 0.3 else 1 if nq > 0.1 else 0 if nq > -0.1 else -1 if nq > -0.3 else -2
        add("NQ futures", s, f"{nq:+.2f}%")
    if chg is not None:
        s = 2 if chg > 0.5 else 1 if chg > 0.1 else 0 if chg > -0.1 else -1 if chg > -0.5 else -2
        add("XYZ100 24h", s, f"{chg:+.2f}%")
    if last is not None:
        add("vs pivot", 1 if last > pivot else (-1 if last < pivot else 0),
            f"{price(last)} vs {price(pivot)}")
        if s1 and last < float(s1.get("low", 0)):
            add("below support_1", -1, f"{price(last)} under {price(float(s1['low']))}")
        if r1 and last > float(r1.get("high", 0)):
            add("above resistance_1", 1, f"{price(last)} over {price(float(r1['high']))}")
    if funding is not None:
        thr = float(bl.get("funding_pct_per_hr_above", 0.05))
        if funding > thr:
            add("funding overheated", -1, f"{funding:.4f}%/hr > {thr}% — never add swing risk")
        elif funding < -0.01:
            add("funding negative", 1, f"{funding:.4f}%/hr — shorts are paying")
        else:
            add("funding neutral", 0, f"{funding:.4f}%/hr")
    if ty is not None:
        add("10Y yield", -1 if ty >= ty_thresh else 1,
            f"{ty:.2f}% vs the {ty_thresh:.2f}% tech-headwind line")
    if rsi is not None:
        rsi_thr = float(bl.get("rsi_above", 78))
        add("daily RSI", -1 if rsi > rsi_thr else (1 if rsi < 30 else 0),
            f"{rsi:.0f}" + (f" > {rsi_thr:.0f} — never add swing risk" if rsi > rsi_thr else ""))

    clock = session_clock(cfg=cfg)
    macro = _macro_within(cfg, clock["now_eat"], hours=24)
    if macro:
        add("macro inside 24h", -2 if macro["minutes"] <= 60 else -1,
            f"{macro['name']} in {macro['minutes'] / 60:.1f}h")

    total = sum(c["score"] for c in contribs)
    if total >= 3:
        label = "RISK-ON (tech)"
    elif total >= 1:
        label = "mildly risk-on"
    elif total <= -3:
        label = "RISK-OFF (tech)"
    elif total <= -1:
        label = "mildly risk-off"
    else:
        label = "NEUTRAL"
    return {"total": total, "label": label, "contributors": contribs,
            "n_scored": len(contribs),
            "missing": [k for k, v in (("last", last), ("nq", nq), ("10Y", ty),
                                       ("funding", funding), ("rsi", rsi)) if v is None]}


def _macro_within(cfg: OpsConfig, now_eat: datetime, hours: int = 24) -> dict | None:
    best = None
    for ev in cfg.get("events", []) or []:
        if str(ev.get("status", "")).lower() != "scheduled":
            continue
        try:
            when = datetime.strptime(f"{ev['date']} {ev.get('time_eat', '00:00')}",
                                     "%Y-%m-%d %H:%M").replace(tzinfo=EAT)
        except (KeyError, ValueError):
            continue
        mins = (when - now_eat).total_seconds() / 60.0
        if -30 <= mins <= hours * 60 and (best is None or mins < best["minutes"]):
            best = {"name": ev.get("name"), "minutes": mins,
                    "when": when.strftime("%d %b %H:%M EAT")}
    return best


# --------------------------------------------------------------------------
# 2. Zone map
# --------------------------------------------------------------------------
def zone_map(cfg: OpsConfig, last: float | None) -> list[dict]:
    rows = []
    for z in cfg.get("zones", []) or []:
        lvl = z.get("level")
        lo, hi = z.get("low"), z.get("high")
        ref = float(lvl) if lvl is not None else float((lo + hi) / 2)
        band = f"{price(float(lo))}-{price(float(hi))}" if (lo is not None and hi is not None) else price(ref)
        row = {"name": z.get("name"), "band": band, "ref": ref, "kind": z.get("kind"),
               "meaning": z.get("meaning", "")}
        if last:
            row["dist_pts"] = ref - float(last)
            row["dist_pct"] = 100.0 * (ref / float(last) - 1)
        rows.append(row)
    rows.sort(key=lambda r: -r["ref"])
    if last:
        for r in rows:
            r["position"] = "above" if r["dist_pts"] > 0 else ("below" if r["dist_pts"] < 0 else "AT")
    return rows


def current_zone(rows: list[dict], last: float | None) -> str:
    if not last:
        return "unknown — no last price"
    for r in rows:  # sorted high -> low
        if float(last) >= r["ref"]:
            return f"at/above {r['name']} ({r['band']})"
    return f"below {rows[-1]['name']} ({rows[-1]['band']})"


# --------------------------------------------------------------------------
# 5. Feasibility band
# --------------------------------------------------------------------------
def feasibility_table(cfg: OpsConfig, entry: float, r_ref: float = 1.5) -> list[dict]:
    """For each legal range width: fee drag, net R, break-even win rate and the
    largest notional the $40 budget allows.

    r_ref  = the legacy reference target (1.5R) shown for comparison.
    min_r  = the ENFORCED minimum from config (2.0R as of 8 Oct 2026).
    """
    d = cfg.get("day", {})
    taker = float(cfg.get("venue.taker_fee_pct", 0.09))
    fee_max = float(d.get("skip_fee_pct_of_target", 20))
    budget = float(d.get("day.day_risk_budget_usd") or d.get("day_risk_budget_usd", 40))
    cap = float(d.get("hard_cap_usd", 10000))
    eb = float(d.get("entry_buffer_pts", 5))
    sb = float(d.get("stop_buffer_pts", 10))
    wide = float(d.get("skip_range_wider_than_pts", 150))
    clean = float(d.get("clean_range_max_pts", 80))
    min_r = float(d.get("min_target_r", 1.5))

    rows = []
    for w in (30, 40, 50, 60, 70, 80, 100, 120, 130, 140, 150):
        stop = w + eb + sb
        drag = fee_drag_r(entry, stop, taker)
        n_ref = net_r(entry, stop, r_ref, taker)
        n_enf = net_r(entry, stop, min_r, taker)
        max_size = min(max_notional_for_risk(entry, stop, budget), cap)
        rows.append({
            "width": w, "stop_pts": stop,
            "fee_drag_r": drag,
            "min_r_needed": min_r_for_fee_filter(entry, stop, fee_max, taker),
            "r_ref": r_ref, "r_enforced": min_r,
            "net_r_at_ref": n_ref, "be_at_ref": breakeven_win_rate(n_ref),
            "net_r_at_min": n_enf, "be_at_min": breakeven_win_rate(n_enf),
            "legal_at_ref": (100.0 * drag / r_ref) <= fee_max,
            "legal_at_min": (100.0 * drag / min_r) <= fee_max,
            "max_size_for_budget": max_size,
            "budget_binds_before_cap": max_notional_for_risk(entry, stop, budget) < cap,
            "upsize_allowed": w <= clean,
            "within_width_cap": w <= wide,
        })
    return rows


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
def render_scan(cfg: OpsConfig, clock: dict, args) -> str:
    out: list[str] = []
    m = cfg.state.get("market", {}) or {}
    a = cfg.state.get("account", {}) or {}
    d = cfg.get("day", {})
    sw = cfg.get("swing", {})
    taker = float(cfg.get("venue.taker_fee_pct", 0.09))
    budget = float(d.get("day_risk_budget_usd", 40))
    cap = float(d.get("hard_cap_usd", 10000))
    min_r = float(d.get("min_target_r", 1.5))
    fee_max = float(d.get("skip_fee_pct_of_target", 20))
    wide = float(d.get("skip_range_wider_than_pts", 150))

    last = args.last if args.last is not None else _num(m.get("last"))
    equity = args.equity if args.equity is not None else _num(a.get("equity_usd"))
    gate_px = float(sw.get("gate_price", 31366))

    out.append(hr(f"MARKET SCAN — XYZ100 — {clock['hhmm']} EAT {clock['date']} ({clock['phase']})"))

    # ---- header numbers
    out.append("TAPE")
    if last is None:
        out.append("  [MISSING] last price — nothing below can be computed without it")
    else:
        out.append(f"  last           {price(last)}")
        chg = _num(m.get("change_24h_pct"))
        fund = _num(m.get("funding_pct_per_hr"))
        oi = _num(m.get("open_interest_usd"))
        nq = _num(m.get("nq_futures_pct"))
        ty = _num(m.get("ten_year_yield_pct"))
        out.append(f"  24h            {chg:+.2f}%" if chg is not None else "  24h            n/a")
        out.append(f"  funding        {fund:+.4f}%/hr" if fund is not None else "  funding        n/a")
        out.append(f"  open interest  {money(oi, 0)}" if oi else "  open interest  n/a")
        out.append(f"  NQ futures     {nq:+.2f}%   (bias only — never a trigger)" if nq is not None
                   else "  NQ futures     n/a")
        out.append(f"  10Y            {ty:.2f}%" if ty is not None else "  10Y            n/a")
        out.append(f"  equity         {money(equity)}" if equity else "  equity         [MISSING]")
        disc = float(cfg.get("limits.liquid_tracks_nq_discount_pct", 0.7))
        out.append(f"  implied NQ eq. {price(last / (1 - disc / 100.0))}   "
                   f"(XYZ100 prints ~{disc:.1f}% under futures)")
    out.append("")

    # ---- 1 regime
    reg = regime_scan(cfg)
    out.append(hr("1 · REGIME SCAN — ADVISORY ONLY, NEVER AN ENTRY TRIGGER"))
    out.append(f"  {reg['label']}   (score {reg['total']:+d} from {reg['n_scored']} inputs)")
    for c in reg["contributors"]:
        out.append(f"    {c['score']:+d}  {c['name']:<20} {c['why']}")
    if reg["missing"]:
        out.append(f"    unscored (missing): {', '.join(reg['missing'])}")
    out.append("  Quiver colours this read. It arms nothing. Only rule 1 and rule 2 arm a trade.")
    out.append("")

    # ---- 2 zones
    rows = zone_map(cfg, last)
    out.append(hr("2 · ZONE MAP"))
    out.append(f"  price is {current_zone(rows, last)}")
    for r in rows:
        if last:
            out.append(f"    {r['band']:>19}  {r['name']:<14} {r['dist_pts']:+8.1f} pts "
                       f"({r['dist_pct']:+.2f}%)  {r['position']:<5} {r['kind']}")
        else:
            out.append(f"    {r['band']:>19}  {r['name']:<14} {r['kind']}")
    out.append("")

    # ---- 3 swing projection
    out.append(hr("3 · SWING GATE PROJECTION (rule 1)"))
    if last:
        need_pts = gate_px - last
        need_pct = 100.0 * (gate_px / last - 1)
        out.append(f"  trigger        DAILY CLOSE above {price(gate_px)} — wicks do not count")
        out.append(f"  distance       {need_pts:+.1f} pts = {need_pct:+.2f}%")
        t = _swing_ticket(cfg)
        if t:
            out.append(f"  ticket         $4,500 · 5x isolated · $900 margin · stop {price(t['stop'])} "
                       f"({t['stop_pts']:.0f} pts) · target {price(t['target'])} (2R)")
            out.append(f"  risk / fees    {money(t['risk'])} risk · {money(t['fees'])} round trip "
                       f"= {t['fee_pct']:.1f}% of the gross target (LEGAL)")
            out.append(f"  net            {money(t['net'])} = {t['net_r']:.2f}R after fees · "
                       f"break-even win rate {breakeven_win_rate(t['net_r']):.0f}%")
            out.append(f"  est. liq       {price(t['liq'])}")
        fund = _num(m.get("funding_pct_per_hr"))
        if fund is not None:
            per_hr = abs(fund) / 100.0 * 4500
            out.append(f"  funding cost   {money(per_hr, 4)}/hr on the $4,500 ticket "
                       f"({money(per_hr * 24, 2)} per day held)")
        out.append(f"  verdict        {'ARMED — trigger MET' if last > gate_px else 'ARMED, NOT FIRED'}")
        if last <= gate_px:
            out.append(f"                 needs {need_pct:+.2f}% into the close. "
                       f"{'Plausible on a minutes/CPI day (±200-300 pts).' if abs(need_pct) < 1.0 else 'Unlikely today.'}")
        out.append("")
        out.append(f"  !! AMBIGUITY   WHICH daily close? The venue's 1d candle rolls at 00:00 UTC = "
                   f"{VENUE_DAILY_CLOSE_EAT} EAT —")
        out.append(f"                 four hours AFTER your {US_CASH_CLOSE_EAT} EAT flat deadline. If rule 1 means the venue's")
        out.append(f"                 close, the swing trigger can only be evaluated while you are asleep, and a")
        out.append(f"                 swing entry would breach flat-by-23:00 by construction. If it means the US cash")
        out.append(f"                 close (~{US_CASH_CLOSE_EAT} EAT), you can act on it. Pick one and set swing.daily_close_ref")
        out.append(f"                 in config/risk.yaml. Until then gate.py treats a supplied --daily-close as truth.")
    else:
        out.append("  cannot project without a last price")
    out.append("")

    # ---- 4 feasibility band
    ref_entry = last if last else gate_px
    out.append(hr("4 · DAY-TRADE FEASIBILITY BAND — the fee toll, quantified"))
    out.append(f"  Computed at entry {price(ref_entry)}. fee_drag_R = 2 x taker x entry / stop_pts — SIZE-INVARIANT.")
    out.append(f"  net_R = target_R - fee_drag_R.   break-even win rate = 1 / (1 + net_R).")
    out.append("")
    ft = feasibility_table(cfg, ref_entry)
    r_enf = ft[0]["r_enforced"]
    r_ref = ft[0]["r_ref"]
    out.append(f"  ENFORCED minimum target: {r_enf:.1f}R   (legacy reference column: {r_ref:.1f}R)")
    out.append(f"  legend: drag = R lost to fees · minR* = target R needed for fees <= {fee_max:.0f}% of it · "
               f"BE% = break-even win rate")
    out.append(f"          maxsize = largest notional whose stop costs <= {money(budget, 0)} "
               f"(capped at {money(cap, 0)})")
    out.append("")
    out.append(f"  {'width':>5} {'stop':>5} {'drag':>6} {'minR*':>6} | "
               f"{('net@' + format(r_ref, '.1f')):>7} {'BE%':>5} | "
               f"{('net@' + format(r_enf, '.1f')):>7} {'BE%':>5} | {'maxsize':>8}  flags")
    for r in ft:
        flags = []
        if not r["within_width_cap"]:
            flags.append("WIDE-SKIP")
        if r["budget_binds_before_cap"]:
            flags.append("budget<cap")
        if r["upsize_allowed"]:
            flags.append("upsize-ok")
        if r["legal_at_min"]:
            flags.append(f"LEGAL@{r_enf:.1f}R")
        if r["legal_at_ref"] and not r["legal_at_min"]:
            flags.append(f"legal@{r_ref:.1f}R only")
        be_ref = f"{r['be_at_ref']:.0f}" if r["be_at_ref"] else "—"
        be_min = f"{r['be_at_min']:.0f}" if r["be_at_min"] else "—"
        nref = f"{r['net_r_at_ref']:+.2f}" if r["net_r_at_ref"] > 0 else "neg"
        nmin = f"{r['net_r_at_min']:+.2f}" if r["net_r_at_min"] > 0 else "neg"
        out.append(f"  {r['width']:>5} {r['stop_pts']:>5.0f} {r['fee_drag_r']:>5.2f}R "
                   f"{r['min_r_needed']:>5.2f}R | {nref:>7} {be_ref:>5} | {nmin:>7} {be_min:>5} | "
                   f"{money(r['max_size_for_budget'], 0):>8}  {', '.join(flags)}")
    out.append("")
    feas = fee_filter_feasibility(ref_entry, min_r, wide, float(d.get("entry_buffer_pts", 5)),
                                  float(d.get("stop_buffer_pts", 10)), fee_max, taker)
    if not feas["feasible"]:
        out.append(f"  X at the enforced {min_r}R minimum the fee filter needs a {feas['stop_pts_needed']:.0f}-pt "
                   f"stop, but the {wide:.0f}-pt width cap allows {feas['stop_pts_allowed']:.0f} pts.")
        out.append(f"    => at {min_r}R the fee filter CANNOT be satisfied, at any size, on any day. "
                   "This is structural.")
    else:
        out.append(f"  + at the enforced {min_r}R minimum the fee filter needs a {feas['stop_pts_needed']:.0f}-pt "
                   f"stop and the {wide:.0f}-pt width cap allows {feas['stop_pts_allowed']:.0f} pts — satisfiable, "
                   "but only in a narrow band.")
    legal = [r["width"] for r in ft if r["legal_at_min"]]
    if legal:
        be_lo = breakeven_win_rate(net_r(ref_entry, min(legal) + 15, min_r, taker))
        be_hi = breakeven_win_rate(net_r(ref_entry, max(legal) + 15, min_r, taker))
        lo, hi = min(be_lo, be_hi), max(be_lo, be_hi)
        be_txt = f"{lo:.0f}%" if round(lo) == round(hi) else f"{lo:.0f}-{hi:.0f}%"
        out.append(f"  LEGAL BAND at {min_r}R: ranges of {min(legal)}-{max(legal)} pts, "
                   f"break-even win rate {be_txt}.")
        out.append(f"  Below {min(legal)} pts the {min_r}R ticket still fails rule 4; above {int(wide)} pts "
                   f"rule 4 skips the range outright. That is the whole tradeable window.")
    else:
        out.append(f"  No legal band at the enforced {min_r}R target at this entry price.")
    legacy = [r["width"] for r in ft if r["legal_at_ref"]]
    out.append(f"  At the legacy {r_ref}R minimum the legal band is "
               + (f"{min(legacy)}-{max(legacy)} pts." if legacy else
                  "EMPTY — no width from 30 to 150 pts clears rule 4. That is why the minimum was raised."))
    out.append(f"  On a $5,000 standard ticket a perfect +1R nets "
               f"{net_r(ref_entry, 75, 1.0, taker):+.2f}R at a 75-pt stop. Fees are the house's edge, not noise.")
    out.append("")

    # ---- 5 scenarios
    r_high = args.range_high if args.range_high is not None else _num((cfg.state.get("range_5m") or {}).get("high"))
    r_low = args.range_low if args.range_low is not None else _num((cfg.state.get("range_5m") or {}).get("low"))
    out.append(hr("5 · SCENARIOS — pre-computed so 16:45 is a lookup"))
    if r_high is None or r_low is None:
        out.append("  Range not printed / not supplied. Projecting the band instead:")
        for w in (60, 100, 140):
            hi = ref_entry + w / 2
            lo = ref_entry - w / 2
            for side, trig in (("LONG", hi + float(d.get("entry_buffer_pts", 5))),
                               ("SHORT", lo - float(d.get("entry_buffer_pts", 5)))):
                stop = w + 15
                drag = fee_drag_r(trig, stop, taker)
                nR = net_r(trig, stop, 2.0, taker)
                ms = min(max_notional_for_risk(trig, stop, budget), cap)
                legal = (100.0 * drag / 2.0) <= fee_max
                out.append(f"    hypothetical {w:>3}-pt range, {side:<5} entry {price(trig)} "
                           f"stop {stop:.0f} pts -> 2.0R nets {nR:+.2f}R (BE {breakeven_win_rate(nR):.0f}%), "
                           f"max size {money(ms, 0)}, {'LEGAL' if legal else 'BLOCKED by rule 4'}")
        out.append("  Run again at 16:45 with --range-high/--range-low for the real tickets.")
    else:
        w = r_high - r_low
        out.append(f"  Range {price(r_low)}-{price(r_high)} = {pts(w)}"
                   f"{'  -> SKIP, wider than the ' + str(int(wide)) + '-pt cap' if w > wide else ''}")
        if w <= wide:
            for side in ("long", "short"):
                entry = r_high + 5 if side == "long" else r_low - 5
                stop = r_low - 10 if side == "long" else r_high + 10
                stop_pts = abs(entry - stop)
                size = min(args.size or float(d.get("standard_size_usd", 5000)),
                           max_notional_for_risk(entry, stop_pts, budget), cap)
                risk = units(size, entry) * stop_pts
                fees = taker_fees_round_trip(size, taker)
                drag = fee_drag_r(entry, stop_pts, taker)
                for R in sorted({1.5, 2.0, min_r}):
                    tgt = entry + R * stop_pts if side == "long" else entry - R * stop_pts
                    gross = units(size, entry) * stop_pts * R
                    nR = net_r(entry, stop_pts, R, taker)
                    fee_pct = 100.0 * drag / R
                    ok = fee_pct <= fee_max
                    be = breakeven_win_rate(nR)
                    out.append(f"    {side.upper():<5} @{R:.1f}R  entry {price(entry)}  stop {price(stop)} "
                               f"({stop_pts:.0f} pts)  target {price(tgt)}")
                    out.append(f"          size {money(size, 0)} · margin {money(size / 5)} · risk {money(risk)} "
                               f"· fees {money(fees)} · net {money(gross - fees)} = {nR:+.2f}R")
                    out.append(f"          break-even win rate {be:.0f}% · est. liq {price(liq_price(entry, side, 5))} · "
                               f"{'LEGAL' if ok else f'BLOCKED (fees {fee_pct:.0f}% > {fee_max:.0f}%, needs {min_r_for_fee_filter(entry, stop_pts, fee_max, taker):.2f}R)'}")
            out.append(f"    NO BREAK  no 1-min close beyond either edge -> SKIP. A touch is not a break.")
    out.append("")

    # ---- 6 prediction brief
    out.append(hr("6 · PREDICTION BRIEF — conditional, with falsifiers"))
    out.extend(_prediction_brief(cfg, clock, last, gate_px, reg, rows, ref_entry, taker))
    out.append("")
    out.append(hr("WHAT THIS SCAN CANNOT TELL YOU"))
    for line in (
        "Whether price goes up or down. Nothing here forecasts direction, and it never will.",
        "Your position status or equity — those are read off the app, never inferred from a feed.",
        "The fill you will actually get. Slippage on a break is real and is not modelled here.",
        "Anything about the next headline. Minutes/CPI days spike ±200-300 pts in minutes.",
        "Whether a resting wall will hold. Order-book walls vanish on headlines; they are not stops.",
    ):
        out.append(f"  - {line}")
    out.append("")
    out.append(hr())
    return "\n".join(out)


def _swing_ticket(cfg: OpsConfig) -> dict | None:
    sw = cfg.get("swing", {}) or {}
    try:
        entry = float(sw.get("gate_price", 31366))
        stop = float(sw.get("stop_price", 30670))
        target = float(sw.get("take_profit_price", 32758))
        size = float(sw.get("ticket_usd", 4500))
    except (TypeError, ValueError):
        return None
    taker = float(cfg.get("venue.taker_fee_pct", 0.09))
    stop_pts = entry - stop
    risk = units(size, entry) * stop_pts
    fees = taker_fees_round_trip(size, taker)
    gross = units(size, entry) * (target - entry)
    return {"stop": stop, "stop_pts": stop_pts, "target": target, "risk": risk, "fees": fees,
            "fee_pct": 100.0 * fees / gross if gross else 0.0, "net": gross - fees,
            "net_r": (gross - fees) / risk if risk else 0.0, "liq": liq_price(entry, "long", 5, fee_pct=taker)}


def _prediction_brief(cfg: OpsConfig, clock: dict, last, gate_px, reg, rows, ref_entry, taker) -> list[str]:
    out = []
    n = 1

    def say(text, falsifier):
        nonlocal n
        out.append(f"  {n}. {text}")
        out.append(f"     Falsified by: {falsifier}")
        n += 1

    if last is not None:
        need_pct = 100.0 * (gate_px / last - 1)
        if need_pct > 1.19:
            say(f"The swing gate at {price(gate_px)} is {need_pct:+.2f}% away. A daily close above it is "
                f"UNLIKELY today — plan on the 16:45 range break being the only live setup.",
                f"a daily close above {price(gate_px)} (wicks do not count)")
        elif need_pct > 0:
            say(f"The swing gate is {need_pct:+.2f}% away — close enough that a minutes/CPI headline could "
                f"cover it. Arm the $4,500 ticket but do not send it.",
                f"a daily close at or below {price(gate_px)}")
        else:
            say(f"Price is ABOVE the swing gate at {price(gate_px)}. Rule 1 is live on a confirming daily close.",
                f"a daily close back below {price(gate_px)}")

    d = cfg.get("day", {})
    min_r = float(d.get("min_target_r", 1.5))
    fee_max = float(d.get("skip_fee_pct_of_target", 20))
    wide = float(d.get("skip_range_wider_than_pts", 150))
    feas = fee_filter_feasibility(ref_entry, min_r, wide,
                                  float(d.get("entry_buffer_pts", 5)),
                                  float(d.get("stop_buffer_pts", 10)), fee_max, taker)
    if not feas["feasible"]:
        say(f"At the enforced {min_r}R minimum, rule 4's fee filter CANNOT be cleared on any legal "
            f"(<= {wide:.0f} pt) range. Every 16:45 setup is a SKIP until min_target_r or "
            f"fee_filter_basis changes.",
            f"a printed range of {feas['range_pts_needed']:.0f}+ pts (forbidden by rule 4), "
            "or a change to day.fee_filter_basis")
    else:
        lo = math.ceil(max(feas["stop_pts_needed"] - 15.0, 0.0))
        say(f"The enforced {min_r}R minimum makes the day trade viable, but only inside a narrow band: "
            f"a printed range of {lo}-{wide:.0f} pts. Below {lo} pts the fee toll eats more than "
            f"{fee_max:.0f}% of the target; above {wide:.0f} pts rule 4 skips the range outright. "
            f"Expect most sessions to be SKIPs, and treat that as the plan working.",
            f"a printed range outside {lo}-{wide:.0f} pts, or a change to day.min_target_r")
    legacy_feas = fee_filter_feasibility(ref_entry, 1.5, wide,
                                         float(d.get("entry_buffer_pts", 5)),
                                         float(d.get("stop_buffer_pts", 10)), fee_max, taker)
    if not legacy_feas["feasible"]:
        say(f"For the record: the old 1.5R minimum was UNSATISFIABLE — it needed a "
            f"{legacy_feas['stop_pts_needed']:.0f}-pt stop where rule 4 allows "
            f"{legacy_feas['stop_pts_allowed']:.0f} pts. That is why the minimum is now {min_r}R.",
            "nothing — this is arithmetic, not a forecast")

    if last is not None:
        stop_typ = 75
        say(f"On a typical 60-pt range the standard $5,000 ticket risks "
            f"{money(units(5000, ref_entry) * stop_typ)} and needs a "
            f"{breakeven_win_rate(net_r(ref_entry, stop_typ, min_r, taker)):.0f}% hit rate just to break even "
            f"at {min_r}R. Below that hit rate the system loses money even while winning trades.",
            f"a sustained realised hit rate above "
            f"{breakeven_win_rate(net_r(ref_entry, stop_typ, min_r, taker)):.0f}% on rule-2 entries")

    say(f"The regime read is {reg['label']} (score {reg['total']:+d}). This adjusts SIZE and how fast you "
        f"take partials. It does not arm, block or trigger anything.",
        "nothing — it is advisory by construction")

    macro = _macro_within(cfg, clock["now_eat"], hours=24 * 8)
    if macro:
        say(f"Next scheduled macro: {macro['name']} at {macro['when']} "
            f"(~{macro['minutes'] / 60:.0f}h out). Inside 1h of it, size is capped at "
            f"{money(float(d.get('macro_max_size_usd', 2500)), 0)} and you must be flat or breakeven+ "
            f"5 minutes BEFORE the print.",
            "the print being moved or cancelled")

    pos = (cfg.state.get("account", {}) or {}).get("position_status")
    if pos is None or str(pos).upper() == "UNCONFIRMED":
        say("The 7 Oct long is UNCONFIRMED. Until the app says otherwise, NO new entry can be authorised "
            "(rule 6: one index position at a time). This overrides every projection above.",
            "confirming FLAT in the app")

    if clock["phase"] in ("managing", "gate") and clock["minutes_to_flat"] > 0:
        say(f"{clock['minutes_to_flat']} minutes remain to the 23:00 EAT flat deadline. Anything still open "
            f"at 23:00 is a rule breach, not a swing.",
            "the position being a rule-1 swing, which is explicitly allowed to survive 23:00")
    return out


def _num(v):
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------
def apply_live(cfg: OpsConfig) -> str | None:
    """Shell out to liquid_feed.py and merge the snapshot into the in-memory state."""
    try:
        rc = subprocess.run([sys.executable, os.path.join(HERE, "liquid_feed.py"), "--state-patch"],
                            capture_output=True, text=True, timeout=45)
    except subprocess.TimeoutExpired:
        return "liquid_feed.py timed out after 45s"
    if rc.returncode != 0:
        return (rc.stderr or rc.stdout or "unknown feed error").strip().splitlines()[-1]
    try:
        patch = json.loads(rc.stdout)
    except json.JSONDecodeError:
        return "feed returned non-JSON"
    for section, values in patch.items():
        node = cfg.state.setdefault(section, {})
        for k, v in (values or {}).items():
            if v is not None:
                node[k] = v
    return None


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="XYZ100 market scan + prediction brief.")
    ap.add_argument("--state", default=None)
    ap.add_argument("--at", default=None, help="pin the EAT clock, HH:MM")
    ap.add_argument("--live", action="store_true", help="fetch via liquid_feed.py first")
    ap.add_argument("--brief", action="store_true", help="prediction brief only")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--last", type=float)
    ap.add_argument("--equity", type=float)
    ap.add_argument("--funding", type=float)
    ap.add_argument("--oi", type=float)
    ap.add_argument("--nq", type=float)
    ap.add_argument("--ten-year", dest="ten_year", type=float)
    ap.add_argument("--rsi", type=float)
    ap.add_argument("--range-high", dest="range_high", type=float)
    ap.add_argument("--range-low", dest="range_low", type=float)
    ap.add_argument("--size", type=float)
    args = ap.parse_args(argv)

    cfg = OpsConfig(state_path=args.state)

    if args.live:
        err = apply_live(cfg)
        if err:
            print(f"LIVE FEED UNAVAILABLE: {err}")
            print("Falling back to config/state.yaml. The feed needs a machine that can reach")
            print("api.hyperliquid.xyz — pass the numbers by hand with --last/--funding/--oi/--nq.")
            print()

    # CLI overrides
    mk = cfg.state.setdefault("market", {})
    rg = cfg.state.setdefault("range_5m", {})
    ac = cfg.state.setdefault("account", {})
    if args.last is not None:
        mk["last"] = args.last
    if args.funding is not None:
        mk["funding_pct_per_hr"] = args.funding
    if args.oi is not None:
        mk["open_interest_usd"] = args.oi
    if args.nq is not None:
        mk["nq_futures_pct"] = args.nq
    if args.ten_year is not None:
        mk["ten_year_yield_pct"] = args.ten_year
    if args.rsi is not None:
        mk["rsi_daily"] = args.rsi
    if args.equity is not None:
        ac["equity_usd"] = args.equity
    if args.range_high is not None:
        rg["high"] = args.range_high
    if args.range_low is not None:
        rg["low"] = args.range_low
    if rg.get("high") is not None and rg.get("low") is not None:
        rg["width_pts"] = float(rg["high"]) - float(rg["low"])

    now = None
    if args.at:
        base = datetime.now(EAT)
        hh, mm = args.at.split(":")
        now = base.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    clock = session_clock(now, cfg)

    if args.json:
        last = args.last if args.last is not None else _num(mk.get("last"))
        reg = regime_scan(cfg)
        rows = zone_map(cfg, last)
        payload = {
            "clock": {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in clock.items()},
            "regime": reg,
            "zones": rows,
            "feasibility": feasibility_table(cfg, last or float(cfg.get("swing.gate_price", 31366))),
            "state": cfg.state,
        }
        print(json.dumps(payload, indent=2, default=str))
        return EXIT_OK

    if _num(mk.get("last")) is None and args.last is None:
        print("SCAN BLOCKED: no last price in config/state.yaml and none given with --last.")
        print("Nothing below can be computed. Fill the bracket — do not estimate it.")
        return EXIT_INCOMPLETE

    print(render_scan(cfg, clock, args))
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
