#!/usr/bin/env python3
"""
size.py — ticket math for Liquid XYZ100. Enforces the $10,000 HARD CAP and the
$40/day risk budget, and bakes the 0.09% taker fee into every target (rule 7).

Usage
-----
  # The armed swing ticket, straight from config/risk.yaml
  python3 size.py --swing

  # Day trade built from the printed 16:30-16:45 range (rule 2 buffers applied)
  python3 size.py --range --high 31052 --low 30988 --side long
  python3 size.py --range --high 31052 --low 30988 --side short --size 7500

  # Any custom bracket
  python3 size.py --custom --side long --entry 31010 --stop 30930 --size 5000 --r 2

  # Size FOR a risk budget instead of a notional (never widen a stop — cut size)
  python3 size.py --custom --side long --entry 31010 --stop 30930 --risk-usd 40

  # Mark an open position to market
  python3 size.py --position --side long --notional 12548 --entry 30918 --mark 30996.5

Exit codes: 0 = ticket is legal, 3 = ticket blocked by a rule, 1 = bad input.

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import argparse
import sys

from opslib import (
    OpsConfig, fee_pct_of_gross_target, hr, liq_price, max_notional_for_risk,
    min_r_for_fee_filter, money, pnl_usd, price, pts, risk_usd, session_clock,
    stop_pts_from_prices, taker_fees_round_trip, units,
)


class TicketBlocked(Exception):
    pass


def build_day_ticket(cfg: OpsConfig, side: str, range_high: float, range_low: float,
                     size_usd: float | None = None, r_mult: float | None = None,
                     mark: float | None = None):
    """Rule 2: entry = 1-min close beyond the edge +5 pts; stop = opposite edge -/+10 pts."""
    d = cfg.get("day", {})
    eb = float(d.get("entry_buffer_pts", 5))
    sb = float(d.get("stop_buffer_pts", 10))
    width = range_high - range_low

    if side == "long":
        entry = range_high + eb
        stop = range_low - sb
    else:
        entry = range_low - eb
        stop = range_high + sb

    stop_pts = stop_pts_from_prices(entry, stop, side)
    r_mult = float(r_mult if r_mult is not None else d.get("min_target_r", 1.5))
    size = float(size_usd if size_usd is not None else d.get("standard_size_usd", 5000))

    return build_ticket(
        cfg, side=side, entry=entry, stop=stop, size_usd=size, r_mult=r_mult,
        setup=f"5m range break ({price(range_low)}-{price(range_high)}, width {width:.0f} pts)",
        range_width_pts=width, mark=mark,
    )


def build_swing_ticket(cfg: OpsConfig, close_price: float | None = None,
                       gate_triggered: bool = True):
    """Rule 1: LONG only on a DAILY CLOSE above the gate. Wicks do not count."""
    s = cfg.get("swing", {})
    gate = float(s.get("gate_price", 31366))
    entry = float(close_price) if close_price else gate
    return build_ticket(
        cfg, side=s.get("side", "long"), entry=entry, stop=float(s.get("stop_price", 30670)),
        size_usd=float(s.get("ticket_usd", 4500)), leverage=float(s.get("leverage", 5)),
        r_mult=None, target_price=float(s.get("take_profit_price", 32758)),
        setup=f"swing — daily CLOSE above {price(gate)}",
        risk_target_usd=float(s.get("risk_usd", 100)), is_swing=True,
    )


def build_ticket(cfg: OpsConfig, side: str, entry: float, stop: float,
                 size_usd: float | None = None, r_mult: float | None = None,
                 target_price: float | None = None, leverage: float | None = None,
                 setup: str = "manual bracket", range_width_pts: float | None = None,
                 risk_target_usd: float | None = None, mark: float | None = None,
                 is_swing: bool = False) -> dict:
    side = side.lower()
    if side not in ("long", "short"):
        raise ValueError("side must be long or short")
    if entry <= 0 or stop <= 0:
        raise ValueError("entry and stop must be positive prices")

    stop_pts = stop_pts_from_prices(entry, stop, side)
    if stop_pts <= 0:
        raise TicketBlocked(
            f"stop is on the wrong side of entry for a {side.upper()} "
            f"(entry {price(entry)}, stop {price(stop)})"
        )

    d = cfg.get("day", {})
    x = cfg.get("execution", {})
    v = cfg.get("venue", {})
    lim = cfg.get("limits", {})
    taker = float(v.get("taker_fee_pct", 0.09))
    lev = float(leverage if leverage is not None else x.get("leverage", d.get("leverage", 5)))
    hard_cap = float(d.get("hard_cap_usd", 10000))
    budget = float(d.get("day_risk_budget_usd", 40))
    std_size = float(d.get("standard_size_usd", 5000))
    clean_max_pts = float(d.get("clean_range_max_pts", 80))
    up_size = float(d.get("max_size_clean_range_usd", 10000))
    fee_filter = float(d.get("skip_fee_pct_of_target", 20))
    min_r = float(d.get("min_target_r", 1.5))

    warnings: list[str] = []
    blocks: list[str] = []

    # ---- sizing -----------------------------------------------------------
    if size_usd is None:
        # size FOR the risk budget
        if risk_target_usd is None:
            raise ValueError("pass either size_usd or risk_target_usd")
        size = max_notional_for_risk(entry, stop_pts, float(risk_target_usd))
        warnings.append(f"sized to risk budget: {money(size)} notional = {money(risk_target_usd)} of risk")
    else:
        size = float(size_usd)

    if range_width_pts is not None:
        if range_width_pts > clean_max_pts and size > std_size:
            warnings.append(
                f"upsizing to {money(size)} needs a clean range <= {clean_max_pts:.0f} pts; "
                f"range is {range_width_pts:.0f} pts -> back to the {money(std_size)} standard size"
            )
            size = std_size

    # HARD CAP (rule 3)
    if size > hard_cap:
        warnings.append(
            f"HARD CAP: requested {money(size)} > {money(hard_cap)} cap -> clamped to {money(hard_cap)}. "
            f"Size creep kills."
        )
        size = hard_cap

    # Day risk budget (rule 3) — cut size, never the stop
    risk = risk_usd(size, entry, stop_pts)
    if not is_swing and risk > budget:
        new_size = max_notional_for_risk(entry, stop_pts, budget)
        new_size = min(new_size, hard_cap)
        warnings.append(
            f"RISK BUDGET: {money(risk)} of stop risk > {money(budget)}/day at {money(size)}. "
            f"NEVER widen a stop — cut size to {money(new_size, 0)} "
            f"(risk {money(risk_usd(new_size, entry, stop_pts))})."
        )
        risk_at_requested = risk
        size = new_size
        risk = risk_usd(size, entry, stop_pts)
    else:
        risk_at_requested = risk

    # ---- target -----------------------------------------------------------
    if target_price is not None:
        target = float(target_price)
        r_actual = (abs(target - entry) / stop_pts)
    else:
        r_actual = max(float(r_mult or min_r), min_r) if not is_swing else float(r_mult or 2.0)
        target = entry + r_actual * stop_pts if side == "long" else entry - r_actual * stop_pts

    gross_target = units(size, entry) * stop_pts * r_actual
    fees_rt = taker_fees_round_trip(size, taker)
    fee_pct = fee_pct_of_gross_target(size, entry, stop_pts, r_actual, taker)
    net_target = gross_target - fees_rt
    r_needed = min_r_for_fee_filter(entry, stop_pts, fee_filter, taker)

    # Rule 4's "fees >20% of target" — measured against the configured basis.
    basis = str(d.get("fee_filter_basis", "gross_target")).lower()
    if basis == "stop_risk":
        fee_basis_value = risk
        fee_basis_pct = 100.0 * fees_rt / risk if risk > 0 else float("inf")
        fee_basis_label = f"{fee_filter:.0f}% of the {money(risk)} stop risk"
    elif basis == "notional":
        fee_basis_value = size
        fee_basis_pct = 100.0 * fees_rt / size if size > 0 else float("inf")
        fee_basis_label = f"{fee_filter:.0f}% of the {money(size, 0)} notional"
    else:
        basis = "gross_target"
        fee_basis_value = gross_target
        fee_basis_pct = fee_pct
        fee_basis_label = f"{fee_filter:.0f}% of the {money(gross_target)} gross target"

    if fee_basis_pct > fee_filter:
        msg = (
            f"FEE FILTER (rule 4, basis={basis}): round-trip taker fees {money(fees_rt)} = "
            f"{fee_basis_pct:.1f}% — over the {fee_basis_label}."
        )
        if basis == "gross_target":
            msg += (
                f" At this {stop_pts:.0f}-pt stop you need a {r_needed:.1f}R target for fees to be "
                f"{fee_filter:.0f}% of it. The ratio is size-invariant — adding size does NOT fix it; "
                f"only a wider stop or a bigger target does."
            )
        (blocks if not is_swing else warnings).append(msg)

    if not is_swing and r_actual < min_r:
        blocks.append(f"target {r_actual:.2f}R is under the {min_r}R minimum (rule 2)")

    # ---- advisory modifiers ----------------------------------------------
    ty = cfg.st("market.ten_year_yield_pct", None)
    ty_thresh = float(lim.get("ten_year_headwind_pct", 5.25))
    if ty is not None and float(ty) >= ty_thresh:
        warnings.append(
            f"10Y at {ty}% >= {ty_thresh}% = tech headwind: smaller size, faster partials "
            f"(consider {money(size * float(lim.get('ten_year_headwind_size_factor', 0.5)), 0)})."
        )

    funding = cfg.st("market.funding_pct_per_hr", None)
    rsi = cfg.st("market.rsi_daily", None)
    bl = lim.get("never_add_swing_risk_if", {}) or {}
    if is_swing:
        if funding is not None and float(funding) > float(bl.get("funding_pct_per_hr_above", 0.05)):
            blocks.append(f"funding {funding}%/hr is above the never-add-swing-risk threshold")
        if rsi is not None and float(rsi) > float(bl.get("rsi_above", 78)):
            blocks.append(f"RSI {rsi} is above the never-add-swing-risk threshold")

    liq = liq_price(entry, side, lev, fee_pct=taker)
    margin = size / lev

    return {
        "side": side.upper(),
        "setup": setup,
        "entry": entry,
        "stop": stop,
        "stop_pts": stop_pts,
        "stop_pct": 100.0 * stop_pts / entry,
        "target": target,
        "target_pts": abs(target - entry),
        "r_multiple": r_actual,
        "size_usd": size,
        "requested_size_usd": float(size_usd) if size_usd is not None else size,
        "units": units(size, entry),
        "usd_per_point": units(size, entry),
        "leverage": lev,
        "margin_usd": margin,
        "risk_usd": risk,
        "risk_at_requested_size": risk_at_requested,
        "risk_pct_equity": 100.0 * risk / float(cfg.get("account.equity_ref", 10000) or 10000),
        "gross_target_usd": gross_target,
        "fees_round_trip_usd": fees_rt,
        "fee_pct_of_target": fee_pct,
        "fee_filter_basis": basis,
        "fee_basis_pct": fee_basis_pct,
        "fee_basis_label": fee_basis_label,
        "net_target_usd": net_target,
        "net_r_multiple": net_target / risk if risk > 0 else 0.0,
        "min_r_for_fee_filter": r_needed,
        "est_liq_price": liq,
        "est_liq_pts": abs(liq - entry),
        "mark": mark,
        "mark_pnl_usd": pnl_usd(size, entry, mark, side) if mark else None,
        "hard_cap_usd": hard_cap,
        "day_risk_budget_usd": budget,
        "warnings": warnings,
        "blocks": blocks,
        "is_swing": is_swing,
        "legal": not blocks,
        "reduce_only_entry": bool(x.get("reduce_only_for_entries", False)),
        "reduce_only_exit": bool(x.get("reduce_only_for_exits", True)),
        "allowed_order_types": x.get("order_types_allowed", ["market", "limit"]),
        "forbidden_order_types": x.get("order_types_forbidden", []),
    }


def render(t: dict, cfg: OpsConfig, clock: dict | None = None) -> str:
    out = []
    out.append(hr(f"TICKET — {t['side']} XYZ100 — {t['setup']}"))
    verdict = "LEGAL" if t["legal"] else "BLOCKED"
    if t.get("armed") is False:
        out.append("VERDICT: SKIP — ticket ARMED, trigger NOT met (pre-built for the daily close)")
    else:
        out.append(f"VERDICT: {t['side'] if t['legal'] else 'SKIP'}  [{verdict}]")
    out.append("")
    out.append("Ticket")
    out.append(f"  entry          {price(t['entry'])}          ({t['side'].lower()} @ 1-min close beyond the edge)")
    out.append(f"  stop           {price(t['stop'])}          {pts(t['stop_pts'], 1)} = {t['stop_pct']:.2f}% adverse")
    out.append(f"  target         {price(t['target'])}          {pts(t['target_pts'], 1)} = {t['r_multiple']:.2f}R")
    out.append(f"  size           {money(t['size_usd'], 0)} notional   = {t['units']:.4f} units = {money(t['usd_per_point'])} per point")
    out.append(f"  leverage       {t['leverage']:.0f}x ISOLATED   (set leverage BEFORE size)")
    out.append(f"  margin         {money(t['margin_usd'])}   (notional / leverage)")
    out.append(f"  risk           {money(t['risk_usd'])}   = {t['risk_pct_equity']:.2f}% of the reference book")
    out.append(f"  est. liq       {price(t['est_liq_price'])}   (~{pts(t['est_liq_pts'], 0)} adverse, isolated {t['leverage']:.0f}x — venue is the truth)")
    out.append("")
    out.append("Fees & expectancy (rule 7 — 0.09% taker)")
    out.append(f"  round trip     {money(t['fees_round_trip_usd'])}   ({t['fee_pct_of_target']:.1f}% of the gross target)")
    out.append(f"  rule-4 basis   {t['fee_filter_basis']} -> {t['fee_basis_pct']:.1f}% vs the {t['fee_basis_label']}")
    out.append(f"  gross target   {money(t['gross_target_usd'])}      net target {money(t['net_target_usd'])} = {t['net_r_multiple']:.2f}R net")
    if t["mark_pnl_usd"] is not None:
        out.append(f"  mark-to-market {money(t['mark_pnl_usd'])} at {price(t['mark'])}")
    out.append("")
    out.append("Order construction (rule 5)")
    out.append(f"  type           {'/'.join(str(o).upper() for o in t['allowed_order_types'])} ONLY"
               f" — never {'/'.join(str(o) for o in t['forbidden_order_types'])} under $1M notional")
    out.append(f"  reduce-only    OFF for the entry / ON for exits")
    out.append(f"  brackets       TP {price(t['target'])} + SL {price(t['stop'])} sent WITH the entry")
    out.append(f"  proof          the stop only counts once it rests in Open Orders")
    if not t["is_swing"]:
        out.append(f"  partial        decide BEFORE entry: +1R take half & stop to BE, or hold full to {t['r_multiple']:.1f}R")
    out.append("")

    if t["warnings"]:
        out.append(hr("WARNINGS"))
        for w in t["warnings"]:
            out.append(f"  ! {w}")
        out.append("")
    if t["blocks"]:
        out.append(hr("BLOCKED BY RULE"))
        for b in t["blocks"]:
            out.append(f"  X {b}")
        out.append("")
    if clock:
        out.append(hr("SESSION"))
        out.append(f"  {clock['hhmm']} EAT ({clock['date']}) — {clock['phase']}: {clock['label']}")
        out.append(f"  flat by 23:00 EAT — {clock['minutes_to_flat']} min left"
                   if clock["minutes_to_flat"] > 0 else "  PAST 23:00 — must be FLAT now")
    out.append(hr())
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="XYZ100 ticket math (enforces the $10k cap).")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--swing", action="store_true", help="the armed swing ticket from config")
    mode.add_argument("--range", action="store_true", help="build from the printed 5-min range")
    mode.add_argument("--custom", action="store_true", help="any entry/stop bracket")
    mode.add_argument("--position", action="store_true", help="mark an open position to market")

    ap.add_argument("--side", default="long", choices=["long", "short"])
    ap.add_argument("--high", type=float, help="range high (with --range)")
    ap.add_argument("--low", type=float, help="range low (with --range)")
    ap.add_argument("--entry", type=float)
    ap.add_argument("--stop", type=float)
    ap.add_argument("--target", type=float, help="explicit target price (overrides --r)")
    ap.add_argument("--size", type=float, help="notional USD")
    ap.add_argument("--risk-usd", type=float, help="size FOR this much risk instead")
    ap.add_argument("--r", type=float, help="target R multiple (default 1.5 day / 2 swing)")
    ap.add_argument("--leverage", type=float)
    ap.add_argument("--notional", type=float, help="open position notional (with --position)")
    ap.add_argument("--mark", type=float, help="current mark price")
    ap.add_argument("--close", type=float, help="daily CLOSE for the swing trigger")
    ap.add_argument("--state", default=None, help="path to state.yaml")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    cfg = OpsConfig(state_path=args.state)
    clock = session_clock(cfg=cfg)

    try:
        if args.swing:
            gate = float(cfg.get("swing.gate_price", 31366))
            close = args.close if args.close is not None else cfg.st("market.last")
            if close is not None and float(close) <= gate:
                print(hr("SWING GATE — NOT TRIGGERED"))
                print(f"  Rule 1 needs a DAILY CLOSE above {price(gate)}. Wicks do not count.")
                print(f"  Last print: {price(float(close))} -> needs "
                      f"{100.0 * (gate / float(close) - 1):+.2f}% into the close.")
                print(f"  Status: ARMED, not fired. Ticket below is pre-built for the close.")
                print()
            t = build_swing_ticket(cfg, close_price=args.close)
            triggered = close is None or float(close) > gate
            t["armed"] = triggered
            if not triggered:
                t["setup"] += " — ARMED, NOT TRIGGERED"
        elif args.range:
            if args.high is None or args.low is None:
                ap.error("--range needs --high and --low")
            if args.high <= args.low:
                ap.error("--high must be above --low")
            width = args.high - args.low
            skip_w = float(cfg.get("day.skip_range_wider_than_pts", 150))
            if width > skip_w:
                print(hr("SKIP — RANGE TOO WIDE (rule 4)"))
                print(f"  range {price(args.low)}-{price(args.high)} = {pts(width, 0)} > {skip_w:.0f} pts.")
                print(f"  No trade. Walk away — that is the whole plan.")
                return 3
            t = build_day_ticket(cfg, args.side, args.high, args.low, args.size, args.r, args.mark)
        elif args.custom:
            if args.entry is None or args.stop is None:
                ap.error("--custom needs --entry and --stop")
            width = None
            if args.high and args.low:
                width = args.high - args.low
            t = build_ticket(
                cfg, side=args.side, entry=args.entry, stop=args.stop,
                size_usd=args.size, r_mult=args.r, target_price=args.target,
                leverage=args.leverage, range_width_pts=width,
                risk_target_usd=args.risk_usd, mark=args.mark, setup="manual bracket",
            )
        else:  # --position
            if args.notional is None or args.entry is None:
                ap.error("--position needs --notional and --entry")
            n, e = args.notional, args.entry
            u = units(n, e)
            print(hr("OPEN POSITION"))
            print(f"  {args.side.upper()} {money(n, 0)} notional @ {price(e)} = {u:.4f} units = {money(u)} per point")
            print(f"  leverage 5x isolated -> margin {money(n / (args.leverage or 5))}")
            print(f"  est. liq  {price(liq_price(e, args.side, args.leverage or 5))}")
            if args.mark:
                p = pnl_usd(n, e, args.mark, args.side)
                print(f"  mark      {price(args.mark)} -> PnL {money(p)} ({100.0 * (args.mark / e - 1):+.2f}% price)")
                print(f"            every 100 pts = {money(u * 100)}")
            cap = float(cfg.get("day.hard_cap_usd", 10000))
            if n > cap:
                print(f"  X HARD CAP BREACH: {money(n, 0)} > {money(cap, 0)} (rule 3). "
                      f"Every 100 pts = {money(u * 100)}. Never add to it.")
            print(hr())
            return 0
    except TicketBlocked as exc:
        print(f"BLOCKED: {exc}")
        return 3
    except ValueError as exc:
        print(f"INPUT ERROR: {exc}")
        return 1

    if args.json:
        import json
        print(json.dumps(t, indent=2, default=str))
        return 0 if t["legal"] else 3

    print(render(t, cfg, clock))
    return 0 if t["legal"] else 3


if __name__ == "__main__":
    sys.exit(main())
