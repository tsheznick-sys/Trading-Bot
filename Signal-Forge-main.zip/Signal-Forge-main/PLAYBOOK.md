# PLAYBOOK.md — Liquid XYZ100 full rule reference

The expanded version of `MASTER_PROMPT.md` Part 1. Read this once; run `RUNBOOK-US-OPEN.md`
every day. Every rule below is enforced mechanically by `gate.py` / `size.py`.

**Educational material only — not financial advice. Leveraged perpetuals can liquidate fast.**

---

## 0. The instrument

| | |
|---|---|
| Venue | Liquid — `app.liquid.trade` (**not** `.com`) |
| Market | **XYZ100** — Nasdaq-100 perpetual, HIP-3 via the `xyz` dex on Hyperliquid rails |
| Settlement | Cash-settled, USDC margin, no expiry, hourly funding, 24/7, up to 30x |
| Fees | maker **0.03%** / taker **0.09%** per side |
| Tracking | prints **~0.7% UNDER** NQ futures — use Liquid levels for triggers, futures for bias only |

### Perp math (the whole model in four lines)

```
units        = notional_usd / entry_price          # 1 unit = $1 per index point
pnl_usd      = units * delta_points                # long: mark-entry, short: entry-mark
risk_usd     = units * stop_pts
margin_usd   = notional_usd / leverage             # set leverage BEFORE size
```

A 1% price move = 1% of notional. Verified three independent ways against the desk's own numbers:

| Fact from the desk | Model output |
|---|---|
| Swing ticket $4,500, entry 31,366, SL 30,670 → "Risk $100 (1%)" | units 0.14347 × 696 pts = **$99.85** ✓ |
| "TP $32,758 (2R)" | 32,758 − 31,366 = 1,392 = 2 × 696 ✓ |
| "a $12.5k position makes every 100 pts = $40" | 12,548/30,918 = 0.4059 units × 100 = **$40.59** ✓ |

---

## 1. The two — and only two — setups

### 1a. Swing long (rule 1)

| Field | Value |
|---|---|
| Trigger | **DAILY CLOSE above 31,366** (the 20-day high). **Wicks do not count.** |
| Ticket | $4,500 notional, 5x isolated ≈ **$900 margin** |
| Stop | 30,670 — 696 pts, 2.22% adverse |
| Target | 32,758 — 1,392 pts = **2R** |
| Risk | **$99.85 ≈ $100 = 1%** of a ~$10k book |
| Est. liq | ~28,258 (~3,108 pts adverse at 5x isolated) |
| Fees | $8.10 round trip = **4.1% of the gross target** — comfortably legal |

Pre-built any time with `python3 size.py --swing`. Blocked automatically if daily RSI > 78 or
funding > 0.05%/hr (never add swing risk in those conditions).

A swing position **survives 23:00**. It is a different thesis from a day trade — never run both
at once, and never let a day trade become a swing by accident.

### 1b. Day trade — the 16:45 range break (rule 2)

The only intraday setup. Nothing else is tradeable.

```
16:30-16:45 EAT   mark the HIGH and LOW of the first 5-minute range. DO NOT TRADE while it prints.
16:45 EAT         THE GATE.

LONG   entry = range_high + 5 pts   on a 1-MINUTE CLOSE beyond the edge
       stop  = range_low  - 10 pts
SHORT  entry = range_low  - 5 pts   on a 1-MINUTE CLOSE beyond the edge
       stop  = range_high + 10 pts

       stop_pts = range_width + 15          (always — both directions)
       target   = 2.0R minimum   (raised from 1.5R on 8 Oct 2026 — see §5)
       flat by 23:00 EAT. No exceptions.
```

A **touch is not a break.** A wick through the edge is not a break. The 1-minute candle must
**close** beyond the edge + the buffer.

`python3 gate.py --range-high <H> --range-low <L> --break long|short --last <px>` builds and
validates the whole thing.

---

## 2. Sizing (rule 3)

| | |
|---|---|
| Standard size | **$5,000** |
| Upsize to $7,500–10,000 | **only** if the range is ≤ **80 pts** *and* clean |
| HARD CAP | **$10,000** — no exceptions, no "just this once" |
| Day risk budget | **$40** total stop-loss cost for the day |
| If the stop costs more than the budget | **cut the size. NEVER widen the stop.** |

`size.py` clamps to the cap and auto-cuts size to fit the $40 budget, printing the replacement
notional. Maximum notional for a $40 budget is `40 × entry / stop_pts`:

| Range width | Stop pts | Max notional for $40 risk | Risk at $5,000 | Risk at $10,000 |
|---|---|---|---|---|
| 60 | 75 | $16,533 | $12.07 | $24.13 |
| 80 | 95 | $13,053 | $15.29 | $30.58 |
| 120 | 135 | $9,185 | $21.67 | $43.33 ⚠ |
| 150 | 165 | $7,515 | $26.61 | $53.23 ⚠ |

⚠ = over the $40 budget → `size.py` cuts it. Note the collision with rule 3: **the widest legal
ranges are also the ones where the $10,000 upsize breaks the risk budget**, while upsizing is only
permitted on the *narrowest* ranges. In practice $5,000–7,500 is the honest working band.

Leverage and margin: **set leverage before size.** 5x → $5,000 notional = $1,000 margin;
$10,000 = $2,000 margin. Isolated always.

---

## 3. SKIP conditions (rule 4)

Skip the session — do not negotiate — if any of these is true:

1. **Range > 150 pts wide.** A wide range means a wide stop means an unpayable target.
2. **Chop inside the range > 15 minutes.** No decision, no trade.
3. **Fees > 20% of target.** See §5 — this one is not what it looks like.
4. **Scheduled macro (FOMC / CPI / Fed) within 1 hour AND size would exceed $2,500.**
   Cap size at $2,500, or stand down. Be flat or breakeven+ **5 minutes BEFORE** the print.

A SKIP is a complete, successful outcome for the day. It is the plan working, not the plan failing.

---

## 4. Execution (rules 5, 6, 7)

- **Market or Limit only.** The "Running Time / Randomize" screen is **TWAP** — it exists for
  orders above ~1% of ADV (≈ $1.8M). A $5k ticket on TWAP gets chopped into worse fills.
- **Isolated margin ON, 5x.**
- **Reduce Only OFF for entries, ON for exits.**
- **TP and SL are sent with the entry, every time.**
- **A stop only counts once it rests in Open Orders.** A line on a chart is a wish.
- **One index position at a time** — XYZ100 *or* SPX, never both.
- **Never add to a loser.** Only reduce.
- Fees: taker 0.09% ≈ **$4.50 per $5k per side**, ≈ **$9 round trip**. Bake into every target.
- **Order-book walls are not stops.** A $1M+ level shown in the book vanishes on a headline.

---

## 5. The fee toll — a rule conflict, proven

This was found on 8 Oct 2026 while building `gate.py`, and it matters more than any single trade.

Rule 4 says **skip if fees exceed 20% of the target**. Rule 2 originally said the **target is 1.5R
minimum**. Rule 4 also says **skip if the range is wider than 150 pts**. Taken literally, those
three made the day trade untradeable:

```
round-trip fees  = 2 × 0.09% × notional
gross target     = R × stop_pts × notional / entry

fees / gross     = 2 × 0.09 × entry / (stop_pts × R)        <-- notional CANCELS
```

**The ratio is size-invariant.** Trading bigger does not improve it; it scales fees and profit
identically. Only two levers exist: a wider stop, or a bigger R.

At entry ≈ 31,000 (`fees/gross = 5,580 / (stop_pts × R)`):

| Range width | Stop pts | Fees % of a 1.5R target | Min R to clear 20% | Legal @1.5R | Legal @2R | Net PnL @1.5R on $5k |
|---|---|---|---|---|---|---|
| 30 | 45 | 82.7% | 6.20R | ✗ | ✗ | $1.89 |
| 60 | 75 | 49.6% | 3.72R | ✗ | ✗ | $9.15 |
| 80 | 95 | 39.2% | 2.94R | ✗ | ✗ | $13.98 |
| 100 | 115 | 32.3% | 2.43R | ✗ | ✗ | $18.82 |
| 120 | 135 | 27.6% | 2.07R | ✗ | ✗ | $23.66 |
| 130 | 145 | 25.7% | 1.92R | ✗ | ✓ | $26.08 |
| 140 | 155 | 24.0% | 1.80R | ✗ | ✓ | $28.50 |
| **150** | **165** | **22.5%** | **1.69R** | ✗ | ✓ | $30.92 |
| 186 | 201 | 18.5% | 1.39R | ✓ | ✓ | — |

The two hard boundaries:

- **At 1.5R the fee filter needs a 186-pt stop** — i.e. a **171-pt range**.
- **Rule 4's width cap allows at most a 165-pt stop** (150 + 5 + 10).
- **186 > 165. At 1.5R the two rules cannot both be satisfied, at any size, ever.**

The narrowest legal band is therefore **range 130–150 pts with a ≥1.92–2.0R target** — and that is
exactly the whippy, wide, post-headline condition the rest of the playbook tells you to avoid.
Note also the perverse incentive: rule 3 permits upsizing only on ranges **≤80 pts**, which is the
region where the fee toll is worst (39% at 1.5R).

The 7 Oct trade proves it empirically: $12,548 notional, +$51.14 gross, **$22.59 of fees** —
price R **+1.85R**, net R **+1.03R**. Fees took **44% of the gross** and **79% of the net**.

And the sharpest version of the same fact: **a $5,000 day ticket that hits exactly +1R nets
+0.64R.** Gross $24.88, fees $9.00, net $15.88. On the standard size, a perfect 1R execution
returns about two-thirds of an R. Anything below a ~0.6R average winner is a losing system after
costs, before the losing trades are even counted. `test_ops.py` pins this number.

### Three ways to resolve it — Option A was adopted on 8 Oct 2026

| Option | Change | Effect | Status |
|---|---|---|---|
| **A — raise the target** | `day.min_target_r: 2.0`, accept only 125–150 pt ranges | Keeps rule 4 exactly as written. Trades rarely, but every trade pays its toll. | ✅ **ADOPTED** |
| **B — re-read rule 4** | `day.fee_filter_basis: stop_risk` | Measures fees against the **dollars risked**, not the profit at target. $9 fees on $26.61 of risk = 34% → still tight on wide ranges, generous on narrow ones. | rejected |
| **C — re-read rule 4** | `day.fee_filter_basis: notional` | The literal cost of doing business: 0.18% round trip. Never blocks. Weakest protection. | rejected |

Under Option A the fee filter needs a **139.5-pt stop** at 2.0R and the width cap allows **165**, so
the legal band is a printed range of **125–150 pts** — a **~38% break-even win rate**, and a maximum
size of **$7,514–$8,551** before the $40 budget binds. Outside that band the answer is SKIP, which
will be most days. That is the point, not a defect.

`gate.py` reports all of it: the fee ratio, the basis in force, the minimum R that would clear the
filter at the current stop, and the structural conflict when it applies. It never silently picks
an interpretation for you.

**Size to the $40 budget, not to the cap.** On every legal (125–150 pt) range the budget binds
before the $10,000 cap does — the widest legal stop of 165 pts allows only $7,514.

### What the toll costs in win rate

`net_R = target_R − fee_drag`, where `fee_drag = 2 × taker × entry / stop_pts` — again
**size-invariant**. Break-even win rate = `1 / (1 + net_R)`. At entry ≈ 31,000:

| Range width | Stop pts | Fee drag | net R @1.5 | BE win rate @1.5 | net R @2.0 | BE @2.0 | Max size for $40 | Legal @2R |
|---|---|---|---|---|---|---|---|---|
| 60 | 75 | 0.74R | +0.76 | **57%** | +1.26 | 44% | $10,000 | ✗ |
| 80 | 95 | 0.59R | +0.91 | **52%** | +1.41 | 41% | $10,000 | ✗ |
| 100 | 115 | 0.49R | +1.01 | 50% | +1.51 | 40% | $10,000 | ✗ |
| 120 | 135 | 0.41R | +1.09 | 48% | +1.59 | 39% | $9,184 | ✗ |
| 130 | 145 | 0.38R | +1.12 | 47% | +1.62 | **38%** | $8,551 | ✓ |
| 150 | 165 | 0.34R | +1.16 | 46% | +1.66 | **38%** | $7,514 | ✓ |

A **$5,000** ticket that hits *exactly* +1R on a 60-pt range nets **+0.26R**. Below the break-even
column the system loses money while still winning trades. `scan.py` recomputes this table against
the live entry price every session.

### Reducing the toll legitimately

- **Enter with a limit order (maker 0.03%)** where the break allows it: maker-in / taker-out
  costs 0.12% instead of 0.18% — a third less drag. Never sacrifice the fill for it on a fast break.
- **Trade only when the target is far enough to pay.** That is what the filter is for.
- **Do not upsize to fix a fee ratio.** It is size-invariant. It cannot be fixed with size.

---

## 6. Session rhythm (EAT = Nairobi = UTC+3, no DST)

| EAT | Phase | Action |
|---|---|---|
| 16:20 | pre-open | Gate check: price vs 31,366, funding, OI, futures, 10Y. **Arm the ticket, do not send.** |
| 16:30–16:45 | range | Mark the 5-min H/L. **No trades while it prints.** Rising OI = whippy. |
| **16:45** | **gate** | **Break + hold → trade per rules. Chop or wide range → skip and walk away.** |
| 16:46–22:59 | managing | Partial / trail / time-stop. Decided **before** entry. |
| 23:00 | flat | **Flat.** Log fills, `journal.py debrief`, update `config/state.yaml`, commit, push. |

`gate.py` refuses to fire an entry verdict outside the gate window, and refuses everything after 23:00.

### Management (decide BEFORE entry)

- **+1R** → take half off and move the stop to breakeven, **or** hold the full size to target.
  Choose one before the entry, not during it.
- **Longs:** first target area 31,039–31,050 (prior supply); partial zone 31,080–31,100
  (resistance 1). Once +1R, trail under the 31,000 pivot — never back inside the range.
- **Shorts:** partial zone 30,900–30,918 (support 1); the day-long long thesis is dead below it.
- **Time stop:** no progress in 45 minutes → flat. Do not hope.
- **Never widen a stop.** Cut size instead.

---

## 7. Levels (re-check weekly — the 20-day-high gate moves)

| Zone | Level | Meaning |
|---|---|---|
| Swing gate | **31,366** | 20-day high — daily CLOSE above = long trigger |
| Resistance 1 | 31,080–31,100 | Pre-open breakdown + stall top — partial zone |
| Stall/supply | 31,039–31,050 | Prior intraday supply — first long target area |
| Pivot | 31,000 | Round number + breakout pivot |
| Support 1 | 30,900–30,918 | Prior base / entries — day-long thesis dead below |
| Support 2 | 30,850 | 7 Oct day low |
| Invalidation | 30,670 | Swing stop — thesis dead below |

Machine-readable: `config/levels.yaml` (`meta.as_of`). If `as_of` is more than 7 days old,
re-derive before trusting the gate.

---

## 8. Regime modifiers (advisory — never entry triggers)

| Signal | Threshold | Response |
|---|---|---|
| 10Y yield | ≥ **5.25%** | Tech headwind → smaller size, faster partials |
| Daily RSI | > **78** | Never add swing risk |
| Funding | > **0.05%/hr** | Never add swing risk |
| OI rising into the open | — | First 15 min are leveraged and whippy — let the range print |
| XYZ100 vs NQ futures | ~**0.7% under** | Triggers come from Liquid levels; futures give bias only |
| Minutes / CPI days | — | ±200–300 pt spikes in minutes. Flat or ≤$2,500, breakeven+ 5 min before |

**Quiver** is a regime filter (risk-on / neutral / risk-off for tech). It is **advisory only and
never an entry trigger.** No setup in this playbook is armed by Quiver.

---

## 9. The stack and who is allowed to do what

| Agent | Role | May place orders? | May move funds? |
|---|---|---|---|
| **Liquid** (`app.liquid.trade`) | Execution venue | — | — |
| **Claude + Co-Invest** (`https://coinvest.liquid.trade/mcp`) | Executor; every order needs a **Confirm** tap | ✅ | ❌ never |
| Co-Invest *Computer* server | Can auto-send within limits | ✅ | ❌ never — **avoid on macro days** |
| **Arena** | Strategist: gates, sizing, levels, journal review | ❌ cannot | ❌ cannot |
| **Quiver** | Regime filter, advisory | ❌ | ❌ |

Arena will never pretend to have placed an order. Anything it outputs is a ticket for a human to
confirm in the app.

---

## 10. Journal discipline

A trade does not exist until it is in `trades.csv` with a fill price.

```bash
python3 journal.py log   --date 2026-10-08 --side long --size 5000 \
                         --entry 31145 --stop 30990 --target 31455 --opened 16:47
python3 journal.py close --id 2 --exit 31300 --closed 18:20 --reason partial_at_1R
python3 journal.py summary          # stats, R proof, rule-violation scan
python3 journal.py debrief          # the 23:00 block
```

`journal.py` reports **two R numbers** and the gap between them:

- **price R** = `(exit − entry) / stop_pts` — pure geometry, what the chart shows.
- **R achieved** = `net PnL / planned risk` — after fees. **This is the number that counts.**

It auto-flags: `HARD_CAP_BREACH`, `DAY_RISK_BUDGET`, `TARGET_UNDER_MIN_R`, `NO_STOP_LOGGED`,
`FLAT_BY_2300_BREACH`, `EXIT_UNCONFIRMED`, `R_DIVERGENCE`, and rule-6 overlapping positions.
Flags are recomputed on every read, so fixing the underlying problem clears the flag.

**No stop logged → no R can be proven.** That is a feature.

---

## 11. Hard lessons (do not relearn these)

1. "Running Time / Randomize" is TWAP for $1.8M+ orders. A $5k ticket on TWAP gets chopped.
2. Set leverage before size. Margin = notional ÷ leverage.
3. Size creep kills: $12.5k makes every 100 pts = $40. Respect the cap.
4. Macro days: flat or ≤$2,500 with a breakeven+ stop 5 minutes before the print.
5. Order-book walls vanish on headlines. They are not stops.
6. Overnight holds mix swing and day theses. Bank day trades, re-enter clean.
7. A stop that is not in Open Orders is not a stop.
8. The fee toll is size-invariant. You cannot out-size a bad ratio.

---

*Educational material only — not financial advice. Leveraged perpetuals can liquidate fast.*

---

## 12. Scanning and prediction

```bash
python3 scan.py                # from config/state.yaml
python3 scan.py --live         # pull the tape first via liquid_feed.py
python3 scan.py --at 16:20     # pin the clock
python3 scan.py --brief        # prediction brief only
python3 scan.py --json         # machine-readable
```

`scan.py` produces seven sections: **regime scan** (advisory score with every contributor shown),
**zone map** (pts and % to every level), **swing projection** (distance to 31,366, funding cost of
holding, break-even win rate on the swing ticket), **feasibility band** (the table above, recomputed
at the live entry), **scenarios** (pre-computed LONG / SHORT / NO-BREAK tickets so 16:45 is a
lookup), **prediction brief**, and **what this scan cannot tell you**.

### It does not forecast price

Nothing here predicts direction, and the prediction brief says so. Every line in it is a
**conditional statement with a named falsifier** — "if the range prints 130–150 pts then a 2.0R
ticket is the only legal one, falsified by a printed range of 171+ pts". That is the honest form of
a prediction for a rule-based desk: it pre-computes the decision tree so the gate call is arithmetic
rather than opinion, and it tells you in advance what evidence would overturn each line.

### The dashboard — the same rules, on a screen

```bash
python3 dashboard.py            # http://localhost:8787
```

`dashboard.py` renders one page: the verdict, the ticket, the zone map, the fee-toll band, the
journal and the alerts. It is not a second implementation of the rules — `build_state()` calls
`gate.py`, `scan.py`, `size.py` and `journal.py` directly, so the screen cannot disagree with the
terminal. A replay clock (`--now`, or the "Replay clock" field on the page) freezes the session at
any minute, which is how the gate gets rehearsed before 16:45 instead of discovered during it.

The page is static and the browser talks only to this server. There is no order path and no venue
connection in it, and the test suite checks the source for both.

### Alerts — delivered as a paste block, because the desk runs chat-only

Five alerts are defined: **16:20** pre-open, **16:30** range starts printing, **16:45** the gate,
**22:45** fifteen minutes to the flat deadline, **23:00** flat. Each one renders as a block of text
to copy into Claude or Arena — nothing is sent anywhere, because no channel has been chosen and the
desk's stated use is the chat. A channel (email, Telegram, webhook) is a transport added later; the
block is the contract, so the wording does not change when the transport does.

### `liquid_feed.py` — the only networked file in the kit

Liquid is a HIP-3 market on Hyperliquid rails, so public data comes from
`POST https://api.hyperliquid.xyz/info` with `"dex": "xyz"`. The adapter fetches mark/oracle/mid,
24h change, hourly funding, open interest, 24h volume, the 5-minute candles over the range window
(**16:30–16:45 EAT = 13:30–13:45 UTC**), and optional L2 depth.

Safety properties, all enforced by `test_ops.py`:

- The **info endpoint only** — every URL literal in the file is that one string.
- Request types are **allowlisted**: `meta`, `allMids`, `metaAndAssetCtxs`, `candleSnapshot`,
  `l2Book`, `fundingHistory`. Anything else is refused *locally, before a packet is sent*.
- **No API keys, no wallet, no signing, no order/withdraw vocabulary.** It cannot mutate anything,
  because the endpoint it speaks to cannot.
- It **never infers your position or equity.** `state_patch()` emits
  `account.position_status: null` on purpose — those are read off the app by a human.
- The decision core (`gate.py`, `size.py`, `scan.py`, `journal.py`, `opslib.py`) is **network-free**
  and credential-free, verified by test.

> **Not verified against the live endpoint.** The sandbox that built this kit has no route to
> `api.hyperliquid.xyz` (confirmed: the connection is refused). The request and response shapes are
> written from the documented Hyperliquid info API but have **not** been executed live. Run
> `python3 liquid_feed.py --dry-run` to see the exact bodies, then `--probe` on your own machine and
> correct `parse_ctx()` if the schema differs. It fails loudly with exit `4` and never fabricates a
> price; `scan.py --live` falls back to `config/state.yaml` and says so.

---

## 13. Ambiguities — all four resolved 8 Oct 2026

Settled in `config/risk.yaml` → `decisions`, each with the rejected option and the reason recorded
alongside it. They stay documented here because every one of them changes tool behaviour, and the
reasoning is worth more than the setting.

| # | Ambiguity | Why it matters | Where to settle it |
|---|---|---|---|
| 1 | ~~**Which "DAILY CLOSE" fires rule 1?**~~ | **RESOLVED 8 Oct** → `us_cash`, the US cash close (~23:00 EAT): actionable while awake and consistent with flat-by-23:00. The venue's 1d roll at 00:00 UTC = **03:00 EAT** was rejected — it falls four hours *after* the flat deadline. | `swing.daily_close_ref` |
| 2 | ~~**"First 5-min range" vs a 16:30–16:45 window**~~ | **RESOLVED 8 Oct** → **15 minutes**, three 5m candles. "5-min" names the candle timeframe the window is built from, not the window length. | `day.range_window_minutes` |
| 3 | ~~**Rule 4's fee filter basis**~~ | **RESOLVED 8 Oct** → `gross_target`, the strictest reading, kept deliberately alongside the 2.0R minimum. See §5. | `day.fee_filter_basis` |
| 4 | ~~**Rule 2's 1.5R minimum vs the fee toll**~~ | **RESOLVED 8 Oct** → minimum raised to **2.0R**. Legal band: printed ranges of 125–150 pts. | `day.min_target_r` |

`scan.py` and `gate.py` read all four from config rather than guessing. Anything passed on the
command line overrides config for that run only.

---

## 14. The live tape and the backtest — decided 8 Oct 2026

The connection is read-only, and it runs without you during the session. A GitHub Action
(`.github/workflows/session-tape.yml`) pulls the public info endpoint every 15 minutes from
16:15 to 22:45 EAT, plus a 23:00 flat check, on weekdays, and commits `data/tape/latest.json`.
You still tap the order in the Liquid app. Nothing in this repo sends one, and no key is stored.

Two limits, stated so they are not discovered later:

- GitHub runs a schedule only on the default branch (`main`). Until this branch is merged, the
  job does not fire by itself. It can be run by hand from the Actions tab.
- Cron is UTC and can slip by minutes. This is a snapshot, not a tick. The 16:45 range may
  arrive a few minutes late. A late range is not a reason to trade a partial one.

`backtest.py` replays rule 2 on 1-minute candles. The fill is the next bar's open — you see the
close, then you tap. A bar that trades both stop and target is a stop. A 5-minute file is
refused, because the rule is a 1-minute close. Fewer than 30 taken trades is INSUFFICIENT,
never an edge. Macro days are not filtered out, which flatters the result.

```bash
python3 backtest.py --demo
python3 backtest.py --candles data/history/xyz100-1m.json
```

The history file is produced by the same Action (`job=history`), because this environment cannot
reach the venue. Liquid's event markets are a later, read-only project. They are not in this build.

---

*Educational material only — not financial advice. Leveraged perpetuals can liquidate fast.*
