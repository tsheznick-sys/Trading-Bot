#!/usr/bin/env python3
"""
journal.py — the trade log, the R-multiple proof, and the rule-violation scan.

A trade only counts once it is in trades.csv with a fill price. This script is
what turns "I think I made money" into "here is the R".

Usage
-----
  python3 journal.py show                       # the whole log
  python3 journal.py summary                    # stats + R proof + violation scan
  python3 journal.py summary --date 2026-10-07
  python3 journal.py debrief                    # the 23:00 Nairobi debrief block

  # open a leg
  python3 journal.py log --date 2026-10-08 --side long --setup range_break \\
      --size 5000 --entry 31057 --stop 30978 --target 31175.5 --opened 16:47

  # close it
  python3 journal.py close --id 2 --exit 31120 --closed 18:05 --reason target_partial \\
      --fees 9.00 --notes "half off at +1R, rest trailed"

  # confirm the still-open 7 Oct leg
  python3 journal.py close --id 1 --exit 31044 --closed 22:55 --reason flat_by_deadline

Exit codes: 0 ok, 1 bad input.

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
from datetime import datetime

from opslib import (
    EAT, JOURNAL_CSV, OpsConfig, hr, money, price, pts, risk_usd, session_clock,
    taker_fees_round_trip, units,
)

COLUMNS = [
    "id", "date", "opened_eat", "closed_eat", "session", "symbol", "side", "setup",
    "verdict", "size_usd", "leverage", "margin_usd", "entry", "stop", "stop_pts",
    "target", "target_r", "exit", "exit_reason", "pnl_usd", "fees_usd", "net_pnl_usd",
    "r_planned", "r_achieved", "status", "rule_flags", "notes",
]

STATUS_OPEN = "OPEN"
STATUS_UNCONFIRMED = "UNCONFIRMED"
STATUS_CLOSED = "CLOSED"

# Flag prefixes this script owns and recomputes on every read.
AUTO_FLAGS = (
    "HARD_CAP_BREACH", "DAY_RISK_BUDGET", "TARGET_UNDER_MIN_R", "NO_STOP_LOGGED",
    "FLAT_BY_2300", "EXIT_UNCONFIRMED", "R_DIVERGENCE", "OVERNIGHT_HOLD",
)


# --------------------------------------------------------------------------
def _to_f(x, default=None):
    try:
        if x is None or str(x).strip() == "":
            return default
        return float(x)
    except (TypeError, ValueError):
        return default


def read_trades(path: str = JOURNAL_CSV) -> list[dict]:
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    for r in rows:
        for c in COLUMNS:
            r.setdefault(c, "")
    return rows


def write_trades(rows: list[dict], path: str = JOURNAL_CSV) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in COLUMNS})


def next_id(rows) -> int:
    ids = [int(_to_f(r.get("id"), 0) or 0) for r in rows]
    return (max(ids) + 1) if ids else 1


# --------------------------------------------------------------------------
# Analysis
# --------------------------------------------------------------------------
def analyse(row: dict, cfg: OpsConfig) -> dict:
    """Compute the R-multiple proof and scan the row against the rulebook."""
    side = str(row.get("side", "")).lower()
    entry = _to_f(row.get("entry"))
    stop = _to_f(row.get("stop"))
    exit_ = _to_f(row.get("exit"))
    size = _to_f(row.get("size_usd"), 0.0)
    lev = _to_f(row.get("leverage"), float(cfg.get("execution.leverage", 5)))
    taker = float(cfg.get("venue.taker_fee_pct", 0.09))
    cap = float(cfg.get("day.hard_cap_usd", 10000))
    budget = float(cfg.get("day.day_risk_budget_usd") or cfg.get("day.day_risk_budget_usd", 40))
    min_r = float(cfg.get("day.min_target_r", 1.5))
    flat_by = str(cfg.get("session.flat_by", "23:00"))

    stop_pts = _to_f(row.get("stop_pts"))
    if stop_pts is None and entry and stop:
        stop_pts = abs(entry - stop)

    planned_risk = risk_usd(size, entry, stop_pts) if (size and entry and stop_pts) else None
    gross_pnl = None
    price_r = None
    if entry and exit_ and stop_pts:
        delta = (exit_ - entry) if side == "long" else (entry - exit_)
        gross_pnl = units(size, entry) * delta if size else None
        price_r = delta / stop_pts

    logged_pnl = _to_f(row.get("pnl_usd"))
    fees = _to_f(row.get("fees_usd"))
    if fees is None and size:
        fees = taker_fees_round_trip(size, taker)
    net_pnl = _to_f(row.get("net_pnl_usd"))
    if net_pnl is None and logged_pnl is not None and fees is not None:
        net_pnl = logged_pnl - fees
    elif net_pnl is None and gross_pnl is not None and fees is not None:
        net_pnl = gross_pnl - fees

    r_achieved = (net_pnl / planned_risk) if (net_pnl is not None and planned_risk) else None
    r_planned = _to_f(row.get("r_planned"))
    if r_planned is None:
        tgt = _to_f(row.get("target"))
        if tgt and entry and stop_pts:
            r_planned = abs(tgt - entry) / stop_pts

    # Auto-generated flags are recomputed every pass so a stale one cannot survive
    # a fix (e.g. EXIT_UNCONFIRMED must disappear once the exit is confirmed).
    stored = [f.strip() for f in str(row.get("rule_flags", "")).split(";") if f.strip()]
    flags = [f for f in stored if not f.startswith(AUTO_FLAGS)]

    def add(f):
        if f not in flags:
            flags.append(f)

    if size and size > cap:
        add(f"HARD_CAP_BREACH({money(size, 0)}>{money(cap, 0)})")
    if planned_risk and planned_risk > budget and str(row.get("setup", "")) != "swing":
        add(f"DAY_RISK_BUDGET({money(planned_risk)}>{money(budget, 0)})")
    if r_planned is not None and r_planned < min_r and str(row.get("setup", "")) != "swing":
        add(f"TARGET_UNDER_MIN_R({r_planned:.2f}<{min_r})")
    if not stop:
        add("NO_STOP_LOGGED")
    closed = str(row.get("closed_eat", "")).strip()
    if closed:
        try:
            hh, mm = [int(x) for x in closed.split(":")[:2]]
            if (hh, mm) > (23, 0):
                add(f"FLAT_BY_{flat_by.replace(':', '')}_BREACH({closed})")
        except ValueError:
            pass
    if str(row.get("status", "")).upper() == STATUS_UNCONFIRMED:
        add("EXIT_UNCONFIRMED")
    if r_achieved is not None and price_r is not None and abs(r_achieved - price_r) > 0.15:
        add(f"R_DIVERGENCE(price {price_r:.2f}R vs net {r_achieved:.2f}R — fees/slippage)")

    return {
        "stop_pts": stop_pts, "planned_risk": planned_risk, "gross_pnl": gross_pnl,
        "net_pnl": net_pnl, "fees": fees, "price_r": price_r, "r_achieved": r_achieved,
        "r_planned": r_planned, "flags": flags, "logged_pnl": logged_pnl,
        "is_open": str(row.get("status", "")).upper() in (STATUS_OPEN, STATUS_UNCONFIRMED),
    }


def overlapping_positions(rows) -> list[tuple]:
    """Rule 6 — one index position at a time. Flag any interval overlap."""
    spans = []
    for r in rows:
        if not str(r.get("opened_eat", "")).strip():
            continue
        spans.append((r.get("date", ""), r.get("opened_eat", ""),
                      r.get("closed_eat", "") or "99:99", r.get("id")))
    out = []
    for i in range(len(spans)):
        for j in range(i + 1, len(spans)):
            a, b = spans[i], spans[j]
            if a[0] == b[0] and a[1] < b[2] and b[1] < a[2]:
                out.append((a[3], b[3]))
    return out


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------
def cmd_log(cfg: OpsConfig, args) -> int:
    rows = read_trades(args.file)
    if not args.entry or not args.side:
        print("INPUT ERROR: --entry and --side are required")
        return 1
    stop_pts = abs(args.entry - args.stop) if args.stop else None
    size = args.size
    lev = args.leverage or float(cfg.get("execution.leverage", 5))
    risk = risk_usd(size, args.entry, stop_pts) if (size and stop_pts) else None
    fees = taker_fees_round_trip(size, float(cfg.get("venue.taker_fee_pct", 0.09))) if size else None
    r_planned = (abs(args.target - args.entry) / stop_pts) if (args.target and stop_pts) else None

    row = {
        "id": next_id(rows), "date": args.date, "opened_eat": args.opened or "",
        "closed_eat": "", "session": args.session or "day", "symbol": args.symbol or "XYZ100",
        "side": args.side, "setup": args.setup or "range_break", "verdict": args.verdict or "",
        "size_usd": f"{size:.2f}" if size else "", "leverage": f"{lev:g}",
        "margin_usd": f"{size / lev:.2f}" if size else "",
        "entry": f"{args.entry:.2f}", "stop": f"{args.stop:.2f}" if args.stop else "",
        "stop_pts": f"{stop_pts:.1f}" if stop_pts else "",
        "target": f"{args.target:.2f}" if args.target else "",
        "target_r": "", "exit": "", "exit_reason": "",
        "pnl_usd": "", "fees_usd": f"{fees:.2f}" if fees is not None else "",
        "net_pnl_usd": "", "r_planned": f"{r_planned:.2f}" if r_planned else "",
        "r_achieved": "", "status": STATUS_OPEN, "rule_flags": "", "notes": args.notes or "",
    }
    rows.append(row)
    write_trades(rows, args.file)
    print(hr(f"LOGGED #{row['id']}"))
    print(f"  {row['side'].upper()} {money(size or 0, 0)} {row['symbol']} @ {price(args.entry)}"
          f"  stop {price(args.stop) if args.stop else 'NONE'}"
          f" ({pts(stop_pts, 1) if stop_pts else 'n/a'})")
    r_txt = f"{r_planned:.2f}R" if r_planned else "n/a"
    print(f"  planned risk {money(risk) if risk else 'n/a'}   "
          f"fees RT {money(fees) if fees is not None else 'n/a'}   target {r_txt}")
    cap = float(cfg.get("day.hard_cap_usd", 10000))
    if size and size > cap:
        print(f"  X HARD CAP BREACH: {money(size, 0)} > {money(cap, 0)} — logged and flagged.")
    print(f"  Now put the stop in Open Orders. A chart drawing is not a stop.")
    print(hr())
    return 0


def cmd_close(cfg: OpsConfig, args) -> int:
    rows = read_trades(args.file)
    target = [r for r in rows if str(r.get("id")) == str(args.id)]
    if not target:
        print(f"INPUT ERROR: no trade with id {args.id}")
        return 1
    row = target[0]
    if getattr(args, "stop", None) is not None:
        row["stop"] = f"{args.stop:.2f}"
        if _to_f(row.get("entry")):
            row["stop_pts"] = f"{abs(_to_f(row['entry']) - args.stop):.1f}"
    if getattr(args, "target", None) is not None:
        row["target"] = f"{args.target:.2f}"
    if getattr(args, "size", None) is not None:
        lev = _to_f(row.get("leverage"), float(cfg.get("execution.leverage", 5))) or 5.0
        row["size_usd"] = f"{args.size:.2f}"
        row["margin_usd"] = f"{args.size / lev:.2f}"
        row["fees_usd"] = f"{taker_fees_round_trip(args.size, float(cfg.get('venue.taker_fee_pct', 0.09))):.2f}"
    if getattr(args, "opened", None):
        row["opened_eat"] = args.opened
    row["exit"] = f"{args.exit:.2f}" if args.exit is not None else row.get("exit", "")
    row["closed_eat"] = args.closed or row.get("closed_eat", "")
    row["exit_reason"] = args.reason or row.get("exit_reason", "")
    row["status"] = STATUS_CLOSED if args.exit is not None else row.get("status", STATUS_OPEN)
    if args.fees is not None:
        row["fees_usd"] = f"{args.fees:.2f}"
    if args.pnl is not None:
        row["pnl_usd"] = f"{args.pnl:.2f}"
    if args.notes:
        row["notes"] = (row.get("notes", "") + " | " + args.notes).strip(" |")
    if getattr(args, "status", None):
        row["status"] = args.status
    elif args.exit is None and not row.get("exit"):
        row["status"] = STATUS_UNCONFIRMED
    write_trades(rows, args.file)
    a = analyse(row, cfg)
    row["rule_flags"] = ";".join(a["flags"])
    row["r_achieved"] = f"{a['r_achieved']:.2f}" if a["r_achieved"] is not None else ""
    row["net_pnl_usd"] = f"{a['net_pnl']:.2f}" if a["net_pnl"] is not None else ""
    write_trades(rows, args.file)

    print(hr(f"CLOSED #{row['id']} — R PROOF"))
    print(f"  {row['side'].upper()} {money(_to_f(row.get('size_usd'), 0), 0)} @ {price(_to_f(row.get('entry'), 0))}"
          f" -> exit {price(_to_f(row.get('exit'), 0) or 0)} at {row.get('closed_eat', '?')} EAT")
    if a["stop_pts"]:
        print(f"  stop distance {pts(a['stop_pts'])}   planned risk {money(a['planned_risk'] or 0)}")
    if a["price_r"] is not None:
        print(f"  price R       {a['price_r']:+.2f}R  (pure geometry)")
    if a["gross_pnl"] is not None:
        print(f"  gross PnL     {money(a['gross_pnl'])}")
    print(f"  fees          {money(a['fees'] or 0)}")
    if a["net_pnl"] is not None:
        print(f"  net PnL       {money(a['net_pnl'])}")
    if a["r_achieved"] is not None:
        print(f"  R ACHIEVED    {a['r_achieved']:+.2f}R   (net PnL / planned risk — this is the number that counts)")
    if a["flags"]:
        print("  rule flags    " + ", ".join(a["flags"]))
    print(hr())
    return 0


def _stats(rows, cfg):
    an = [(r, analyse(r, cfg)) for r in rows]
    closed = [(r, a) for r, a in an if not a["is_open"] and a["net_pnl"] is not None]
    open_ = [(r, a) for r, a in an if a["is_open"]]
    wins = [x for x in closed if x[1]["net_pnl"] > 0]
    losses = [x for x in closed if x[1]["net_pnl"] <= 0]
    total_net = sum(x[1]["net_pnl"] for x in closed)
    total_fees = sum(x[1]["fees"] or 0 for x in closed)
    total_r = sum(x[1]["r_achieved"] for x in closed if x[1]["r_achieved"] is not None)
    gross_win = sum(x[1]["net_pnl"] for x in wins)
    gross_loss = abs(sum(x[1]["net_pnl"] for x in losses))
    return {
        "all": an, "closed": closed, "open": open_, "wins": wins, "losses": losses,
        "n": len(closed), "win_rate": (100.0 * len(wins) / len(closed)) if closed else None,
        "total_net": total_net, "total_fees": total_fees, "total_r": total_r,
        "avg_r": (total_r / len(closed)) if closed else None,
        "profit_factor": (gross_win / gross_loss) if gross_loss > 0 else None,
        "best": max((x[1]["net_pnl"] for x in closed), default=None),
        "worst": min((x[1]["net_pnl"] for x in closed), default=None),
    }


def cmd_show(cfg: OpsConfig, args) -> int:
    rows = read_trades(args.file)
    if not rows:
        print("trades.csv is empty.")
        return 0
    print(hr("TRADE LOG"))
    print(f"{'#':>2} {'date':<10} {'side':<5} {'size':>9} {'entry':>9} "
          f"{'stop':>9} {'exit':>9} {'net':>9} {'R':>7}  status")
    for r in rows:
        a = analyse(r, cfg)
        entry = _to_f(r.get("entry"))
        stop = _to_f(r.get("stop"))
        exit_ = _to_f(r.get("exit"))
        r_txt = f"{a['r_achieved']:+.2f}R" if a["r_achieved"] is not None else "-"
        net_txt = money(a["net_pnl"]) if a["net_pnl"] is not None else "-"
        print(f"{r.get('id', ''):>2} {r.get('date', ''):<10} {str(r.get('side', '')).upper():<5} "
              f"{money(_to_f(r.get('size_usd'), 0), 0):>9} "
              f"{(price(entry) if entry else '-'):>9} "
              f"{(price(stop) if stop else '-'):>9} "
              f"{(price(exit_) if exit_ else '-'):>9} "
              f"{net_txt:>9} {r_txt:>7}  {r.get('status', '')}")
    print(hr())
    return 0


def cmd_summary(cfg: OpsConfig, args) -> int:
    rows = read_trades(args.file)
    if args.date:
        rows = [r for r in rows if str(r.get("date", "")).startswith(args.date)]
    st = _stats(rows, cfg)
    title = f"SUMMARY {args.date}" if args.date else "SUMMARY (all trades)"
    print(hr(title))
    if not rows:
        print("  no trades logged for this filter")
        print(hr())
        return 0
    print(f"  trades logged      {len(rows)}   ({len(st['closed'])} closed, {len(st['open'])} open/unconfirmed)")
    if st["n"]:
        print(f"  win rate           {st['win_rate']:.0f}%  ({len(st['wins'])}W / {len(st['losses'])}L)")
        print(f"  net PnL            {money(st['total_net'])}")
        print(f"  total R            {st['total_r']:+.2f}R   (avg {st['avg_r']:+.2f}R per closed trade)")
        if st["profit_factor"] is not None:
            print(f"  profit factor      {st['profit_factor']:.2f}")
        print(f"  best / worst       {money(st['best'])} / {money(st['worst'])}")
        print(f"  fees paid          {money(st['total_fees'])}   "
              f"({100.0 * st['total_fees'] / abs(st['total_net']):.0f}% of net PnL)"
              if st["total_net"] else f"  fees paid          {money(st['total_fees'])}")
    print()
    print(hr("RULE-VIOLATION SCAN"))
    any_flag = False
    for r, a in st["all"]:
        if a["flags"]:
            any_flag = True
            print(f"  #{r.get('id')} {r.get('date')} {str(r.get('side', '')).upper()}: " + ", ".join(a["flags"]))
    overlaps = overlapping_positions(rows)
    if overlaps:
        any_flag = True
        for a_id, b_id in overlaps:
            print(f"  X RULE 6: #{a_id} and #{b_id} overlap — one index position at a time")
    if not any_flag:
        print("  clean — no rule breaches in this window")
    print()
    if st["open"]:
        print(hr("STILL OPEN / UNCONFIRMED"))
        for r, a in st["open"]:
            print(f"  #{r.get('id')} {r.get('date')} {str(r.get('side', '')).upper()} "
                  f"{money(_to_f(r.get('size_usd'), 0), 0)} @ {price(_to_f(r.get('entry'), 0))} "
                  f"— status {r.get('status')}. Confirm the fill in the app, then: "
                  f"python3 journal.py close --id {r.get('id')} --exit <price> --closed <HH:MM>")
        print()
    print(hr())
    return 0


def cmd_debrief(cfg: OpsConfig, args) -> int:
    clock = session_clock(cfg=cfg)
    rows = read_trades(args.file)
    today = [r for r in rows if str(r.get("date", "")).startswith(clock["date"])]
    st = _stats(today, cfg)
    allst = _stats(rows, cfg)

    print(hr(f"DEBRIEF — {clock['date']} {clock['hhmm']} EAT"))
    print(f"  session phase      {clock['phase']} ({clock['label']})")
    print(f"  flat deadline      {cfg.get('session.flat_by', '23:00')} EAT "
          f"({clock['minutes_to_flat']} min from now)" if clock["minutes_to_flat"] > 0
          else f"  flat deadline      PASSED — confirm you are flat")
    print()
    if today:
        print(f"  trades today       {len(today)}")
        if st["n"]:
            print(f"  net PnL today      {money(st['total_net'])}   ({st['total_r']:+.2f}R)")
            print(f"  win rate today     {st['win_rate']:.0f}%")
        print(f"  fees today         {money(st['total_fees'])}")
    else:
        print("  trades today       none logged — either a clean SKIP day (good) or the log is behind")
    print()
    if allst["n"]:
        print(f"  all-time           {allst['n']} closed, {allst['total_r']:+.2f}R, net {money(allst['total_net'])}")
    print()
    print(hr("THREE QUESTIONS (answer in notes)"))
    print("  1. Did I follow the plan, or did I improvise? (The R tells you, not the PnL.)")
    print("  2. Where did I give profit back? Which zone should have taken the partial?")
    print("  3. Which rule did I bend? Name it, then size down next session until it is clean.")
    print()
    print(hr("AFTER THE DEBRIEF"))
    print("  1. Update config/state.yaml (Part 3) — equity, position, last, funding, OI, macro")
    print("  2. Re-check config/levels.yaml if the 20-day-high gate moved (weekly)")
    print("  3. git add -A && git commit -m 'debrief <date>' && git push")
    print("  The prompt is only as good as its state.")
    print(hr())
    return 0


# --------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Trade journal + R-multiple proof.")
    ap.add_argument("--file", default=JOURNAL_CSV)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("log", help="append a new trade")
    p.add_argument("--date", required=True)
    p.add_argument("--opened", help="HH:MM EAT")
    p.add_argument("--closed")
    p.add_argument("--session", default="day")
    p.add_argument("--symbol", default="XYZ100")
    p.add_argument("--side", required=True, choices=["long", "short"])
    p.add_argument("--setup", default="range_break")
    p.add_argument("--verdict")
    p.add_argument("--size", type=float)
    p.add_argument("--leverage", type=float)
    p.add_argument("--entry", type=float, required=True)
    p.add_argument("--stop", type=float)
    p.add_argument("--target", type=float)
    p.add_argument("--notes", default="")

    p = sub.add_parser("close", help="fill the exit on a logged trade")
    p.add_argument("--id", required=True)
    p.add_argument("--exit", dest="exit", type=float)
    p.add_argument("--closed", help="HH:MM EAT")
    p.add_argument("--reason")
    p.add_argument("--pnl", type=float, help="venue-reported gross PnL (overrides the computed one)")
    p.add_argument("--fees", type=float)
    p.add_argument("--notes", default="")
    p.add_argument("--stop", type=float, help="fill in a stop that was never logged (needed to prove R)")
    p.add_argument("--target", type=float, help="fill in the target that was never logged")
    p.add_argument("--size", type=float, help="correct the notional from the actual fill")
    p.add_argument("--opened", help="fill in the entry time, HH:MM EAT")
    p.add_argument("--status", choices=[STATUS_CLOSED, STATUS_OPEN, STATUS_UNCONFIRMED])

    p = sub.add_parser("show", help="print the log")
    p = sub.add_parser("summary", help="stats + violation scan")
    p.add_argument("--date")
    p = sub.add_parser("debrief", help="the 23:00 debrief block")

    args = ap.parse_args(argv)
    # --date on summary lives on the subparser; normalise
    if not hasattr(args, "date"):
        args.date = None
    cfg = OpsConfig()

    if args.cmd == "log":
        return cmd_log(cfg, args)
    if args.cmd == "close":
        return cmd_close(cfg, args)
    if args.cmd == "show":
        return cmd_show(cfg, args)
    if args.cmd == "summary":
        return cmd_summary(cfg, args)
    if args.cmd == "debrief":
        return cmd_debrief(cfg, args)
    return 1


if __name__ == "__main__":
    sys.exit(main())
