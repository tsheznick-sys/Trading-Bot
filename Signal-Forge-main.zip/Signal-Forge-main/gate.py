#!/usr/bin/env python3
"""
gate.py — the machine gate check for Liquid XYZ100.

It does two jobs:
  1. VERIFIES the Part 1 inputs. Every [bracket] in the Master Prompt must be
     filled with a real number before a verdict is allowed. Missing inputs do not
     produce a guess — they produce "fill this in".
  2. RUNS THE GATE. Rules 1-7 are applied mechanically and the verdict is printed
     in the Master Prompt output format.

Usage
-----
  python3 gate.py                                  # read config/state.yaml, now()
  python3 gate.py --mode position                  # manage/check an open position
  python3 gate.py --mode debrief                   # end-of-day summary
  python3 gate.py --now 16:45                      # pin the EAT clock (testing)

  # Live at 16:45 — type the printed numbers straight off the app:
  python3 gate.py --range-high 31052 --range-low 30988 --break long --last 31057
  python3 gate.py --last 30996.5 --equity 9985 --flat

Exit codes: 0 = a trade is allowed, 2 = SKIP, 3 = inputs incomplete, 1 = error.

Educational tooling only — not financial advice. Leveraged perpetuals can liquidate fast.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta

from opslib import (
    EAT, OpsConfig, fee_filter_feasibility, hr, money, price, pts, session_clock, units,
)
import size as sizelib

# Part 1 of the Master Prompt, as a checklist. (label, state path, required_for)
PART1_INPUTS = [
    ("Equity $",                  "account.equity_usd",            "all"),
    ("Position status",           "account.position_status",       "all"),
    ("XYZ100 last",               "market.last",                   "all"),
    ("24h %",                     "market.change_24h_pct",         "bias"),
    ("Funding %/hr",              "market.funding_pct_per_hr",     "swing"),
    ("Open interest $",           "market.open_interest_usd",      "bias"),
    ("RSI (daily)",               "market.rsi_daily",              "swing"),
    ("First 5-min range H",       "range_5m.high",                 "day"),
    ("First 5-min range L",       "range_5m.low",                  "day"),
    ("Range width pts",           "range_5m.width_pts",            "day"),
    ("Chop minutes inside range", "range_5m.chop_minutes_inside",  "day"),
    ("NQ futures %",              "market.nq_futures_pct",         "bias"),
    ("10Y yield %",               "market.ten_year_yield_pct",     "bias"),
]

EXIT_OK, EXIT_ERROR, EXIT_SKIP, EXIT_INCOMPLETE = 0, 1, 2, 3


# --------------------------------------------------------------------------
# Input verification
# --------------------------------------------------------------------------
def verify_inputs(cfg: OpsConfig, need: str = "all") -> tuple[list, list]:
    """Return (filled, missing) for the Part 1 brackets."""
    filled, missing = [], []
    for label, path, scope in PART1_INPUTS:
        val = cfg.st(path)
        blank = (val is None or val == ""
                 or (isinstance(val, str) and val.upper().strip() in ("UNCONFIRMED", "TBC", "N/A", "NULL")))
        if blank:
            missing.append((label, path, scope))
        else:
            filled.append((label, path, val))
    return filled, missing


def render_inputs(cfg: OpsConfig) -> str:
    filled, missing = verify_inputs(cfg)
    out = [hr("PART 1 INPUT CHECK")]
    for label, path, val in filled:
        shown = money(val, 2) if isinstance(val, (int, float)) and "usd" in path else str(val)
        out.append(f"  [ok]      {label:<26} {shown}")
    for label, path, scope in missing:
        tag = "REQUIRED" if scope == "all" else scope
        out.append(f"  [MISSING] {label:<26} -> fill {path} in config/state.yaml   ({tag})")
    stale = cfg.st("meta.stale", False)
    conf = cfg.st("account.equity_confirmed_in_app", False)
    if stale:
        out.append("  [STALE]   meta.stale = true — these numbers are from a previous read")
    if not conf:
        out.append("  [STALE]   equity not confirmed in the app this session")
    out.append(hr())
    return "\n".join(out)


def apply_overrides(cfg: OpsConfig, args) -> bool:
    """Fold CLI numbers into the state so the input check reflects what was actually
    supplied this run. Returns True if anything was overridden (state is then 'live')."""
    touched = False
    m = cfg.state.setdefault("market", {})
    r = cfg.state.setdefault("range_5m", {})
    a = cfg.state.setdefault("account", {})
    if args.last is not None:
        m["last"] = args.last
        touched = True
    if args.equity is not None:
        a["equity_usd"] = args.equity
        a["equity_confirmed_in_app"] = True
        touched = True
    if args.flat:
        a["position_status"] = "FLAT"
        touched = True
    if args.position:
        a["position_status"] = str(args.position).upper()
        touched = True
    if args.range_high is not None:
        r["high"] = args.range_high
        r["printed"] = True
        touched = True
    if args.range_low is not None:
        r["low"] = args.range_low
        r["printed"] = True
        touched = True
    if r.get("high") is not None and r.get("low") is not None:
        r["width_pts"] = float(r["high"]) - float(r["low"])
    if args.chop is not None:
        r["chop_minutes_inside"] = args.chop
        touched = True
    if touched:
        cfg.state.setdefault("meta", {})["stale"] = False
    return touched


# --------------------------------------------------------------------------
# Macro calendar
# --------------------------------------------------------------------------
def macro_check(cfg: OpsConfig, now_eat: datetime) -> dict:
    blackout = int(cfg.get("day.macro_blackout_minutes", 60))
    events = cfg.get("events", []) or []
    hits = []
    for ev in events:
        if str(ev.get("status", "")).lower() != "scheduled":
            continue
        try:
            when = datetime.strptime(f"{ev['date']} {ev.get('time_eat', '00:00')}",
                                     "%Y-%m-%d %H:%M").replace(tzinfo=EAT)
        except (KeyError, ValueError):
            continue
        delta_min = (when - now_eat).total_seconds() / 60.0
        if -30 <= delta_min <= blackout:
            hits.append({"event": ev.get("name"), "when": when.strftime("%d %b %H:%M EAT"),
                         "minutes": delta_min})
    return {"blackout_minutes": blackout,
            "max_size_usd": float(cfg.get("day.macro_max_size_usd", 2500)),
            "hits": hits, "blocked": bool(hits)}


# --------------------------------------------------------------------------
# Levels
# --------------------------------------------------------------------------
def nearest_zone(cfg: OpsConfig, px: float) -> str | None:
    if px is None:
        return None
    best, best_d = None, 1e9
    for z in cfg.get("zones", []) or []:
        for key in ("level", "low", "high"):
            v = z.get(key)
            if v is None:
                continue
            d = abs(float(v) - float(px))
            if d < best_d:
                best_d, best = d, f"{z.get('name')} @ {price(float(v))} — {z.get('meaning', '')}"
    return f"{best} ({best_d:.0f} pts away)" if best and best_d < 400 else None


# --------------------------------------------------------------------------
# The gate
# --------------------------------------------------------------------------
class Verdict:
    def __init__(self, kind: str, reason: str, code: int = EXIT_SKIP, title: str = "THE GATE"):
        self.kind = kind            # LONG | SHORT | SKIP | WAIT | BLOCKED | HOLD-CHECK | DEBRIEF
        self.title = title
        self.reason = reason
        self.code = code
        self.ticket = None
        self.management: list[str] = []
        self.flip: list[str] = []   # exact conditions that would change the verdict
        self.notes: list[str] = []

    def render(self, cfg: OpsConfig, clock: dict) -> str:
        out = [hr(f"{self.title} — {clock['hhmm']} EAT  {clock['date']}  ({clock['phase']})")]
        out.append(f"VERDICT: {self.kind} — {self.reason}")
        out.append("")
        if self.ticket:
            t = self.ticket
            out.append("Ticket")
            out.append(f"  entry      {price(t['entry'])}   ({t['side'].lower()} on a 1-min close beyond the edge +5 pts)")
            out.append(f"  stop       {price(t['stop'])}   {pts(t['stop_pts'])} = {t['stop_pct']:.2f}%")
            out.append(f"  size       {money(t['size_usd'], 0)} notional   ({t['units']:.4f} units = {money(t['usd_per_point'])}/pt)")
            out.append(f"  margin     {money(t['margin_usd'])} @ {t['leverage']:.0f}x ISOLATED")
            out.append(f"  risk       {money(t['risk_usd'])}   (budget {money(t['day_risk_budget_usd'], 0)}/day)")
            out.append(f"  target     {price(t['target'])}   {pts(t['target_pts'])} = {t['r_multiple']:.2f}R"
                       f"  -> net {money(t['net_target_usd'])} ({t['net_r_multiple']:.2f}R) after {money(t['fees_round_trip_usd'])} fees")
            out.append(f"  est. liq   {price(t['est_liq_price'])}   (~{pts(t['est_liq_pts'], 0)} adverse)")
            out.append("")
        if self.management:
            out.append("Management")
            for m in self.management:
                out.append(f"  - {m}")
            out.append("")
        if self.notes:
            out.append("Read")
            for n in self.notes:
                out.append(f"  . {n}")
            out.append("")
        if self.ticket and self.ticket["warnings"]:
            out.append("Warnings")
            for w in self.ticket["warnings"]:
                out.append(f"  ! {w}")
            out.append("")
        if self.ticket and self.ticket["blocks"]:
            out.append("Blocked by")
            for b in self.ticket["blocks"]:
                out.append(f"  X {b}")
            out.append("")
        if self.kind not in ("LONG", "SHORT", "DEBRIEF", "HOLD-CHECK"):
            out.append("What would change this")
            if not self.flip:
                self.flip = ["Nothing in this session — the plan is to stand down."]
            for f in self.flip:
                out.append(f"  > {f}")
            out.append("")
        out.append(hr())
        return "\n".join(out)


def std_management(cfg: OpsConfig, t: dict) -> list[str]:
    zones = cfg.get("zones", []) or []
    z = {str(x.get("name")): x for x in zones}
    m = []
    one_r = t["entry"] + t["stop_pts"] if t["side"] == "LONG" else t["entry"] - t["stop_pts"]
    m.append(f"DECIDE BEFORE ENTRY: at +1R ({price(one_r)}) take half and stop to breakeven, "
             f"or hold the full size to {t['r_multiple']:.1f}R ({price(t['target'])}). Pick one now.")
    if t["side"] == "LONG":
        r1 = z.get("resistance_1", {})
        sup = z.get("stall_supply", {})
        piv = z.get("pivot", {})
        if r1:
            m.append(f"Partial zone: {price(float(r1.get('low', 0)))}-{price(float(r1.get('high', 0)))} "
                     f"(resistance 1) — sell into strength, do not chase it.")
        if sup:
            m.append(f"First target area: {price(float(sup.get('low', 0)))}-{price(float(sup.get('high', 0)))} "
                     f"(prior intraday supply).")
        if piv:
            m.append(f"Trail: once +1R, move the stop under the {price(float(piv.get('level', 0)))} pivot; "
                     f"never back inside the range.")
    else:
        s1 = z.get("support_1", {})
        piv = z.get("pivot", {})
        if s1:
            m.append(f"Partial zone: {price(float(s1.get('low', 0)))}-{price(float(s1.get('high', 0)))} "
                     f"(support 1) — the day-long long thesis dies below it.")
        if piv:
            m.append(f"Trail: once +1R, move the stop above the {price(float(piv.get('level', 0)))} pivot.")
    m.append(f"Time stop: no progress in {int(cfg.get('day.time_stop_minutes', 45))} minutes -> flat, "
             f"do not hope. Never widen the stop; cut size instead.")
    m.append("Hard flat by 23:00 EAT. No exceptions, no overnight mixing of theses.")
    m.append("A stop only counts once it rests in Open Orders. Chart drawings are not stops.")
    return m


def run_gate(cfg: OpsConfig, clock: dict, args) -> Verdict:
    d = cfg.get("day", {})
    sw = cfg.get("swing", {})
    gate_px = float(sw.get("gate_price", 31366))

    last = args.last if args.last is not None else cfg.st("market.last")
    equity = args.equity if args.equity is not None else cfg.st("account.equity_usd")
    pos_status = (args.flat and "FLAT") or (args.position if args.position else cfg.st("account.position_status"))
    r_high = args.range_high if args.range_high is not None else cfg.st("range_5m.high")
    r_low = args.range_low if args.range_low is not None else cfg.st("range_5m.low")
    chop = args.chop if args.chop is not None else (cfg.st("range_5m.chop_minutes_inside") or 0)
    brk = args.break_side

    # ---- 0. inputs --------------------------------------------------------
    filled, missing = verify_inputs(cfg)
    hard_missing = [m for m in missing if m[2] == "all"]
    if not args.flat and (pos_status is None or str(pos_status).upper() == "UNCONFIRMED"):
        v = Verdict("BLOCKED",
                    "position status is UNCONFIRMED — rule 6 (one index position at a time) cannot be verified",
                    EXIT_INCOMPLETE)
        v.flip = [
            "Open the app, read the Positions tab, then set account.position_status to FLAT / LONG / SHORT "
            "in config/state.yaml (or pass --flat / --position long).",
            "If the 7 Oct long is STILL open, today is manage-only: no new entries at all.",
        ]
        v.notes = ["The 7 Oct long ($12,548 @ 30,918) is the single biggest unknown in this gate."]
        return v
    if last is None or equity is None:
        v = Verdict("BLOCKED", "last price and/or equity are missing — no verdict on blank inputs", EXIT_INCOMPLETE)
        v.flip = [f"Fill {p} in config/state.yaml" for _, p, _ in hard_missing] or ["Fill the Part 1 brackets."]
        return v

    zone = nearest_zone(cfg, last)
    macro = macro_check(cfg, clock["now_eat"])

    # ---- 1. open position blocks everything -------------------------------
    if str(pos_status).upper() in ("LONG", "SHORT"):
        v = Verdict("SKIP", f"a {str(pos_status).upper()} index position is already open — rule 6: one at a time",
                    EXIT_SKIP)
        v.notes = ["Manage the open position; do not stack a second index trade (XYZ100 or SPX, never both).",
                   "Never add to a loser. Bank day trades and re-enter clean at the next gate."]
        v.flip = ["Flat the existing position, then re-run the gate."]
        return v

    # ---- 2. session -------------------------------------------------------
    if clock["phase"] == "range":
        v = Verdict("WAIT", f"{clock['hhmm']} EAT — the first 5-min range is still PRINTING; no trades until 16:45",
                    EXIT_SKIP)
        v.notes = [f"Mark the H/L of the 16:30-16:45 window. {clock['minutes_to_gate']} min to the gate.",
                   "Rising OI into the open makes the first 15 minutes leveraged and whippy — let it print."]
        v.flip = [f"16:45 EAT with a printed range -> re-run: gate.py --range-high H --range-low L --break long|short"]
        return v
    if clock["phase"] == "pre-open":
        v = Verdict("WAIT", f"{clock['hhmm']} EAT — pre-open: ARM the ticket, do not send it", EXIT_SKIP)
        v.notes = [f"Last {price(last)} vs the swing gate {price(gate_px)} "
                   f"({100.0 * (gate_px / last - 1):+.2f}% away on a DAILY CLOSE).",
                   f"Session: {clock['label']}."]
        if zone:
            v.notes.append(f"Nearest zone: {zone}")
        v.flip = ["16:45 EAT gate with a printed 5-min range."]
        return v
    if clock["phase"] == "flat":
        v = Verdict("SKIP", f"{clock['hhmm']} EAT is past the 23:00 flat deadline — the day trade window is closed",
                    EXIT_SKIP)
        v.flip = ["Tomorrow's 16:20 pre-open gate check."]
        v.notes = ["Log fills and run: python3 journal.py debrief"]
        return v

    # ---- 3. swing gate (rule 1) -------------------------------------------
    daily_close = args.daily_close
    if daily_close is not None and float(daily_close) > gate_px:
        t = sizelib.build_swing_ticket(cfg, close_price=float(daily_close), gate_triggered=True)
        v = Verdict("LONG", f"DAILY CLOSE {price(float(daily_close))} above the {price(gate_px)} swing gate (rule 1)",
                    EXIT_OK if t["legal"] else EXIT_SKIP)
        v.ticket = t
        v.management = [
            f"Take the partial into {price(float((cfg.get('zones') or [{}])[0].get('level', 0)))} strength zones; "
            "trail under the prior daily low, not intraday noise.",
            "This is a SWING ticket — it survives 23:00. Do not mix it with a day trade in the same session.",
            f"Stop {price(t['stop'])} must rest in Open Orders. Risk {money(t['risk_usd'])} = {t['risk_pct_equity']:.2f}% of equity.",
        ]
        if not t["legal"]:
            v.kind = "SKIP"
            v.code = EXIT_SKIP
        return v

    # ---- 4. day gate (rule 2) ---------------------------------------------
    if clock["phase"] != "managing" or clock["minutes"] < clock["range_end"]:
        pass  # fallthrough

    if r_high is None or r_low is None:
        v = Verdict("SKIP", "the first 5-min range has not been supplied — a range break needs a printed range",
                    EXIT_INCOMPLETE)
        v.notes = [f"Last {price(last)}; session {clock['phase']} ({clock['label']})."]
        if zone:
            v.notes.append(f"Nearest zone: {zone}")
        v.flip = [
            "Read the 16:30 and 16:45 EAT extremes off the 5-min chart, then run:",
            "  python3 gate.py --range-high <H> --range-low <L> --break long|short --last <price>",
        ]
        return v

    r_high, r_low = float(r_high), float(r_low)
    width = r_high - r_low
    skip_wide = float(d.get("skip_range_wider_than_pts", 150))
    skip_chop = float(d.get("skip_chop_inside_range_minutes", 15))

    if width > skip_wide:
        v = Verdict("SKIP", f"range {pts(width, 0)} is wider than the {skip_wide:.0f}-pt limit (rule 4)", EXIT_SKIP)
        v.notes = [f"Range {price(r_low)}-{price(r_high)}. A wide range means a wide stop means an unpayable target."]
        v.flip = [f"A range of {skip_wide:.0f} pts or less at the next session — or stand down for the day."]
        return v
    if float(chop) > skip_chop:
        v = Verdict("SKIP", f"{chop:.0f} min of chop inside the range > the {skip_chop:.0f}-min limit (rule 4)", EXIT_SKIP)
        v.flip = [f"Chop inside the range under {skip_chop:.0f} minutes with a clean 1-min close beyond an edge."]
        return v
    if brk not in ("long", "short"):
        v = Verdict("SKIP", "no 1-min CLOSE beyond a range edge yet — a touch is not a break", EXIT_SKIP)
        v.notes = [f"Range {price(r_low)}-{price(r_high)} = {pts(width, 0)}.",
                   f"Long trigger: a 1-min close above {price(r_high + float(d.get('entry_buffer_pts', 5)))}.",
                   f"Short trigger: a 1-min close below {price(r_low - float(d.get('entry_buffer_pts', 5)))}.",
                   f"Last {price(last)}." + (f" Nearest zone: {zone}" if zone else "")]
        v.flip = ["A 1-min candle CLOSES beyond an edge (+/-5 pts) -> re-run with --break long or --break short."]
        return v

    # macro blackout caps size (rule 4)
    size_override = args.size
    if macro["blocked"]:
        cap = macro["max_size_usd"]
        if size_override is None or size_override > cap:
            size_override = cap
        note = (f"Macro inside {macro['blackout_minutes']} min: {macro['hits'][0]['event']} "
                f"({macro['hits'][0]['when']}) — size capped at {money(cap, 0)}, "
                "flat or breakeven+ 5 min before the print.")
    else:
        note = None

    try:
        t = sizelib.build_day_ticket(cfg, brk, r_high, r_low, size_override, args.r, last)
    except sizelib.TicketBlocked as exc:
        v = Verdict("SKIP", str(exc), EXIT_SKIP)
        v.flip = ["A range edge that produces a legal bracket."]
        return v

    if note:
        t["warnings"].insert(0, note)

    if not t["legal"]:
        v = Verdict("SKIP", f"the {brk.upper()} bracket fails rule 4 — see Blocked by", EXIT_SKIP)
        v.ticket = t
        feas = fee_filter_feasibility(
            t["entry"], float(d.get("min_target_r", 1.5)),
            float(d.get("skip_range_wider_than_pts", 150)),
            float(d.get("entry_buffer_pts", 5)), float(d.get("stop_buffer_pts", 10)),
            float(d.get("skip_fee_pct_of_target", 20)),
            float(cfg.get("venue.taker_fee_pct", 0.09)),
        )
        v.flip = [
            f"A target of {t['min_r_for_fee_filter']:.1f}R or better at this {t['stop_pts']:.0f}-pt stop "
            f"(re-run with --r {t['min_r_for_fee_filter']:.1f} to see the ticket), or",
            "flip day.fee_filter_basis in config/risk.yaml to stop_risk or notional if that is the "
            "intended reading of rule 4.",
        ]
        v.notes = [
            f"Range {price(r_low)}-{price(r_high)} = {pts(width, 0)}; break to the {brk.upper()}.",
            "RULE CONFLICT (structural, not about this trade): at the {r:.1f}R minimum, rule 4's fee filter "
            "needs a stop of {need:.0f} pts, but rule 4's {wide:.0f}-pt width cap only allows {allow:.0f} pts "
            "(= {wide:.0f} + 5 + 10). {verdict} The fee ratio is size-invariant, so no ticket size fixes it. "
            "Minimum target that can clear both at the widest legal range: {minr:.2f}R "
            "(needs a range of at least {rng:.0f} pts).".format(
                r=feas["r_multiple"], need=feas["stop_pts_needed"], wide=float(d.get("skip_range_wider_than_pts", 150)),
                allow=feas["stop_pts_allowed"], minr=feas["min_r_at_max_range"],
                rng=feas["stop_pts_allowed"] * feas["min_r_at_max_range"] * 0 + max(
                    (2.0 * 0.09 * t["entry"]) / (20.0 * feas["min_r_at_max_range"]) - 15.0, 0.0),
                verdict=("These two rules cannot both be satisfied." if not feas["feasible"]
                         else "These can both be satisfied, but only in a narrow band."),
            ),
        ]
        return v

    v = Verdict(brk.upper(), f"1-min close beyond the {brk} edge of the {pts(width, 0)} range (rule 2)",
                EXIT_OK)
    v.ticket = t
    v.management = std_management(cfg, t)
    v.notes = [f"Range {price(r_low)}-{price(r_high)} = {pts(width, 0)}"
               + (f"; clean-range upsizing allowed (<= {float(d.get('clean_range_max_pts', 80)):.0f} pts)"
                  if width <= float(d.get("clean_range_max_pts", 80)) else "") + ".",
               f"Last {price(last)}." + (f" Nearest zone: {zone}" if zone else ""),
               f"Liquid prints ~{float(cfg.get('limits.liquid_tracks_nq_discount_pct', 0.7)):.1f}% under NQ futures — "
               "use these Liquid levels for triggers, futures for bias only."]
    return v


# --------------------------------------------------------------------------
# Position / debrief modes
# --------------------------------------------------------------------------
def run_position(cfg: OpsConfig, clock: dict, args) -> Verdict:
    op = cfg.state.get("open_position", {}) or {}
    mkt = cfg.state.get("market", {}) or {}
    notional = args.notional if args.notional is not None else op.get("notional_usd")
    entry = args.entry if args.entry is not None else op.get("entry")
    side = args.side or op.get("side") or "long"
    mark = args.mark if args.mark is not None else mkt.get("last")

    if not notional or not entry:
        v = Verdict("BLOCKED", "no open position data — pass --notional/--entry or fill open_position in state.yaml",
                    EXIT_INCOMPLETE)
        v.flip = ["Confirm the position in the app, then re-run."]
        return v

    notional, entry = float(notional), float(entry)
    u = units(notional, entry)
    pnl = None
    if mark:
        delta = (float(mark) - entry) if side == "long" else (entry - float(mark))
        pnl = u * delta

    v = Verdict("HOLD-CHECK", f"{side.upper()} {money(notional, 0)} @ {price(entry)}", EXIT_OK,
                title="POSITION CHECK")
    v.notes = [
        f"units {u:.4f} -> {money(u)} per point; every 100 pts = {money(u * 100)}.",
    ]
    if pnl is not None:
        v.notes.append(f"mark {price(float(mark))} -> PnL {money(pnl)} ({100.0 * (float(mark) / entry - 1):+.2f}% price).")
    last_pnl = op.get("last_pnl_usd")
    if last_pnl is not None and pnl is not None:
        v.notes.append(f"last logged PnL {money(float(last_pnl))} at {op.get('last_pnl_at_eat', '?')} EAT "
                       f"(implied {price(float(op.get('implied_price_at_last_pnl', 0)))}) -> "
                       f"give-back since {money(pnl - float(last_pnl))}.")

    cap = float(cfg.get("day.hard_cap_usd", 10000))
    if notional > cap:
        v.notes.append(f"X HARD CAP BREACH: {money(notional, 0)} > {money(cap, 0)} (rule 3) — "
                       f"{100.0 * (notional / cap - 1):.0f}% oversize. Never add to it; only reduce.")
    for viol in op.get("violations", []) or []:
        v.notes.append(f"! {viol}")

    zones = {str(z.get("name")): z for z in cfg.get("zones", []) or {}}
    sup = zones.get("support_1", {})
    inv = zones.get("invalidation", {})
    zone_map = ", ".join(
        "{} {}".format(k, price(float(vv.get("level") or vv.get("low") or 0)))
        for k, vv in zones.items() if vv.get("level") or vv.get("low")
    )
    v.management = [
        f"Zone map: {zone_map}.",
        f"If this is a DAY position: flat by 23:00 EAT, no exceptions ({clock['minutes_to_flat']} min left).",
        f"Day-long thesis is dead below support_1 {price(float(sup.get('low', 30900)))}-{price(float(sup.get('high', 30918)))}.",
        f"Swing invalidation {price(float(inv.get('level', 30670)))} — if this is the swing thesis, that stop must rest in Open Orders.",
        "Bank day trades and re-enter clean at the next gate; overnight holds mix swing and day theses.",
    ]
    if op.get("exists") == "UNCONFIRMED":
        v.flip = ["CONFIRM IN THE APP whether this position is still open, then set "
                  "account.position_status and open_position.exists in config/state.yaml."]
        v.kind = "BLOCKED"
        v.code = EXIT_INCOMPLETE
    return v


def run_debrief(cfg: OpsConfig, clock: dict, args) -> Verdict:
    try:
        import journal
        rows = journal.read_trades()
    except Exception as exc:  # pragma: no cover
        rows, exc_msg = [], str(exc)
    else:
        exc_msg = None

    v = Verdict("DEBRIEF", f"{clock['date']} — end of session review", EXIT_OK, title="DEBRIEF")
    if exc_msg:
        v.notes = [f"journal read failed: {exc_msg}"]
        return v
    today = [r for r in rows if str(r.get("date", "")).startswith(clock["date"])]
    v.notes = [
        f"{len(rows)} trade(s) in trades.csv; {len(today)} dated {clock['date']}.",
        "Run `python3 journal.py summary` for the R-multiple proof and rule-violation scan.",
    ]
    flat_now = (args.flat is True)
    v.management = [
        "Log every fill: python3 journal.py log ...",
        "Close the open leg: python3 journal.py close --id <n> --exit <price> --closed <HH:MM> --reason <why>",
        "Prove the R: python3 journal.py summary",
        "Then update config/state.yaml Part 3 + commit + push. The prompt is only as good as its state.",
    ]
    if clock["minutes"] < clock["flat_by"] and not flat_now:
        v.management.insert(0, f"Still {clock['minutes_to_flat']} min to the 23:00 flat deadline.")
    return v


# --------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Machine gate check for Liquid XYZ100.")
    ap.add_argument("--mode", default="gate", choices=["gate", "position", "debrief"])
    ap.add_argument("--state", default=None, help="path to state.yaml")
    ap.add_argument("--now", default=None, help="pin the EAT clock, HH:MM (testing)")
    ap.add_argument("--last", type=float, help="XYZ100 last price")
    ap.add_argument("--equity", type=float)
    ap.add_argument("--flat", action="store_true", help="assert FLAT (no open position)")
    ap.add_argument("--position", choices=["long", "short", "LONG", "SHORT"], help="assert an open position")
    ap.add_argument("--range-high", dest="range_high", type=float)
    ap.add_argument("--range-low", dest="range_low", type=float)
    ap.add_argument("--break", dest="break_side", choices=["long", "short"],
                    help="a 1-min CLOSE beyond this edge")
    ap.add_argument("--chop", type=float, help="minutes of chop inside the range")
    ap.add_argument("--size", type=float, help="notional override")
    ap.add_argument("--r", type=float, help="target R multiple")
    ap.add_argument("--daily-close", dest="daily_close", type=float,
                    help="the DAILY CLOSE print (swing trigger — wicks do not count)")
    # position mode
    ap.add_argument("--side", default=None, choices=["long", "short"])
    ap.add_argument("--notional", type=float)
    ap.add_argument("--entry", type=float)
    ap.add_argument("--mark", type=float)
    ap.add_argument("--show-inputs", action="store_true", help="print the Part 1 input check")
    args = ap.parse_args(argv)

    cfg = OpsConfig(state_path=args.state)
    apply_overrides(cfg, args)
    now = None
    if args.now:
        base = datetime.now(EAT)
        hh, mm = args.now.split(":")
        now = base.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    clock = session_clock(now, cfg)

    if args.show_inputs or args.mode == "gate":
        print(render_inputs(cfg))
        print()

    if args.mode == "position":
        v = run_position(cfg, clock, args)
    elif args.mode == "debrief":
        v = run_debrief(cfg, clock, args)
    else:
        v = run_gate(cfg, clock, args)

    print(v.render(cfg, clock))
    return v.code


if __name__ == "__main__":
    sys.exit(main())
