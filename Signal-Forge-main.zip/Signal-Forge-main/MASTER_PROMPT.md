# MASTER PROMPT — Liquid Trading Ops (Quiver × Liquid × Claude × Arena)

Everything from the trading chat, distilled into ONE paste-ready prompt.

Paste **Part 1** into any AI (Claude + Co-Invest to execute, Arena to strategize), fill the
bracketed variables with live numbers, and it will operate exactly per this playbook.
**Part 2** is the standing context the AI must assume. **Part 3** is today's state (update daily).

> The machine-readable twin of this file lives in `config/`. When Part 3 changes, change
> `config/state.yaml` too — `gate.py` reads that, not this markdown.
>
> **Educational material only — not financial advice. Leveraged perpetuals can liquidate fast.**

| How this repo serves the Master Prompt | |
|---|---|
| `MASTER_PROMPT.md` (this file) | The brain — paste Part 1 anywhere |
| `RUNBOOK-US-OPEN.md` | The 4-minute checklist version |
| `PLAYBOOK.md` | Full rule reference + the fee-toll finding |
| `dashboard.py` | The session screen — same rules as the CLI, rendered. Places no orders |
| `scan.py` | **Market scan + prediction brief** — regime, zone map, feasibility band, scenarios |
| `liquid_feed.py` | Read-only live data adapter (Hyperliquid info API, `dex=xyz`) — the only file that touches the network |
| `backtest.py` | Replays the written day-trade rulebook on 1-minute candles. Allowed to say the rules lose |
| `gate.py` | Machine gate check (verifies Part 1 inputs, then rules 1–7) |
| `size.py` | Ticket math (enforces the $10k cap and the $40/day risk budget) |
| `journal.py` | Log + R-multiple proof + rule-violation scan |
| `opslib.py` | Shared config loader, EAT session clock, perp math |
| `claude_gate.md` | Executor-flavored brief (Claude + Co-Invest) |
| `arena_brief.md` | Strategist-flavored brief (Arena) |
| `config/risk.yaml` | Machine-readable risk rules |
| `config/levels.yaml` | Machine-readable XYZ100 zones |
| `config/macro.yaml` | Scheduled macro calendar (rule 4 blackout) |
| `config/state.yaml` | **Part 3, machine-readable — update every session** |
| `trades.csv` | The journal |
| `test_ops.py` | 194 invariants, including the math pinned to the desk's own numbers |

---

## PART 1 — PASTE THIS (fill the `[brackets]`)

```text
You are my trading-ops brain for Nasdaq-100 perpetuals on Liquid (Hyperliquid HIP-3).

ACCOUNT & STATE (I fill these every session):
- Equity: $[____] | Position: [FLAT | LONG/SHORT size/entry/PnL]
- Session: [pre-open 16:20 | range 16:30-45 | gate 16:45 | managing | debrief 23:00] Nairobi time
- XYZ100 last: [____] | 24h%: [____] | Funding/hr: [____] | OI: [____]
- First 5-min range H/L: [____/____ or "not printed"] | Width: [____ pts or n/a]
- NQ futures: [____%] | 10Y: [____] | Known macro today: [____]

RULES YOU MUST ENFORCE (never soften these):
1. Swing LONG only on DAILY CLOSE above $31,366. Wicks don't count. Ticket: $4,500,
   5x isolated (~$900 margin), SL $30,670, TP $32,758 (2R). Risk $100 (1%).
2. Day trade = 16:30-16:45 5m range break only. Entry = 1-min close beyond edge +5 pts.
   Stop = opposite edge -/+10 pts. Target 2.0R min. Flat by 23:00 Nairobi. No exceptions.
3. Size: $5,000 standard. $7,500-10,000 ONLY if range <=80 pts and clean. HARD CAP $10,000.
   Day risk budget $40. Never widen a stop - cut size instead.
4. SKIP if: range >150 pts wide; chop inside range >15 min; fees >20% of target;
   scheduled macro (FOMC/CPI/Fed) within 1h and size would exceed $2,500.
5. Execution: Market/Limit ONLY. Never TWAP/Running Time under $1M notional.
   Isolated ON, 5x, Reduce Only OFF for entries / ON for exits, TP/SL ALWAYS set.
   A stop only counts if it rests in Open Orders - chart drawings are not stops.
6. One index position at a time (XYZ100 or SPX, never both). Never add to a loser.
7. Taker fee 0.09% (~$4.50 per $5k side, ~$9 round trip) - bake into every target.

YOUR OUTPUT FORMAT (every gate call):
- VERDICT: LONG / SHORT / SKIP + 1-line reason
- Ticket: entry, stop (pts + %), size USD, margin, risk USD, target, est. liq
- Management: where to trail, where to partial, time stop
- If SKIP: exact condition that would change it

Now: [RUN THE GATE / CHECK MY POSITION / DEBRIEF MY DAY - delete as applicable]
```

**Or run it locally instead of pasting it:**

```bash
python3 scan.py                                        # market scan + prediction brief (run at 16:20)
python3 scan.py --live                                 # pull the tape via liquid_feed.py first
python3 gate.py                                        # verifies Part 1 inputs, then runs the gate
python3 gate.py --now 16:45 --flat \
    --range-high 31052 --range-low 30988 --break long --last 31057
python3 gate.py --mode position                        # check/manage the open position
python3 gate.py --mode debrief                         # end of day
python3 size.py --swing                                # the armed swing ticket
python3 size.py --range --high 31140 --low 31000 --side long   # 2.0R is now the enforced minimum
python3 journal.py summary                             # R proof + violation scan
```

Exit codes: `0` a trade is allowed · `2` SKIP · `3` inputs incomplete · `1` error.

---

## PART 2 — STANDING CONTEXT (the AI assumes all of this)

### The stack

- **Liquid** (`app.liquid.trade`, **NOT** `.com`) = execution venue. **XYZ100** = Nasdaq-100 perp,
  cash-settled, USDC margin, no expiry, hourly funding, up to 30x, trades 24/7.
  Maker 0.03% / taker 0.09%. HIP-3 market via the `xyz` dex on Hyperliquid rails.
- **Quiver** = regime filter (risk-on / neutral / risk-off for tech). **Advisory only, never an entry trigger.**
- **Claude + Co-Invest** = executor. Standard server `https://coinvest.liquid.trade/mcp`
  (every order needs a **Confirm** tap). The Computer server can auto-send within limits —
  **avoid on macro days.** Co-Invest can read + trade but **NEVER** withdraw or move funds.
- **Arena** = strategist: gates, sizing, levels, journal review. **Cannot place orders.**

### Reference zones (Liquid XYZ100 levels, Oct 2026 — re-check weekly)

| Zone | Level | Meaning |
|---|---|---|
| Swing gate | **31,366** | 20-day high — daily CLOSE above = long trigger |
| Resistance 1 | 31,080–31,100 | Pre-open breakdown + stall top — partial zone |
| Stall/supply | 31,039–31,050 | Prior intraday supply — first long target area |
| Pivot | 31,000 | Round number + breakout pivot |
| Support 1 | 30,900–30,918 | Prior base / entries — day-long thesis dead below |
| Support 2 | 30,850 | 7 Oct day low |
| Invalidation | 30,670 | Swing stop — thesis dead below |

Machine-readable copy: `config/levels.yaml`.

### Standing market facts (learned, durable)

- Liquid XYZ100 tracks **~0.7% UNDER** NQ futures consistently — always use Liquid's own levels
  for triggers, futures only for bias.
- **Rising OI into the open** = leveraged, whippy first 15 min. Let the range print.
- **10Y ≥ 5.25%** = tech headwind: smaller size, faster partials.
- **RSI > 78 or funding > 0.05%/hr** = never add swing risk.
- Perp math: `units = notional ÷ entry price`, so PnL = `units × Δpoints`. A 1% move = 1% of notional.
  Verified three ways — see `opslib.py` header.

### Session rhythm (Nairobi = EAT = UTC+3; US open 16:30, close 23:00)

| EAT | What happens |
|---|---|
| 16:20 | Gate check (price vs 31,366, funding, OI, futures, yields). **Arm the ticket, don't send.** |
| 16:30–16:45 | Mark H/L of the first 5-min range. **No trades while printing.** |
| **16:45** | **THE GATE:** break + hold = trade per rules; chop/wide range = skip + walk away. |
| Live | Decide **BEFORE** entry: at +1R take half + stop to breakeven, or hold full to target. |
| 23:00 latest | **Flat.** Log fills, run journal summary, debrief. |

### Hard lessons from the desk (do not relearn these)

1. The **"Running Time / Randomize"** screen is **TWAP** (for >1% of ADV ≈ $1.8M orders).
   A $5k ticket on TWAP gets chopped — always switch to Market/Limit.
2. **Set leverage BEFORE size**; margin = notional ÷ leverage (5x → $5k = $1,000 margin).
3. **Size creep kills:** a $12.5k position makes every 100 pts = $40. Respect the cap.
4. **FOMC/CPI days:** be flat or ≤$2,500 with a breakeven+ stop **5 min BEFORE** the print.
   Minutes-days spike ±200–300 pts in minutes.
5. **Order-book walls** ($1M+ shown) vanish on headlines — they are not stops.
6. **Overnight holds mix swing/day theses** — bank day trades, re-enter clean at the next gate.
7. **The fee toll (proven 8 Oct — the reason rule 2 now says 2.0R).** Round-trip taker fees are
   `0.18% × notional` and the gross target is `R × stop_pts × notional ÷ entry`, so
   `fees ÷ gross = 2 × taker × entry ÷ (stop_pts × R)` — **notional cancels, the ratio is
   size-invariant.** At ~31,000 a **1.5R** target needs a **186-pt stop** for fees to be 20% of it,
   but a 150-pt range only permits **165 pts** (150+5+10). **186 > 165: at 1.5R rules 2 and 4 were
   mutually unsatisfiable, at any size, on any day.** Raising the minimum to **2.0R** needs only a
   139-pt stop and opens a real legal band of **125–150 pt ranges** at a **~38% break-even win
   rate**. Full derivation: `PLAYBOOK.md` §5.

---

## PART 3 — CURRENT STATE (update after every session)

**Machine-readable copy: `config/state.yaml` — update that file, it is what `gate.py` reads.**

```
Date:        8 Oct 2026, pre-open (~16:26 Nairobi)
Account:     ~$9,985 ref (7 Oct) — CONFIRM in app, update here + config/risk.yaml
Position:    7 Oct long $12,548 @ 30,918 (+$51.14 at 18:45) — EXIT UNCONFIRMED, update from app
Last seen:   XYZ100 $30,996.50 (+0.04%), OI $269.7M, funding +0.0006%, NQ fut -0.57%
Macro:       hawkish FOMC minutes 7 Oct (one more 2026 hike hinted); Oct hike ~19%;
             CPI 14 Oct; Fed meeting 27-28 Oct; 10Y ~5.28%; oil elevated; Asia red
Swing gate:  ARMED but unlikely today (needs +1.2% daily close to 31,366)
Journal:     trades.csv seeded with the 7 Oct trade (exit/PnL TBC)
```

### Open items carried into today

| # | Item | Why it matters | Clear it with |
|---|---|---|---|
| 1 | **7 Oct long exit UNCONFIRMED** | Rule 6 allows one index position at a time. Until this is confirmed FLAT, no new entry can be authorised at all. | Read the Positions tab → `journal.py close --id 1 …` and set `account.position_status` |
| 2 | **Equity not re-read** | Sizing and the 1% swing risk are computed off a 7 Oct reference of $9,985 | Confirm in app → `account.equity_confirmed_in_app: true` |
| 3 | **7 Oct ticket was $12,548** | 25% over the $10,000 hard cap — every 100 pts = $40 | Already flagged in `trades.csv`; do not repeat |
| 4 | **No stop logged on the 7 Oct trade** | Without a stop distance there is no R to prove | `journal.py close --id 1 --stop <price>` |
### Resolved 8 Oct 2026 — logged in `config/risk.yaml` → `decisions`

| # | Question | Decision | Effect |
|---|---|---|---|
| 5 | Rule 4's fee filter basis | **`gross_target`** — fees as a % of the profit at the target | Strictest reading, kept deliberately. The filter still bites; it is now satisfiable |
| 6 | Which "DAILY CLOSE" fires rule 1? | **`us_cash`** — the US cash close, ~23:00 EAT | Actionable while awake, consistent with flat-by-23:00. Rejected the venue 1d roll at 00:00 UTC = 03:00 EAT |
| 7 | "First 5-min range" vs a 16:30–16:45 window | **15 minutes** — three 5m candles | "5-min" names the candle *timeframe*, not the window length |
| 8 | Rule 2's 1.5R minimum vs the fee toll | **Raised to `min_target_r: 2.0`** | Legal band = printed ranges of 125–150 pts, ~38% break-even win rate, max size $7,514–8,551. Outside it: SKIP |
| 6 | **Which "DAILY CLOSE" fires rule 1?** | The venue's 1d candle rolls at 00:00 UTC = **03:00 EAT** — four hours *after* the 23:00 flat deadline. A venue-close trigger can only be evaluated while you are asleep, and entering on it breaches flat-by-23:00 by construction. The US cash close (~23:00 EAT) is the one you can act on. | Set `swing.daily_close_ref` in `config/risk.yaml` |
| 7 | **"First 5-min range" vs a 16:30–16:45 window** | That window is **15 minutes** (three 5m candles), not five. The H/L differs materially between the two readings. | Set `day.range_window_minutes` (15 or 5) in `config/risk.yaml` |

### Update ritual (after every session, ~5 min)

```bash
python3 journal.py close --id <n> --exit <price> --closed <HH:MM> --reason <reason>
python3 journal.py debrief
# edit config/state.yaml (Part 3) with the fresh numbers
git add -A && git commit -m "debrief 8 Oct: <one line>" && git push
```

**The prompt is only as good as its state.**

---

*Educational material only — not financial advice. Leveraged perpetuals can liquidate fast.*
