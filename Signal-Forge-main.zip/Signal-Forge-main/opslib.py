"""
opslib.py — shared plumbing for the Liquid Trading Ops kit.

Used by gate.py, size.py and journal.py. No third-party dependencies:
a small YAML-subset parser is bundled so the kit runs on a bare Python 3.8+.

Contains:
  * load_config()      — YAML-subset loader for config/*.yaml
  * OpsConfig          — dotted access into the merged config
  * session_clock()    — Nairobi (EAT, UTC+3, no DST) session phase
  * ticket math        — units(), risk_usd(), fees(), liq_price()
  * fmt helpers        — money(), pts()

MATH MODEL (verified against three independent facts in the Master Prompt):
  XYZ100 is a linear perp quoted in index points. Position size in units is
      units = notional_usd / entry_price
  so PnL = units * delta_points, i.e. a 1% price move = 1% of notional.

  Proof points:
    swing  $4,500 @ 31,366, SL 30,670 -> stop 696 pts
           units = 4500/31366 = 0.14347 -> risk = 0.14347*696 = $99.85 ~= "Risk $100 (1%)"
    swing  TP 32,758 = entry + 2*696   -> "(2R)"
    lesson "$12.5k position makes every 100 pts = $40"
           units = 12548/30918 = 0.4059 -> 100 pts = $40.59 ~= $40

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

REPO_ROOT = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(REPO_ROOT, "config")
JOURNAL_CSV = os.path.join(REPO_ROOT, "trades.csv")

EAT = timezone(timedelta(hours=3), "EAT")  # Nairobi — no DST, fixed UTC+3


# --------------------------------------------------------------------------
# YAML subset parser
# --------------------------------------------------------------------------
def _split_top(s: str):
    """Split on commas that are not inside brackets or quotes."""
    out, buf, depth, quote = [], "", 0, None
    for ch in s:
        if quote:
            buf += ch
            if ch == quote:
                quote = None
            continue
        if ch in "\"'":
            quote = ch
            buf += ch
        elif ch in "[{":
            depth += 1
            buf += ch
        elif ch in "]}":
            depth -= 1
            buf += ch
        elif ch == "," and depth == 0:
            out.append(buf)
            buf = ""
        else:
            buf += ch
    if buf.strip():
        out.append(buf)
    return [x.strip() for x in out]


def _strip_comment(line: str) -> str:
    quote = None
    for i, ch in enumerate(line):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
        elif ch == "#" and (i == 0 or line[i - 1] in " \t"):
            return line[:i]
    return line


def _coerce(s: str):
    s = s.strip()
    if not s:
        return None
    if len(s) >= 2 and s[0] in "\"'" and s[-1] == s[0]:
        return s[1:-1]
    low = s.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if low in ("null", "none", "~"):
        return None
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        return [] if not inner else [_coerce(x) for x in _split_top(inner)]
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s


def _is_inline_map_item(rest: str) -> bool:
    """Is `- <rest>` the start of a map ("- name: pivot") or just a scalar
    ("- held past 23:00 EAT")? Quoted strings and text with a space before the
    first colon are scalars — otherwise "23:00" inside a sentence would be
    parsed as a key."""
    if rest.startswith("[") or not rest:
        return False
    if len(rest) >= 2 and rest[0] in "\"'" and rest.endswith(rest[0]):
        return False
    if ":" not in rest:
        return False
    head = rest.split(":", 1)[0]
    return " " not in head.strip()


def _parse_block(lines, i: int, indent: int):
    """Parse lines[i:] at the given indent. Returns (value, next_index)."""
    # Detect list vs map from the first significant line
    while i < len(lines):
        ind, content = lines[i]
        if content == "":
            i += 1
            continue
        break
    if i >= len(lines) or ind < indent:
        return None, i

    if content.startswith("- "):
        return _parse_list(lines, i, ind)
    return _parse_map(lines, i, ind)


def _parse_list(lines, i: int, indent: int):
    out = []
    while i < len(lines):
        ind, content = lines[i]
        if content == "":
            i += 1
            continue
        if ind < indent:
            break
        if ind > indent:  # continuation handled by child parse
            i += 1
            continue
        if not content.startswith("- "):
            break
        rest = content[2:].strip()
        i += 1
        if rest == "":
            child, i = _parse_block(lines, i, indent + 1)
            out.append(child)
        elif _is_inline_map_item(rest):
            # inline map start: "- name: x" plus deeper keys
            key, _, val = rest.partition(":")
            item = {key.strip(): _coerce(val)}
            child_indent = indent + 2
            while i < len(lines):
                ind2, c2 = lines[i]
                if c2 == "":
                    i += 1
                    continue
                if ind2 < child_indent or c2.startswith("- "):
                    break
                k2, _, v2 = c2.partition(":")
                i += 1
                if v2.strip() == "":
                    sub, i = _parse_block(lines, i, ind2 + 1)
                    item[k2.strip()] = sub
                else:
                    item[k2.strip()] = _coerce(v2)
            out.append(item)
        else:
            out.append(_coerce(rest))
    return out, i


def _parse_map(lines, i: int, indent: int):
    out = {}
    while i < len(lines):
        ind, content = lines[i]
        if content == "":
            i += 1
            continue
        if ind < indent:
            break
        if ind > indent:
            i += 1
            continue
        if content.startswith("- "):
            break
        if ":" not in content:
            i += 1
            continue
        key, _, val = content.partition(":")
        key = key.strip()
        val = val.strip()
        i += 1
        if val == "":
            child, i = _parse_block(lines, i, indent + 1)
            out[key] = child if child is not None else {}
        else:
            out[key] = _coerce(val)
    return out, i


def parse_yaml(text: str):
    lines = []
    for raw in text.splitlines():
        raw = raw.replace("\t", "    ")
        stripped = _strip_comment(raw).rstrip()
        if stripped.strip() == "":
            lines.append((0, ""))
            continue
        indent = len(stripped) - len(stripped.lstrip(" "))
        lines.append((indent, stripped.strip()))
    value, _ = _parse_block(lines, 0, 0)
    return value if value is not None else {}


def load_yaml_file(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return parse_yaml(fh.read())


def _deep_merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class OpsConfig:
    """Merged view over config/*.yaml with dotted lookup."""

    def __init__(self, config_dir: str = CONFIG_DIR, state_path: str | None = None):
        self.config_dir = config_dir
        self.data: dict = {}
        for name in ("risk.yaml", "levels.yaml", "macro.yaml"):
            p = os.path.join(config_dir, name)
            if os.path.exists(p):
                self.data = _deep_merge(self.data, load_yaml_file(p) or {})
        self.state_path = state_path or os.path.join(config_dir, "state.yaml")
        self.state = {}
        if os.path.exists(self.state_path):
            self.state = load_yaml_file(self.state_path) or {}

    def get(self, dotted: str, default=None):
        node = self.data
        for part in dotted.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default
        return node

    def st(self, dotted: str, default=None):
        node = self.state
        for part in dotted.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default
        return node


# --------------------------------------------------------------------------
# Session clock (Nairobi / EAT)
# --------------------------------------------------------------------------
def _hhmm_to_min(s: str) -> int:
    h, m = str(s).split(":")[:2]
    return int(h) * 60 + int(m)


def session_clock(now_eat: datetime | None = None, cfg: OpsConfig | None = None) -> dict:
    now = now_eat or datetime.now(EAT)
    if now.tzinfo is None:
        now = now.replace(tzinfo=EAT)
    now = now.astimezone(EAT)
    mins = now.hour * 60 + now.minute

    s = (cfg.get("session") if cfg else None) or {}
    pre = _hhmm_to_min(s.get("pre_open_gate", "16:20"))
    r_start = _hhmm_to_min(s.get("range_print_start", "16:30"))
    r_end = _hhmm_to_min(s.get("range_print_end", "16:45"))
    flat = _hhmm_to_min(s.get("flat_by", "23:00"))

    if mins < pre:
        phase, label = "pre-open", "before the 16:20 gate check"
    elif mins < r_start:
        phase, label = "pre-open", "gate check window — arm the ticket, do NOT send"
    elif mins < r_end:
        phase, label = "range", "PRINTING the first 5-min range — no trades"
    elif mins == r_end:
        phase, label = "gate", "THE GATE — decide now"
    elif mins < flat:
        phase, label = "managing", "live management — partial/trail/flat by 23:00"
    else:
        phase, label = "flat", "past 23:00 — must be FLAT, run the debrief"

    return {
        "now_eat": now,
        "hhmm": now.strftime("%H:%M"),
        "date": now.strftime("%Y-%m-%d"),
        "minutes": mins,
        "phase": phase,
        "label": label,
        "pre_open": pre,
        "range_start": r_start,
        "range_end": r_end,
        "flat_by": flat,
        "minutes_to_gate": r_end - mins,
        "minutes_to_flat": flat - mins,
        "range_printed": mins >= r_end,
        "trading_allowed": r_end <= mins < flat,
    }


# --------------------------------------------------------------------------
# Ticket math
# --------------------------------------------------------------------------
def units(notional_usd: float, price: float) -> float:
    """XYZ100 linear-perp units: 1 unit = $1 per index point."""
    return float(notional_usd) / float(price)


def pnl_usd(notional_usd: float, entry: float, mark: float, side: str) -> float:
    u = units(notional_usd, entry)
    delta = (mark - entry) if side.lower() == "long" else (entry - mark)
    return u * delta


def risk_usd(notional_usd: float, entry: float, stop_pts: float) -> float:
    return units(notional_usd, entry) * stop_pts


def stop_pts_from_prices(entry: float, stop: float, side: str) -> float:
    return (entry - stop) if side.lower() == "long" else (stop - entry)


def taker_fees_round_trip(notional_usd: float, taker_pct: float = 0.09, sides: int = 2) -> float:
    return notional_usd * (taker_pct / 100.0) * sides


def fee_pct_of_gross_target(notional_usd: float, entry: float, stop_pts: float,
                            r_multiple: float, taker_pct: float = 0.09) -> float:
    """Round-trip taker fees as a % of the GROSS profit at the target.

    Size-invariant: scaling notional scales fees and profit identically,
    so only the stop distance and the R multiple can fix a bad ratio.
    """
    gross = units(notional_usd, entry) * stop_pts * r_multiple
    if gross <= 0:
        return float("inf")
    return 100.0 * taker_fees_round_trip(notional_usd, taker_pct) / gross


def min_r_for_fee_filter(entry: float, stop_pts: float, max_fee_pct: float = 20.0,
                        taker_pct: float = 0.09) -> float:
    """Smallest R multiple whose GROSS profit keeps round-trip fees <= max_fee_pct.

        fees/gross = 2*(taker/100)*entry / (stop_pts * R)   ->   R_min = 2*taker*entry / (max_fee * stop_pts)

    Size-invariant, so the only levers are a wider stop or a bigger R target.
    """
    if stop_pts <= 0:
        return float("inf")
    return (2.0 * taker_pct * entry) / (max_fee_pct * stop_pts)


def fee_filter_feasibility(entry: float, r_multiple: float, max_range_pts: float,
                           entry_buffer_pts: float = 5.0, stop_buffer_pts: float = 10.0,
                           max_fee_pct: float = 20.0, taker_pct: float = 0.09) -> dict:
    """Can rule 2 (1.5R minimum) and rule 4 (fees <=20% of target, range <=150 pts)
    BOTH be satisfied at once? The fee ratio is size-invariant, so this is pure
    geometry — it does not depend on the ticket size at all.

        fees/gross = 2*taker*entry / (stop_pts * R)
        -> stop_pts_min = 2*taker*entry / (max_fee_pct * R)
        -> stop_pts_max = max_range_pts + entry_buffer + stop_buffer   (rule 4 width cap)
    """
    stop_min = (2.0 * taker_pct * entry) / (max_fee_pct * r_multiple)
    stop_max = max_range_pts + entry_buffer_pts + stop_buffer_pts
    range_min = stop_min - entry_buffer_pts - stop_buffer_pts
    return {
        "entry": entry,
        "r_multiple": r_multiple,
        "stop_pts_needed": stop_min,
        "stop_pts_allowed": stop_max,
        "range_pts_needed": range_min,
        "range_pts_allowed": max_range_pts,
        "feasible": stop_min <= stop_max,
        "min_r_at_max_range": (2.0 * taker_pct * entry) / (max_fee_pct * stop_max),
    }


def max_notional_for_risk(entry: float, stop_pts: float, risk_budget_usd: float) -> float:
    """Largest notional whose stop loss costs no more than risk_budget_usd."""
    if stop_pts <= 0:
        return 0.0
    return risk_budget_usd * entry / stop_pts


def liq_price(entry: float, side: str, leverage: float = 5.0,
              maintenance_fraction: float = 0.5, fee_pct: float = 0.09) -> float:
    """Approximate isolated-margin liquidation price.

    Hyperliquid-style: maintenance margin = maintenance_fraction * initial margin.
    Adverse move to liquidation ~= (1/lev) * (1 - maintenance_fraction), minus an
    allowance for the entry fee. Approximation only — the venue is the truth.
    """
    adverse = (1.0 / leverage) * (1.0 - maintenance_fraction) - (fee_pct / 100.0)
    adverse = max(adverse, 0.0)
    return entry * (1 - adverse) if side.lower() == "long" else entry * (1 + adverse)


# --------------------------------------------------------------------------
# Formatting
# --------------------------------------------------------------------------
def money(x: float, dp: int = 2) -> str:
    sign = "-" if x < 0 else ""
    return f"{sign}${abs(x):,.{dp}f}"


def pts(x: float, dp: int = 1) -> str:
    return f"{x:,.{dp}f} pts"


def price(x: float) -> str:
    return f"{x:,.2f}"


def hr(title: str = "", width: int = 78) -> str:
    if not title:
        return "-" * width
    pad = max(width - len(title) - 2, 3)
    return f"-- {title} " + "-" * pad
