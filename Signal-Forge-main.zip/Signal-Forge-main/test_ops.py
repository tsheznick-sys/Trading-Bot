#!/usr/bin/env python3
"""
test_ops.py — invariants for the Liquid Trading Ops kit.

Run: python3 test_ops.py          (also works under pytest)

The important tests are the first three: they pin the perp math to numbers the
desk has already stated independently, so a refactor cannot silently change the
meaning of "risk $100" or "every 100 pts = $40".

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import ast
import json
import math
import os
import re
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from opslib import (  # noqa: E402
    OpsConfig, fee_filter_feasibility, fee_pct_of_gross_target, liq_price,
    max_notional_for_risk, min_r_for_fee_filter, parse_yaml, pnl_usd,
    risk_usd, session_clock, taker_fees_round_trip, units, EAT,
)
import journal  # noqa: E402
import size as sizelib  # noqa: E402
import scan as scanlib  # noqa: E402
import liquid_feed as feed  # noqa: E402

from datetime import datetime  # noqa: E402

CFG = OpsConfig()
FAILURES: list[str] = []


def check(name: str, cond: bool, detail: str = ""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILURES.append(name)


def near(a, b, tol=0.02):
    return abs(a - b) <= tol


# --------------------------------------------------------------------------
def test_perp_math_is_pinned_to_the_desks_own_numbers():
    print("\n[1] perp math vs the desk's stated numbers")
    # "$4,500, 5x isolated, SL 30,670 ... Risk $100 (1%)" with the gate at 31,366
    stop_pts = 31366 - 30670
    check("swing stop is 696 pts", stop_pts == 696, f"got {stop_pts}")
    check("swing risk ~= $100", near(risk_usd(4500, 31366, stop_pts), 99.85, 0.5),
          f"got {risk_usd(4500, 31366, stop_pts):.2f}")
    check("swing risk is ~1% of a $10k book",
          near(100.0 * risk_usd(4500, 31366, stop_pts) / 9985.0, 1.0, 0.05))
    # "TP $32,758 (2R)"
    check("swing target is exactly 2R", near((32758 - 31366) / stop_pts, 2.0, 1e-9))
    # "a $12.5k position makes every 100 pts = $40"
    u = units(12548, 30918)
    check("$12,548 -> ~$40 per 100 pts", near(u * 100, 40.0, 1.0), f"got {u * 100:.2f}")
    # "Taker fee 0.09% (~$4.50 per $5k side, ~$9 round trip)"
    check("$5k one side = $4.50", near(taker_fees_round_trip(5000, 0.09, sides=1), 4.50, 0.01))
    check("$5k round trip = $9.00", near(taker_fees_round_trip(5000, 0.09), 9.00, 0.01))
    # margin = notional / leverage, "5x -> $5k = $1,000 margin"
    check("margin $5,000 @5x = $1,000", near(5000 / 5, 1000, 1e-9))
    # 7 Oct trade: +$51.14 at 18:45 implies ~31,044
    implied = 30918 + 51.14 / units(12548, 30918)
    check("7 Oct +$51.14 implies ~31,044", near(implied, 31044, 1.0), f"got {implied:.2f}")
    check("long pnl sign", pnl_usd(5000, 31000, 31100, "long") > 0)
    check("short pnl sign", pnl_usd(5000, 31000, 30900, "short") > 0)
    check("short loses when price rises", pnl_usd(5000, 31000, 31100, "short") < 0)


def test_hard_cap_and_risk_budget_bind():
    print("\n[2] rule 3 — the $10,000 hard cap and the $40/day risk budget")
    # 60-pt stop -> the cap binds (the $40 budget does not)
    t = sizelib.build_ticket(CFG, "long", 31000, 30940, size_usd=12548, r_mult=2.0)
    check("over-cap request is clamped to $10,000", near(t["size_usd"], 10000, 1e-6),
          f"got {t['size_usd']}")
    check("clamping is reported as a warning",
          any("HARD CAP" in w for w in t["warnings"]))
    # 165-pt stop -> the $40 budget binds BEFORE the cap does
    t0 = sizelib.build_ticket(CFG, "long", 31000, 30835, size_usd=12548, r_mult=2.0)
    check("on a wide stop the risk budget binds before the cap",
          t0["size_usd"] < 10000 and near(t0["risk_usd"], 40.0, 0.01),
          f"got size {t0['size_usd']:.0f} risk {t0['risk_usd']:.2f}")

    # A 165-pt stop at $10,000 costs $53.23 > $40 -> size must be cut
    t2 = sizelib.build_ticket(CFG, "long", 31000, 30835, size_usd=10000, r_mult=2.0)
    check("risk budget cuts the size", t2["size_usd"] < 10000, f"got {t2['size_usd']}")
    check("cut size respects the $40 budget", t2["risk_usd"] <= 40.0 + 1e-6,
          f"got {t2['risk_usd']:.2f}")
    check("cutting size is reported", any("RISK BUDGET" in w for w in t2["warnings"]))

    check("max notional for $40 at a 165-pt stop ~= $7,515",
          near(max_notional_for_risk(31000, 165, 40), 7515, 5),
          f"got {max_notional_for_risk(31000, 165, 40):.0f}")

    # Upsizing is only allowed on a clean <=80pt range
    t3 = sizelib.build_day_ticket(CFG, "long", 31120, 31000, size_usd=10000, r_mult=2.0)
    check("upsize refused on a 120-pt range", t3["size_usd"] <= 5000 + 1e-6,
          f"got {t3['size_usd']}")


def test_day_range_geometry():
    print("\n[3] rule 2 — range-break geometry")
    t = sizelib.build_day_ticket(CFG, "long", 31052, 30988, size_usd=5000, r_mult=2.0)
    check("long entry = high + 5", near(t["entry"], 31057, 1e-9), f"got {t['entry']}")
    check("long stop = low - 10", near(t["stop"], 30978, 1e-9), f"got {t['stop']}")
    check("stop_pts = width + 15", near(t["stop_pts"], 64 + 15, 1e-9), f"got {t['stop_pts']}")

    s = sizelib.build_day_ticket(CFG, "short", 31052, 30988, size_usd=5000, r_mult=2.0)
    check("short entry = low - 5", near(s["entry"], 30983, 1e-9), f"got {s['entry']}")
    check("short stop = high + 10", near(s["stop"], 31062, 1e-9), f"got {s['stop']}")
    check("short stop_pts = width + 15", near(s["stop_pts"], 79, 1e-9), f"got {s['stop_pts']}")
    check("short target is below entry", s["target"] < s["entry"])


def test_fee_toll_is_structural():
    print("\n[4] rule 4 — the fee toll is size-invariant and structurally impossible at 1.5R")
    entry, stop = 31000.0, 165.0
    small = fee_pct_of_gross_target(5000, entry, stop, 1.5)
    big = fee_pct_of_gross_target(10000, entry, stop, 1.5)
    huge = fee_pct_of_gross_target(100000, entry, stop, 1.5)
    check("fee ratio does not change with size",
          near(small, big, 1e-9) and near(big, huge, 1e-9), f"{small} / {big} / {huge}")
    check("fees/gross = 2*taker*entry/(stop*R)",
          near(small, 2 * 0.09 * entry / (stop * 1.5), 1e-9), f"got {small}")

    f = fee_filter_feasibility(entry, 1.5, 150, 5, 10, 20, 0.09)
    check("1.5R needs a 186-pt stop", near(f["stop_pts_needed"], 186, 0.5), f"got {f['stop_pts_needed']}")
    check("rule 4 allows at most a 165-pt stop", near(f["stop_pts_allowed"], 165, 1e-9))
    check("=> 1.5R is INFEASIBLE", f["feasible"] is False)
    check("minimum feasible R at the widest legal range ~= 1.69",
          near(f["min_r_at_max_range"], 1.691, 0.01), f"got {f['min_r_at_max_range']}")

    f2 = fee_filter_feasibility(entry, 2.0, 150, 5, 10, 20, 0.09)
    check("2.0R IS feasible (stop needed 139.5 <= 165)", f2["feasible"] is True,
          f"needs {f2['stop_pts_needed']}")
    check("min_r_for_fee_filter agrees with fee_pct at the boundary",
          near(fee_pct_of_gross_target(5000, entry, stop, min_r_for_fee_filter(entry, stop, 20)),
               20.0, 1e-6))

    t = sizelib.build_day_ticket(CFG, "long", 31052, 30988, size_usd=5000, r_mult=1.5)
    check("a 1.5R narrow-range ticket is BLOCKED by rule 4", not t["legal"])
    check("the block names the fee filter",
          any("FEE FILTER" in b for b in t["blocks"]))


def test_wide_range_and_skip_conditions():
    print("\n[5] rule 4 — width and chop skips")
    rc = subprocess.run(
        [sys.executable, "gate.py", "--now", "16:46", "--flat", "--range-high", "31160",
         "--range-low", "31000", "--break", "long", "--last", "31165"],
        capture_output=True, text=True, cwd=os.path.dirname(os.path.abspath(__file__)))
    check("160-pt range -> exit 2 (SKIP)", rc.returncode == 2, f"got {rc.returncode}")
    check("160-pt range -> 'wider than the 150-pt limit'", "150-pt limit" in rc.stdout)

    rc = subprocess.run(
        [sys.executable, "gate.py", "--now", "16:46", "--flat", "--range-high", "31052",
         "--range-low", "30988", "--break", "long", "--last", "31057", "--chop", "22"],
        capture_output=True, text=True, cwd=os.path.dirname(os.path.abspath(__file__)))
    check("22 min of chop -> SKIP", rc.returncode == 2 and "chop" in rc.stdout.lower())


def test_gate_refuses_blank_inputs():
    print("\n[6] the gate refuses to guess")
    here = os.path.dirname(os.path.abspath(__file__))

    # The UNCONFIRMED case is built in a temp state, not assumed of the live file —
    # the live book was confirmed FLAT on 8 Oct 2026.
    with tempfile.TemporaryDirectory() as d:
        st = open(os.path.join(here, "config", "state.yaml"), encoding="utf-8").read()
        st = st.replace("position_status: FLAT", "position_status: UNCONFIRMED")
        open(os.path.join(d, "state.yaml"), "w", encoding="utf-8").write(st)
        rc = subprocess.run([sys.executable, "gate.py", "--now", "16:46", "--state",
                             os.path.join(d, "state.yaml")],
                            capture_output=True, text=True, cwd=here)
    check("UNCONFIRMED position -> exit 3 (incomplete)", rc.returncode == 3, f"got {rc.returncode}")
    check("it names rule 6", "rule 6" in rc.stdout)

    rc = subprocess.run([sys.executable, "gate.py", "--now", "16:44"],
                        capture_output=True, text=True, cwd=here)
    check("a confirmed FLAT book no longer blocks the gate", rc.returncode != 3, f"got {rc.returncode}")
    check("a FLAT book is not reported as unconfirmed", "UNCONFIRMED" not in rc.stdout)

    rc = subprocess.run([sys.executable, "gate.py", "--now", "16:46", "--flat"],
                        capture_output=True, text=True, cwd=here)
    check("no range supplied -> exit 3", rc.returncode == 3, f"got {rc.returncode}")

    rc = subprocess.run([sys.executable, "gate.py", "--now", "16:35", "--flat",
                         "--range-high", "31052", "--range-low", "30988"],
                        capture_output=True, text=True, cwd=here)
    check("16:35 (range still printing) -> WAIT/SKIP", rc.returncode == 2 and "PRINTING" in rc.stdout)

    rc = subprocess.run([sys.executable, "gate.py", "--now", "23:30", "--flat"],
                        capture_output=True, text=True, cwd=here)
    check("23:30 -> past the flat deadline", rc.returncode == 2 and "23:00" in rc.stdout)


def test_legal_ticket_exits_zero():
    print("\n[7] a legal ticket exits 0")
    here = os.path.dirname(os.path.abspath(__file__))
    rc = subprocess.run([sys.executable, "gate.py", "--now", "16:46", "--flat",
                         "--range-high", "31140", "--range-low", "31000",
                         "--break", "long", "--last", "31148", "--r", "2"],
                        capture_output=True, text=True, cwd=here)
    check("140-pt range @2R -> exit 0 (trade allowed)", rc.returncode == 0, f"got {rc.returncode}")
    check("verdict is LONG", "VERDICT: LONG" in rc.stdout)
    check("management block is present", "Management" in rc.stdout)
    check("stop is 155 pts", "155.0 pts" in rc.stdout)


def test_session_clock_phases():
    print("\n[8] the EAT session clock")
    def at(hh, mm):
        return session_clock(datetime(2026, 10, 8, hh, mm, tzinfo=EAT), CFG)["phase"]
    check("16:20 -> pre-open", at(16, 20) == "pre-open")
    check("16:35 -> range", at(16, 35) == "range")
    check("16:45 -> gate", at(16, 45) == "gate")
    check("18:00 -> managing", at(18, 0) == "managing")
    check("23:00 -> flat", at(23, 0) == "flat")
    c = session_clock(datetime(2026, 10, 8, 16, 40, tzinfo=EAT), CFG)
    check("minutes_to_gate at 16:40 = 5", c["minutes_to_gate"] == 5, f"got {c['minutes_to_gate']}")
    check("EAT is UTC+3", datetime(2026, 10, 8, 13, 0, tzinfo=EAT).utcoffset().total_seconds() == 3 * 3600)


def test_liq_estimate():
    print("\n[9] liquidation estimate (isolated 5x)")
    lq = liq_price(31000, "long", 5)
    check("long liq ~9.91% below entry (10% less the entry fee)",
          near(lq, 31000 * (1 - 0.0991), 5), f"got {lq:.2f}")
    check("short liq is above entry", liq_price(31000, "short", 5) > 31000)
    check("higher leverage liquidates closer",
          liq_price(31000, "long", 30) > liq_price(31000, "long", 5))


def test_yaml_parser():
    print("\n[10] the bundled YAML-subset parser")
    doc = parse_yaml("""
# comment
a: 1
b: 2.5
c: hello world
d: true
e: [x, y, 3]
f:
  g: 4
  h:
    - one
    - two
zones:
  - name: pivot
    level: 31000
    meaning: round number  # not a comment inside a value? it is stripped
""")
    check("int", doc["a"] == 1)
    check("float", doc["b"] == 2.5)
    check("string", doc["c"] == "hello world")
    check("bool", doc["d"] is True)
    check("inline list", doc["e"] == ["x", "y", 3])
    check("nested map", doc["f"]["g"] == 4)
    check("block list", doc["f"]["h"] == ["one", "two"])
    check("list of maps", doc["zones"][0]["name"] == "pivot" and doc["zones"][0]["level"] == 31000)
    check("trailing comment stripped", doc["zones"][0]["meaning"] == "round number",
          f"got {doc['zones'][0]['meaning']!r}")
    doc2 = parse_yaml("""
violations:
  - "held past 23:00 EAT — breaks the rule"
  - plain scalar with a colon 12:30 inside
  - name: real_map
    level: 100
""")
    check("quoted scalar with a colon stays a string",
          doc2["violations"][0] == "held past 23:00 EAT — breaks the rule",
          f"got {doc2['violations'][0]!r}")
    check("bare scalar with a colon stays a string",
          isinstance(doc2["violations"][1], str), f"got {doc2['violations'][1]!r}")
    check("a real map item is still a map", doc2["violations"][2] == {"name": "real_map", "level": 100},
          f"got {doc2['violations'][2]!r}")
    check("state.yaml violations parse as strings",
          all(isinstance(x, str) for x in CFG.state["closed_position"]["violations"]),
          f"got {CFG.state['closed_position']['violations']}")
    check("real config loads", CFG.get("day.hard_cap_usd") == 10000)
    check("levels load", len(CFG.get("zones") or []) == 7)
    check("macro calendar loads", len(CFG.get("events") or []) == 3)


def test_journal_r_proof_and_flags():
    print("\n[11] the journal proves R and flags rule breaks")
    rows = journal.read_trades()
    check("trades.csv is seeded", len(rows) >= 1)
    a = journal.analyse(rows[0], CFG)
    check("7 Oct trade is flagged for the hard cap",
          any(f.startswith("HARD_CAP_BREACH") for f in a["flags"]))
    check("7 Oct trade is now CLOSED — confirmed FLAT in the app on 8 Oct",
          rows[0]["status"] == "CLOSED" and "EXIT_UNCONFIRMED" not in a["flags"])
    check("no stop was ever logged, so no R can be proven", a["r_achieved"] is None)
    check("the implied exit nets $28.55 after $22.59 of fees",
          near(a["net_pnl"], 28.55, 0.01), f"got {a['net_pnl']}")
    check("units on the 7 Oct ticket ~= 0.4059", near(units(12548, 30918), 0.4059, 0.001))

    with tempfile.TemporaryDirectory() as td:
        f = os.path.join(td, "t.csv")
        journal.write_trades([], f)
        rc = subprocess.run([sys.executable, "journal.py", "--file", f, "log",
                             "--date", "2026-10-08", "--side", "long", "--size", "5000",
                             "--entry", "31145", "--stop", "30990", "--target", "31455",
                             "--opened", "16:47"], capture_output=True, text=True,
                            cwd=os.path.dirname(os.path.abspath(__file__)))
        check("log exits 0", rc.returncode == 0, rc.stderr[-200:])
        rows2 = journal.read_trades(f)
        check("logged row has stop_pts 155", near(float(rows2[0]["stop_pts"]), 155, 1e-6))
        check("logged row has planned R 2.00", near(float(rows2[0]["r_planned"]), 2.0, 1e-6))
        check("logged row is OPEN", rows2[0]["status"] == "OPEN")

        rc = subprocess.run([sys.executable, "journal.py", "--file", f, "close", "--id", "1",
                             "--exit", "31300", "--closed", "18:20", "--reason", "target"],
                            capture_output=True, text=True,
                            cwd=os.path.dirname(os.path.abspath(__file__)))
        check("close exits 0", rc.returncode == 0, rc.stderr[-200:])
        rows3 = journal.read_trades(f)
        a3 = journal.analyse(rows3[0], CFG)
        check("price R = +1.0 exactly", near(a3["price_r"], 1.0, 1e-9), f"got {a3['price_r']}")
        check("net R < price R after fees", a3["r_achieved"] < a3["price_r"])
        # At exactly 1R on a $5k ticket, $9 of fees leaves 0.64R. That IS the fee toll.
        check("a 1R winner nets only ~0.64R after fees",
              near(a3["r_achieved"], 0.638, 0.01), f"got {a3['r_achieved']:.3f}")
        check("R_DIVERGENCE flagged when fees bite",
              any(x.startswith("R_DIVERGENCE") for x in a3["flags"]))
        check("EXIT_UNCONFIRMED cleared after the exit is set",
              "EXIT_UNCONFIRMED" not in a3["flags"])
        check("closed after 23:00 is flagged", any(
            x.startswith("FLAT_BY_2300_BREACH")
            for x in journal.analyse(dict(rows3[0], closed_eat="23:40"), CFG)["flags"]))
        check("closed before 23:00 is not flagged", not any(
            x.startswith("FLAT_BY_2300_BREACH")
            for x in journal.analyse(dict(rows3[0], closed_eat="18:20"), CFG)["flags"]))


def test_no_order_placing_capability():
    print("\n[12] Arena cannot trade — the kit has no order-placing surface")
    here = os.path.dirname(os.path.abspath(__file__))
    banned = ("requests.post", "requests.get", "urllib.request", "http.client", "websocket",
              "coinvest.liquid.trade/mcp", "api_key", "private_key", "withdraw")
    for fn in ("gate.py", "size.py", "journal.py", "opslib.py"):
        src = open(os.path.join(here, fn), encoding="utf-8").read()
        hits = [b for b in banned if b in src]
        check(f"{fn} makes no network calls / holds no credentials", not hits, f"found {hits}")


def test_fee_drag_closed_form():
    print("\n[13] fee drag in R — closed form, size-invariant")
    entry, stop, taker = 31000.0, 155.0, 0.09
    drag = scanlib.fee_drag_r(entry, stop, taker)
    check("drag = 2*taker/100*entry/stop", near(drag, 0.0018 * entry / stop, 1e-12), f"got {drag}")
    # cross-check against the explicit dollar arithmetic at three different sizes
    for sz in (2500, 5000, 10000):
        risk = units(sz, entry) * stop
        gross = risk * 2.0
        fees = taker_fees_round_trip(sz, taker)
        explicit = (gross - fees) / risk
        check(f"net_R at ${sz:,} matches the closed form", near(explicit, scanlib.net_r(entry, stop, 2.0, taker), 1e-9),
              f"{explicit} vs {scanlib.net_r(entry, stop, 2.0, taker)}")
    check("break-even win rate = 1/(1+net_R)",
          near(scanlib.breakeven_win_rate(1.0), 50.0, 1e-9))
    check("break-even at 1.66R net ~= 37.6%",
          near(scanlib.breakeven_win_rate(scanlib.net_r(31000, 165, 2.0)), 37.6, 0.2))
    check("break-even of a non-positive net_R is None",
          scanlib.breakeven_win_rate(-0.5) is None)


def test_feasibility_band():
    print("\n[14] the legal band under the enforced minimum, and the empty band at the legacy 1.5R")
    check("the enforced minimum is now 2.0R (decided 8 Oct 2026)",
          CFG.get("day.min_target_r") == 2.0, f"got {CFG.get('day.min_target_r')}")
    ft = scanlib.feasibility_table(CFG, 30996.5)
    check("table covers 30..150 pt ranges", [r["width"] for r in ft][0] == 30 and ft[-1]["width"] == 150)
    legal = [r["width"] for r in ft if r["legal_at_min"]]
    check("legal at the enforced 2.0R only for 130-150 pt ranges", legal == [130, 140, 150], f"got {legal}")
    check("NOTHING is legal at the legacy 1.5R minimum", not any(r["legal_at_ref"] for r in ft))
    ft15 = scanlib.feasibility_table(CFG, 30996.5, r_ref=1.0)  # r_ref only relabels the reference column
    check("r_ref does not change the enforced column", ft15[0]["r_enforced"] == 2.0)
    check("the $40 budget binds before the $10k cap on wide ranges",
          all(r["budget_binds_before_cap"] for r in ft if r["width"] >= 120))
    check("max size at a 165-pt stop ~= $7,514", near(ft[-1]["max_size_for_budget"], 7514, 3),
          f"got {ft[-1]['max_size_for_budget']}")
    check("upsize only allowed at <=80 pts",
          [r["width"] for r in ft if r["upsize_allowed"]] == [30, 40, 50, 60, 70, 80])
    check("net_R rises as the stop widens", ft[0]["net_r_at_min"] < ft[-1]["net_r_at_min"])
    check("break-even win rate falls as the stop widens", ft[0]["be_at_min"] > ft[-1]["be_at_min"])
    check("break-even at the enforced 2.0R on a 150-pt range ~= 38%",
          near(ft[-1]["be_at_min"], 37.6, 0.6), f"got {ft[-1]['be_at_min']}")
    check("the enforced minimum clamps a lower --r back up",
          sizelib.build_day_ticket(CFG, "long", 31052, 30988, 5000, 1.5)["r_multiple"] == 2.0,
          f"got {sizelib.build_day_ticket(CFG, 'long', 31052, 30988, 5000, 1.5)['r_multiple']}")


def test_regime_scan():
    print("\n[15] regime scan is advisory and reproducible")
    reg = scanlib.regime_scan(CFG)
    check("current state reads RISK-OFF", reg["label"] == "RISK-OFF (tech)", f"got {reg['label']}")
    check("score is -4 (NQ -0.57%, below pivot, 10Y 5.28%)", reg["total"] == -4, f"got {reg['total']}")
    check("every contributor is shown with a reason",
          all(c["why"] for c in reg["contributors"]))
    check("missing RSI is reported, not invented", "rsi" in reg["missing"])
    check("label bands are ordered", scanlib.regime_scan(CFG)["label"] in
          ("RISK-ON (tech)", "mildly risk-on", "NEUTRAL", "mildly risk-off", "RISK-OFF (tech)"))


def test_zone_map():
    print("\n[16] zone map distances")
    rows = scanlib.zone_map(CFG, 30996.5)
    check("seven zones, sorted high to low",
          len(rows) == 7 and rows[0]["ref"] > rows[-1]["ref"])
    check("swing gate is +369.5 pts away", near(rows[0]["dist_pts"], 369.5, 0.1), f"got {rows[0]['dist_pts']}")
    check("pivot is +3.5 pts away", near([r for r in rows if r["name"] == "pivot"][0]["dist_pts"], 3.5, 0.01))
    check("support_1 is below price", [r for r in rows if r["name"] == "support_1"][0]["position"] == "below")
    check("current zone is identified", "support_1" in scanlib.current_zone(rows, 30996.5))


def test_feed_is_read_only_and_refuses_everything_else():
    print("\n[17] the feed adapter cannot mutate anything")
    for bad in ("post", "order", "place", "cancel", "withdraw", "transfer", "exchange",
                "clearinghouseState", "userFills", "modify"):
        try:
            feed.build_request(bad)
            check(f"refuses request type {bad!r}", False, "it was accepted")
        except feed.FeedError:
            check(f"refuses request type {bad!r}", True)
    for good in ("meta", "allMids", "metaAndAssetCtxs", "l2Book"):
        body = feed.build_request(good)
        check(f"allows public read type {good!r}", body["type"] == good and body.get("dex") == "xyz")
    req = feed.build_request("candleSnapshot", interval="5m", start_ms=1, end_ms=2)
    check("candleSnapshot carries the dex + coin", req["req"]["coin"] == "XYZ100" and req["req"]["dex"] == "xyz")

    here_f = os.path.dirname(os.path.abspath(__file__))
    src = open(os.path.join(here_f, "liquid_feed.py"), encoding="utf-8").read()
    # Strip the module docstring and comments: the prose *says* "no wallet, no
    # withdraw" on purpose. What matters is that the executable code has none of it.
    tree = ast.parse(src)
    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Constant):
        tree.body.pop(0)
    code = ast.unparse(tree)
    for banned in ("api_key", "secret", "private_key", "sign(", "wallet",
                   "Authorization", "Bearer", "/exchange", "place_order", "withdraw"):
        check("feed code has no %r" % banned, banned not in code)
    check("feed prose documents that it is read-only",
          "READ-ONLY" in src and "NO API keys" in src)
    urls = set(re.findall(r"https://[A-Za-z0-9._/:-]+", src))
    check("every URL in the feed is the public info endpoint",
          urls == {"https://api.hyperliquid.xyz/info"}, f"got {urls}")
    for core in ("gate.py", "size.py", "scan.py", "journal.py", "opslib.py"):
        csrc = open(os.path.join(here_f, core), encoding="utf-8").read()
        ctree = ast.parse(csrc)
        if ctree.body and isinstance(ctree.body[0], ast.Expr) and isinstance(ctree.body[0].value, ast.Constant):
            ctree.body.pop(0)
        ccode = ast.unparse(ctree)
        hits = [x for x in ("urllib", "http.client", "requests.", "socket", "https://") if x in ccode]
        check(f"{core} (the decision core) is network-free", not hits, f"found {hits}")


def test_feed_parsing_against_documented_shapes():
    print("\n[18] feed parsing, against the documented Hyperliquid schema")
    # 16:30 EAT == 13:30 UTC, and the window is 15 minutes
    from datetime import datetime as dt
    now = dt(2026, 10, 8, 13, 50, tzinfo=feed.UTC)
    start, end, printed = feed.range_window(now)
    check("range window starts 13:30 UTC", start.strftime("%H:%M") == "13:30", start.strftime("%H:%M"))
    check("range window ends 13:45 UTC", end.strftime("%H:%M") == "13:45", end.strftime("%H:%M"))
    check("window is printed at 13:50 UTC", printed is True)
    check("window is EAT 16:30-16:45", feed.to_eat(start) == "16:30" and feed.to_eat(end) == "16:45")
    check("not printed at 13:40 UTC", feed.range_window(dt(2026, 10, 8, 13, 40, tzinfo=feed.UTC))[2] is False)

    meta_resp = [
        {"universe": [{"name": "ABC", "maxLeverage": 30}, {"name": "XYZ100", "maxLeverage": 30, "szDecimals": 4}]},
        [{"markPx": "100.0", "openInterest": "10"},
         {"markPx": "30996.5", "oraclePx": "31002.0", "midPx": "30997.0", "prevDayPx": "30984.0",
          "openInterest": "8700.5", "funding": "0.000006", "dayNtlVlm": "12345678"}],
    ]
    ctx = feed.parse_ctx(meta_resp)
    check("picks the XYZ100 row, not the first", ctx["coin"] == "XYZ100" and ctx["last"] == 30996.5)
    check("24h change computed from prevDayPx", near(ctx["change_24h_pct"], 0.0403, 0.001),
          f"got {ctx['change_24h_pct']}")
    check("funding decimal -> %/hr", near(ctx["funding_pct_per_hr"], 0.0006, 1e-9),
          f"got {ctx['funding_pct_per_hr']}")
    check("OI is base units x mark", near(ctx["open_interest_usd"], 8700.5 * 30996.5, 1.0),
          f"got {ctx['open_interest_usd']}")
    try:
        feed.parse_ctx([{"universe": [{"name": "OTHER"}]}, [{}]])
        check("a missing coin raises, never guesses", False)
    except feed.FeedError:
        check("a missing coin raises, never guesses", True)

    t0 = int(start.timestamp() * 1000)
    candles = [
        {"t": t0, "T": t0 + 300000, "o": "31000", "h": "31052", "l": "30995", "c": "31040", "v": "10"},
        {"t": t0 + 300000, "T": t0 + 600000, "o": "31040", "h": "31048", "l": "30988", "c": "31010", "v": "9"},
        {"t": t0 + 600000, "T": t0 + 900000, "o": "31010", "h": "31030", "l": "31000", "c": "31020", "v": "8"},
        {"t": t0 + 900000, "T": t0 + 1200000, "o": "31020", "h": "31999", "l": "30001", "c": "31500", "v": "1"},
    ]
    r = feed.parse_range(candles, start, end)
    check("range takes the max high INSIDE the window", r["high"] == 31052, f"got {r['high']}")
    check("range takes the min low INSIDE the window", r["low"] == 30988, f"got {r['low']}")
    check("width = 64 pts", near(r["width_pts"], 64.0, 1e-9), f"got {r['width_pts']}")
    check("out-of-window candle excluded", r["high"] != 31999)
    check("long trigger = high + 5", r["long_trigger"] == 31057)
    check("short trigger = low - 5", r["short_trigger"] == 30983)
    check("three 5m candles used", r["candles"] == 3, f"got {r['candles']}")
    check("empty candle list is reported, not faked", feed.parse_range([], start, end)["printed"] is False)

    patch = feed.state_patch({"context": ctx, "range": r, "as_of_eat": "x"})
    check("state patch never invents a position status",
          patch["account"]["position_status"] is None)
    check("state patch carries the range through", patch["range_5m"]["width_pts"] == 64.0)


def test_scan_cli():
    print("\n[19] scan.py end to end")
    here = os.path.dirname(os.path.abspath(__file__))
    rc = subprocess.run([sys.executable, "scan.py", "--at", "16:20"], capture_output=True, text=True, cwd=here)
    check("scan exits 0 on the current state", rc.returncode == 0, rc.stderr[-300:])
    for needle in ("REGIME SCAN", "ZONE MAP", "SWING GATE PROJECTION", "FEASIBILITY BAND",
                   "SCENARIOS", "PREDICTION BRIEF", "WHAT THIS SCAN CANNOT TELL YOU"):
        check(f"section present: {needle}", needle in rc.stdout)
    check("the daily-close ambiguity is flagged", "WHICH daily close" in rc.stdout)
    check("it records that the legacy 1.5R minimum was unsatisfiable",
          "UNSATISFIABLE" in rc.stdout and "186-pt stop" in rc.stdout)
    check("it reports the enforced minimum as satisfiable in a narrow band",
          "satisfiable, but only in a narrow band" in rc.stdout)
    check("every prediction carries a falsifier",
          rc.stdout.count("Falsified by:") >= 5, f"got {rc.stdout.count('Falsified by:')}")
    check("advisory-only is stated", "NEVER AN ENTRY TRIGGER" in rc.stdout)

    rc = subprocess.run([sys.executable, "scan.py", "--at", "16:45",
                         "--range-high", "31052", "--range-low", "30988"],
                        capture_output=True, text=True, cwd=here)
    check("scenarios render for a supplied range", "LONG  @1.5R" in rc.stdout and "SHORT @2.0R" in rc.stdout)
    check("the 64-pt range is reported BLOCKED", "BLOCKED" in rc.stdout)
    check("the enforced minimum is announced", "ENFORCED minimum target: 2.0R" in rc.stdout)
    check("the legal band is announced", "LEGAL BAND at 2.0R" in rc.stdout)
    check("the legacy empty band is explained", "why the minimum was raised" in rc.stdout)

    rc = subprocess.run([sys.executable, "scan.py", "--json", "--at", "16:20"],
                        capture_output=True, text=True, cwd=here)
    check("--json is valid JSON", rc.returncode == 0 and isinstance(json.loads(rc.stdout), dict))

    rc = subprocess.run([sys.executable, "scan.py", "--last", ""], capture_output=True, text=True, cwd=here)
    check("a non-numeric --last is a usage error, not a guess", rc.returncode == 2, f"got {rc.returncode}")
    with tempfile.TemporaryDirectory() as td:
        blank = os.path.join(td, "state.yaml")
        with open(blank, "w", encoding="utf-8") as fh:
            fh.write("meta:\n  stale: true\nmarket:\n  last: null\n")
        rc = subprocess.run([sys.executable, "scan.py", "--state", blank],
                            capture_output=True, text=True, cwd=here)
        check("no last price -> exit 3, scan refused", rc.returncode == 3, f"got {rc.returncode}")
        check("it says fill the bracket, do not estimate",
              "do not estimate" in rc.stdout, rc.stdout[:200])

    rc = subprocess.run([sys.executable, "liquid_feed.py", "--dry-run"],
                        capture_output=True, text=True, cwd=here)
    check("feed --dry-run sends nothing and exits 0", rc.returncode == 0 and "nothing was sent" in rc.stdout.lower())
    dry = json.loads(rc.stdout.split("\nNothing was sent")[0])
    check("dry-run shows the metaAndAssetCtxs request",
          dry["requests"][0] == {"type": "metaAndAssetCtxs", "dex": "xyz"})
    check("dry-run shows the 5m candle request for the range",
          dry["requests"][1]["req"]["interval"] == "5m" and dry["requests"][1]["req"]["coin"] == "XYZ100")


def test_dashboard_matches_the_cli():
    print("\n[20] the dashboard is the CLI, rendered — it cannot disagree with the rules")
    import dashboard as dash
    from opslib import OpsConfig
    cfg = OpsConfig()

    def run(**kw):
        return dash.build_state(cfg, **kw)

    printing = run(now_str="16:44")
    check("16:44 is WAIT while the range prints", printing["verdict"]["kind"] == "WAIT")
    check("the pre-open arms but does not send", run(now_str="16:20")["verdict"]["kind"] == "WAIT")
    check("past 23:00 the day window is closed", "flat deadline" in run(now_str="23:30")["verdict"]["reason"])

    blocked = run(now_str="16:50", r_high=31052, r_low=30988, brk="long", last=31057)
    check("a 64-pt range LONG is refused by rule 4", blocked["verdict"]["kind"] == "SKIP")
    check("the refused ticket still shows its numbers", blocked["ticket"]["legal"] is False
          and blocked["ticket"]["r_multiple"] == 2.0)
    check("the refusal names the fee filter", any("FEE FILTER" in b for b in blocked["ticket"]["blocks"]))

    legal = run(now_str="16:50", r_high=31140, r_low=31000, brk="long", last=31145)
    check("a 140-pt range LONG is authorised", legal["verdict"]["kind"] == "LONG")
    t = legal["ticket"]
    check("the authorised ticket is the CLI's ticket",
          t["legal"] and t["size_usd"] == 5000 and near(t["risk_usd"], 24.88, 0.02)
          and t["r_multiple"] == 2.0 and near(t["net_r_multiple"], 1.64, 0.01),
          f"got {t['risk_usd']} / {t['net_r_multiple']}")
    check("a 160-pt range is skipped outright", "150-pt limit" in run(now_str="16:50", r_high=31200,
          r_low=31040, brk="long")["verdict"]["reason"])

    check("a touch is not a break", "touch is not a break" in run(now_str="16:50", r_high=31052,
          r_low=30988)["verdict"]["reason"])
    check("seven zones, the fee band, and five alerts", len(legal["zones"]) == 7
          and len(legal["band"]) == 7 and len(legal["alerts"]) == 5)
    due = [a for a in run(now_str="16:50")["alerts"] if a["state"] == "due"]
    check("at 16:50 the gate alert is the one that is due", [a["key"] for a in due] == ["gate"])
    check("every alert carries a paste block and nothing is sent",
          all(a["paste_block"] and "Paste" in a["paste_block"] for a in legal["alerts"]))
    check("the journal shows the closed 7 Oct trade and its flags",
          legal["journal"][0]["status"] == "CLOSED"
          and any(f.startswith("HARD_CAP_BREACH") for f in legal["journal"][0]["flags"]))
    check("the screen states that it places no orders", "places no orders" in legal["disclaimer"])

    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard.py"), encoding="utf-8").read()
    tree = ast.parse(src)
    tree.body = [n for n in tree.body if not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant))]
    code = ast.unparse(tree)
    check("the dashboard has no network client and no order vocabulary",
          not re.search(r"\b(requests|urllib|socket|httpx|aiohttp|websocket)\b", code)
          and not re.search(r"\b(withdraw|privateKey|sign_l1|place_order|api_key)\b", code))


def _bar(day, hh, mm, o, h, l, c):
    from datetime import datetime as dt
    t = int(dt(int(day[0:4]), int(day[5:7]), int(day[8:10]), hh, mm, tzinfo=feed.EAT).timestamp() * 1000)
    return {"t": t, "T": t + 60_000, "o": o, "h": h, "l": l, "c": c}


def _range(day, hi, lo):
    mid = (hi + lo) / 2
    return [_bar(day, 16, 30 + i, mid, hi if i == 0 else mid + 1, lo if i == 0 else mid - 1, mid)
            for i in range(15)]


def test_backtest_books_the_rulebook():
    print("\n[21] the backtest books the written rule, and is allowed to say there is no edge")
    import backtest as bt
    demo = bt.run_backtest(bt._demo_candles())
    taken = {d["date"]: d for d in demo["days"] if d["taken"]}
    skipped = {d["date"]: d["reason"] for d in demo["days"] if not d["taken"]}
    check("a 60-pt range is skipped by the fee filter, even if price runs",
          skipped.get("2026-10-02") == "fee_filter", skipped)
    check("the scripted target is a target, filled at the next open not the signal close",
          taken["2026-10-08"]["reason"] == "target" and taken["2026-10-08"]["fill"] == 31150)
    check("the scripted stop is a stop at the stop price, not at the wick",
          taken["2026-10-01"]["reason"] == "stop" and taken["2026-10-01"]["exit"] == 30990)
    check("two trades is INSUFFICIENT, not an edge", demo["verdict"] == "INSUFFICIENT")
    check("a stop after a worse fill is worse than -1R once fees are in",
          taken["2026-10-01"]["r"] < -1.0, taken["2026-10-01"]["r"])

    # Same bar trades both. Stop wins.
    bars = _range("2026-10-06", 31140, 31000)
    bars += [_bar("2026-10-06", 16, 47, 31130, 31150, 31128, 31146),
             _bar("2026-10-06", 16, 48, 31150, 31480, 30980, 31200)]
    both = bt.replay_day(CFG, "2026-10-06", bars)
    check("stop and target on the fill bar is a stop", both["taken"] and both["reason"] == "stop")

    # Gap through the stop exits at the open.
    bars = _range("2026-10-07", 31140, 31000)
    bars += [_bar("2026-10-07", 16, 47, 31130, 31150, 31128, 31146),
             _bar("2026-10-07", 16, 48, 30900, 30920, 30880, 30910)]
    gap = bt.replay_day(CFG, "2026-10-07", bars)
    check("a gap through the stop exits at the open", gap["reason"] == "stop" and gap["exit"] == 30900)

    # Break 20 minutes late is chop, not a trade.
    bars = _range("2026-10-09", 31140, 31000)
    bars += [_bar("2026-10-09", 16, 46 + i, 31100, 31110, 31090, 31100) for i in range(14)]
    bars += [_bar("2026-10-09", 17, 6, 31140, 31160, 31130, 31150),
             _bar("2026-10-09", 17, 7, 31150, 31480, 31140, 31460)]
    chop = bt.replay_day(CFG, "2026-10-09", bars)
    check("a break after 15 minutes of chop is a skip", chop["reason"] == "chop" and not chop["taken"])

    # The signal bar's own high is not a fill. No lookahead.
    bars = _range("2026-10-13", 31140, 31000)
    bars += [_bar("2026-10-13", 16, 47, 31130, 31480, 31128, 31146),  # high at the target, close is the signal
             _bar("2026-10-13", 16, 48, 31150, 31155, 31140, 31145),
             _bar("2026-10-13", 16, 49, 31145, 31148, 30980, 30990)]
    no_look = bt.replay_day(CFG, "2026-10-13", bars)
    check("the signal bar is not the fill, and its high does not book the target",
          no_look["reason"] == "stop" and no_look["fill"] == 31150)

    # Weekend bars are ignored. A 5-minute file is refused.
    sat = [_bar("2026-10-10", 16, 30 + i, 31100, 31140, 31000, 31120) for i in range(15)]
    sat += [_bar("2026-10-10", 16, 47, 31130, 31150, 31128, 31146),
            _bar("2026-10-10", 16, 48, 31150, 31480, 31140, 31460)]
    weekend = bt.run_backtest(sat + _range("2026-10-08", 31140, 31000)
                              + [_bar("2026-10-08", 16, 47, 31100, 31110, 31090, 31100)])
    check("Saturday is not a session", all(d["date"] != "2026-10-10" for d in weekend["days"]))
    coarse = [_bar("2026-10-08", 16, 30, 1, 2, 1, 1), _bar("2026-10-08", 16, 35, 1, 2, 1, 1),
              _bar("2026-10-08", 16, 40, 1, 2, 1, 1)]
    try:
        bt.run_backtest(coarse)
        check("a 5-minute file is refused", False, "it ran")
    except SystemExit as exc:
        check("a 5-minute file is refused", "1-minute close" in str(exc))

    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "backtest.py"), encoding="utf-8").read()
    tree = ast.parse(src)
    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Constant):
        tree.body.pop(0)
    code = ast.unparse(tree)
    hits = [x for x in ("urllib", "requests", "socket", "https://") if x in code]
    check("the backtest is network-free", not hits, f"found {hits}")


def test_tape_is_public_and_order_free():
    print("\n[22] the tape is a public snapshot — no account, no order")
    meta = [
        {"universe": [{"name": "xyz:XYZ100", "maxLeverage": 20, "szDecimals": 4}]},
        [{"markPx": "31010", "oraclePx": "31000", "midPx": "31008", "prevDayPx": "30900",
          "openInterest": "10", "funding": "0.000012", "dayNtlVlm": "1000"}],
    ]
    ctx = feed.parse_ctx(meta)
    check("prefixed HIP-3 name xyz:XYZ100 is recognised", ctx["last"] == 31010 and ctx["coin"] == "XYZ100")
    with tempfile.TemporaryDirectory() as td:
        path = feed.write_tape({
            "as_of_utc": "2026-10-08T13:50:00+00:00",
            "as_of_eat": "2026-10-08 16:50 EAT",
            "context": ctx, "range": {"printed": True, "high": 31140, "low": 31000},
            "basis": {},
        }, td)
        saved = json.loads(open(path, encoding="utf-8").read())
        check("tape says it places no orders", saved["orders"] is False)
        check("tape has no position and no account block",
              "position" not in saved and "account" not in saved and "order" not in saved)
        check("a day log was appended", os.path.exists(os.path.join(td, "2026-10-08.jsonl")))
    tape = dash.load_tape() if "dash" in dir() else None
    import dashboard as dashlib
    found = dashlib.load_tape()
    if found is None:
        check("no committed tape yet is empty, not a made-up price", True)
    else:
        check("a committed tape still places no orders", found.get("orders") is False)


def main() -> int:
    print("=" * 78)
    print("Liquid Trading Ops — invariant tests")
    print("=" * 78)
    for fn in [
        test_perp_math_is_pinned_to_the_desks_own_numbers,
        test_hard_cap_and_risk_budget_bind,
        test_day_range_geometry,
        test_fee_toll_is_structural,
        test_wide_range_and_skip_conditions,
        test_gate_refuses_blank_inputs,
        test_legal_ticket_exits_zero,
        test_session_clock_phases,
        test_liq_estimate,
        test_yaml_parser,
        test_journal_r_proof_and_flags,
        test_no_order_placing_capability,
        test_fee_drag_closed_form,
        test_feasibility_band,
        test_regime_scan,
        test_zone_map,
        test_feed_is_read_only_and_refuses_everything_else,
        test_feed_parsing_against_documented_shapes,
        test_scan_cli,
        test_dashboard_matches_the_cli,
        test_backtest_books_the_rulebook,
        test_tape_is_public_and_order_free,
    ]:
        fn()
    print("\n" + "=" * 78)
    if FAILURES:
        print(f"FAILED {len(FAILURES)}: " + ", ".join(FAILURES))
        return 1
    print("ALL PASS")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
