#!/usr/bin/env python3
"""
dashboard.py — the session screen over the CLI.

Reads exactly the same config, clock and math as gate.py / scan.py / size.py, and
renders one page: the verdict, the ticket, the zone map, the fee-toll band, the
journal and the alerts. The screen can never disagree with the rules, because it
calls the same functions the terminal does.

The page itself is static — the browser talks only to this server, never to the
venue. There is no order path here, by construction.

  python3 dashboard.py                 # serve on :8787
  python3 dashboard.py --port 9000
  python3 dashboard.py --now 16:44     # freeze the clock (demo / replay)

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import argparse
import json
import os
import re
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import gate as gatelib
import journal as journallib
import scan as scanlib
import size as sizelib
from opslib import EAT, OpsConfig, money, price, session_clock

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, "dashboard.html")

# The desk's stated use is chat-only, so alerts are delivered as a block to paste
# into Claude / Arena rather than pushed to a channel. The block is the contract;
# a channel (email, Telegram, webhook) is a transport you add later.
ALERT_TEMPLATES = {
    "preopen": ("16:20", "Pre-open gate check",
                "Run the pre-open scan and arm the ticket. Do not send anything yet."),
    "range_start": ("16:30", "The range starts printing",
                    "Mark the high and the low from now. No trades until 16:45."),
    "gate": ("16:45", "THE GATE",
             "Read the 16:30-16:45 high and low off the 5-minute chart and paste them back."),
    "flat_warning": ("22:45", "15 minutes to the flat deadline",
                     "Anything still open at 23:00 is a rule breach, not a swing. A rule-1 swing is the only exception."),
    "flat": ("23:00", "Flat deadline",
             "You must be flat. Then run the debrief."),
}


def _clock(now_str: str | None, cfg: OpsConfig) -> dict:
    if not now_str:
        return session_clock(cfg=cfg)
    hh, mm = [int(x) for x in now_str.split(":")[:2]]
    base = datetime.now(EAT).replace(hour=hh, minute=mm, second=0, microsecond=0)
    return session_clock(base, cfg)


def _alerts(cfg: OpsConfig, clock: dict) -> list[dict]:
    """Which alerts are due, which are coming, and the paste-ready block for each."""
    mins = clock["minutes"]
    out = []
    for key, (when, title, body) in ALERT_TEMPLATES.items():
        hh, mm = [int(x) for x in when.split(":")]
        at = hh * 60 + mm
        if mins >= at + 15:
            state = "passed"
        elif mins >= at:
            state = "due"
        else:
            state = "upcoming"
        block = "\n".join([
            f"[{when} EAT — {title}]",
            body,
            f"Session phase right now: {clock['phase']} ({clock['label']}).",
            "Paste the app's numbers back and I will run the gate.",
        ])
        out.append({"key": key, "when": when, "title": title, "body": body,
                    "state": state, "minutes_away": at - mins, "paste_block": block})
    return out


def load_tape(path: str | None = None) -> dict | None:
    """The scheduled snapshot, if one has been committed. Never a position, never an order."""
    path = path or os.path.join(HERE, "data", "tape", "latest.json")
    if not os.path.exists(path):
        return None
    try:
        data = json.loads(open(path, encoding="utf-8").read())
    except (OSError, json.JSONDecodeError):
        return {"error": "unreadable", "orders": False}
    data["orders"] = False
    data["path"] = os.path.relpath(path, HERE)
    return data


def build_state(cfg: OpsConfig, now_str: str | None = None,
                r_high=None, r_low=None, brk=None, last=None) -> dict:
    clock = _clock(now_str, cfg)

    class A:
        pass
    a = A()
    a.last = last
    a.equity = None
    a.flat = False
    a.position = None
    a.range_high = r_high
    a.range_low = r_low
    a.chop = None
    a.break_side = brk
    a.daily_close = None
    a.size = None
    a.r = None

    v = gatelib.run_gate(cfg, clock, a)
    filled, missing = gatelib.verify_inputs(cfg)
    stale = not bool(cfg.st("account.equity_confirmed_in_app")) or bool(cfg.st("meta.stale"))

    last_px = last if last is not None else cfg.st("market.last")
    rows = scanlib.zone_map(cfg, last_px)
    reg = scanlib.regime_scan(cfg)
    ft = scanlib.feasibility_table(cfg, float(last_px)) if last_px else []

    ticket = None
    if v.ticket:
        t = v.ticket
        ticket = {
            "side": t["side"], "entry": t["entry"], "stop": t["stop"],
            "stop_pts": round(t["stop_pts"], 1), "stop_pct": round(t["stop_pct"], 2),
            "size_usd": round(t["size_usd"]), "units": round(t["units"], 4),
            "usd_per_point": round(t["usd_per_point"], 2),
            "margin_usd": round(t["margin_usd"], 2), "leverage": t["leverage"],
            "risk_usd": round(t["risk_usd"], 2), "target": t["target"],
            "target_pts": round(t["target_pts"], 1), "r_multiple": round(t["r_multiple"], 2),
            "net_target_usd": round(t["net_target_usd"], 2),
            "net_r_multiple": round(t["net_r_multiple"], 2),
            "fees_round_trip_usd": round(t["fees_round_trip_usd"], 2),
            "est_liq_price": round(t["est_liq_price"], 2),
            "legal": t["legal"],
            "warnings": t.get("warnings", []), "blocks": t.get("blocks", []),
        }

    trades = journallib.read_trades(os.path.join(HERE, "trades.csv"))
    journal = []
    for r in trades:
        an = journallib.analyse(r, cfg)
        journal.append({
            "id": r.get("id"), "date": r.get("date"), "side": r.get("side"),
            "size_usd": r.get("size_usd"), "entry": r.get("entry"), "exit": r.get("exit"),
            "status": r.get("status"), "net_pnl_usd": an["net_pnl"],
            "flags": an["flags"], "setup": r.get("setup"),
        })

    m = cfg.state.get("market", {}) or {}
    band = [row for row in ft if row["width"] in (60, 80, 100, 120, 130, 140, 150)]
    return {
        "clock": {"hhmm": clock["hhmm"], "date": clock["date"], "phase": clock["phase"],
                  "label": clock["label"], "minutes_to_gate": clock["minutes_to_gate"],
                  "minutes_to_flat": clock["minutes_to_flat"]},
        "verdict": {"kind": v.kind, "reason": v.reason, "title": v.title,
                    "management": v.management, "flip": v.flip, "notes": v.notes},
        "ticket": ticket,
        "inputs": {"ok": [{"label": label, "value": val} for label, _, val in filled],
                   "missing": [{"label": label, "path": path, "scope": scope}
                               for label, path, scope in missing],
                   "stale": stale},
        "market": {"last": m.get("last"), "change_24h_pct": m.get("change_24h_pct"),
                   "funding_pct_per_hr": m.get("funding_pct_per_hr"),
                   "open_interest_usd": m.get("open_interest_usd"),
                   "nq_futures_pct": m.get("nq_futures_pct"),
                   "ten_year_yield_pct": m.get("ten_year_yield_pct"),
                   "rsi_daily": m.get("rsi_daily"),
                   "as_of": cfg.st("meta.updated_eat"), "stale": bool(cfg.st("meta.stale"))},
        "regime": {"label": reg["label"], "total": reg["total"],
                   "contributors": reg["contributors"], "missing": reg["missing"]},
        "zones": [{"name": r["name"], "band": r["band"], "dist_pts": round(r.get("dist_pts", 0), 1),
                   "dist_pct": round(r.get("dist_pct", 0), 2), "kind": r["kind"]} for r in rows],
        "zone_now": scanlib.current_zone(rows, last_px),
        "band": [{"width": r["width"], "stop_pts": r["stop_pts"],
                  "fee_drag_r": round(r["fee_drag_r"], 2),
                  "net_r_at_ref": round(r["net_r_at_ref"], 2),
                  "net_r_at_min": round(r["net_r_at_min"], 2),
                  "be_at_min": round(r["be_at_min"]) if r["be_at_min"] else None,
                  "legal_at_min": r["legal_at_min"], "legal_at_ref": r["legal_at_ref"],
                  "max_size": round(r["max_size_for_budget"]),
                  "r_enforced": r["r_enforced"], "r_ref": r["r_ref"]} for r in band],
        "journal": journal,
        "alerts": _alerts(cfg, clock),
        "rules": {"min_target_r": cfg.get("day.min_target_r"),
                  "hard_cap_usd": cfg.get("day.hard_cap_usd"),
                  "day_risk_budget_usd": cfg.get("day.day_risk_budget_usd"),
                  "flat_by": cfg.get("session.flat_by"),
                  "range_window_minutes": cfg.get("day.range_window_minutes"),
                  "daily_close_ref": cfg.get("swing.daily_close_ref"),
                  "swing_gate": cfg.get("swing.gate_price")},
        "tape": load_tape(),
        "disclaimer": "Educational tooling only — not financial advice. This screen places no orders.",
    }


# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    cfg: OpsConfig = None  # set by main()

    def log_message(self, fmt, *args):  # quieter
        return

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            self._send(200, open(PAGE, "rb").read(), "text/html; charset=utf-8")
            return
        if path == "/api/state":
            body = json.dumps(build_state(self.cfg)).encode()
            self._send(200, body, "application/json")
            return
        if path == "/healthz":
            self._send(200, b"ok", "text/plain")
            return
        self._send(404, b"not found", "text/plain")

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        n = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            self._send(400, b'{"error":"bad json"}', "application/json")
            return
        if path == "/api/state":
            def num(k):
                v = payload.get(k)
                return float(v) if v not in (None, "") else None
            body = json.dumps(build_state(
                self.cfg, payload.get("now") or None, num("range_high"), num("range_low"),
                (payload.get("break") or None), num("last"))).encode()
            self._send(200, body, "application/json")
            return
        self._send(404, b"not found", "text/plain")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Signal Forge session dashboard")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--now", default=None, help="freeze the clock at HH:MM EAT (demo/replay)")
    args = ap.parse_args(argv)

    Handler.cfg = OpsConfig()
    if args.now:
        # A frozen clock is a demo aid: wrap build_state's default via the handler.
        Handler._frozen = args.now  # noqa: stored for visibility
        print(f"clock frozen at {args.now} EAT")

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Signal Forge dashboard on http://{args.host}:{args.port}")
    print("read-only — this server places no orders and talks to no venue")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
