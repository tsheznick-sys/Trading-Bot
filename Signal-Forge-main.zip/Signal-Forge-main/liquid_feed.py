#!/usr/bin/env python3
"""
liquid_feed.py — READ-ONLY market data adapter for Liquid XYZ100.

Liquid is a HIP-3 market on Hyperliquid rails, so the public data comes from the
Hyperliquid info endpoint with `"dex": "xyz"`. This module fetches:

  * last / mark / oracle price, 24h change, hourly funding, open interest, 24h volume
  * the 5-minute candles covering the US-open range window (16:30-16:45 EAT = 13:30-13:45 UTC)
  * optional L2 book depth (for the "walls are not stops" sanity check)

and writes them into config/state.yaml's shape so scan.py / gate.py consume them unchanged.

SAFETY — THIS FILE IS THE ONLY ONE IN THE KIT THAT TOUCHES THE NETWORK:
  * POST https://api.hyperliquid.xyz/info only. No other host, no other path.
  * Public market data request types only (allowlisted below).
  * NO API keys, NO wallet, NO signing, NO order/withdraw/transfer capability.
  * Read-only by construction: the info endpoint cannot place anything.
  The decision logic (gate.py, size.py, scan.py, journal.py) stays network-free.

!!! NOT VERIFIED FROM THE BUILD SANDBOX !!!
The sandbox that generated this file has no route to api.hyperliquid.xyz, so the
request/response shapes are written from the documented Hyperliquid info API and
have NOT been executed against the live endpoint. Run `--dry-run` first, then
`--probe` on your own machine, and correct FIELD_MAP / parsing if the venue's
schema differs. Prices are the venue's truth, never this file's.

Usage
-----
  python3 liquid_feed.py --dry-run              # print the exact requests, send nothing
  python3 liquid_feed.py --probe                # fetch meta + allMids, print raw JSON
  python3 liquid_feed.py --scan                 # full snapshot -> stdout
  python3 liquid_feed.py --range                # the 16:30-16:45 EAT range -> stdout
  python3 liquid_feed.py --write-state          # merge a full snapshot into config/state.yaml
  python3 liquid_feed.py --book                 # L2 depth (walls are not stops)

Requires network access to api.hyperliquid.xyz. Stdlib only.

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

INFO_URL = "https://api.hyperliquid.xyz/info"
DEX = "xyz"           # Liquid's HIP-3 builder dex on Hyperliquid
COIN = "XYZ100"       # Nasdaq-100 perp
TIMEOUT = 12

# Public, read-only request types. Anything not on this list is refused locally
# before a packet is sent — this adapter has no mutating vocabulary.
ALLOWED_TYPES = frozenset({
    "meta", "allMids", "metaAndAssetCtxs", "candleSnapshot", "l2Book", "fundingHistory",
})

EAT = timezone(timedelta(hours=3), "EAT")
UTC = timezone.utc

# US open 16:30 EAT == 13:30 UTC. The playbook's window is 16:30-16:45 EAT (15 min)
# even though it is called the "first 5-min range" — see RANGE_WINDOW_MINUTES.
US_OPEN_UTC = (13, 30)
RANGE_WINDOW_MINUTES = 15
RANGE_TF_MINUTES = 5

# Liquid XYZ100 tracks ~0.7% UNDER NQ futures (standing market fact).
NQ_DISCOUNT_PCT = 0.7


class FeedError(RuntimeError):
    pass


# --------------------------------------------------------------------------
def build_request(req_type: str, **params) -> dict:
    """Construct an allowlisted public info request. Refuses anything else."""
    if req_type not in ALLOWED_TYPES:
        raise FeedError(
            f"refused: request type {req_type!r} is not on the read-only allowlist "
            f"{sorted(ALLOWED_TYPES)}. This adapter cannot mutate anything."
        )
    body: dict = {"type": req_type}
    if req_type in ("meta", "allMids", "metaAndAssetCtxs"):
        body["dex"] = DEX
    elif req_type == "candleSnapshot":
        req = {"coin": params.get("coin", COIN),
               "interval": params.get("interval", "5m"),
               "startTime": int(params["start_ms"]),
               "endTime": int(params["end_ms"])}
        if params.get("dex", DEX):
            req["dex"] = params.get("dex", DEX)
        body["req"] = req
    elif req_type == "l2Book":
        body["coin"] = params.get("coin", COIN)
        body["dex"] = params.get("dex", DEX)
        if params.get("n_sig_figs"):
            body["nSigFigs"] = params["n_sig_figs"]
    elif req_type == "fundingHistory":
        body["coin"] = params.get("coin", COIN)
        body["startTime"] = int(params["start_ms"])
        body["dex"] = params.get("dex", DEX)
    return body


def post(body: dict, dry_run: bool = False):
    """POST one request to the info endpoint. dry_run prints it and sends nothing."""
    if dry_run:
        return {"_dry_run": True, "url": INFO_URL, "body": body}
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        INFO_URL, data=data,
        headers={"Content-Type": "application/json", "User-Agent": "signal-forge-ops/1.0 read-only"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise FeedError(f"HTTP {exc.code} from {INFO_URL}: {exc.read()[:300]!r}") from exc
    except urllib.error.URLError as exc:
        raise FeedError(
            f"cannot reach {INFO_URL}: {exc.reason}. "
            "This host must be reachable from the machine running the feed — the build "
            "sandbox is not. Prices remain the venue's truth."
        ) from exc
    except json.JSONDecodeError as exc:
        raise FeedError(f"non-JSON response from {INFO_URL}: {exc}") from exc


# --------------------------------------------------------------------------
# Time helpers
# --------------------------------------------------------------------------
def us_open_utc_today(now_utc: datetime | None = None) -> datetime:
    now = now_utc or datetime.now(UTC)
    return now.replace(hour=US_OPEN_UTC[0], minute=US_OPEN_UTC[1], second=0, microsecond=0)


def range_window(now_utc: datetime | None = None) -> tuple[datetime, datetime, bool]:
    """Start/end of the US-open range window in UTC, and whether it has fully printed."""
    now = now_utc or datetime.now(UTC)
    start = us_open_utc_today(now)
    end = start + timedelta(minutes=RANGE_WINDOW_MINUTES)
    return start, end, now >= end


def to_eat(dt_utc: datetime) -> str:
    return dt_utc.astimezone(EAT).strftime("%H:%M")


# --------------------------------------------------------------------------
# Parsing
# --------------------------------------------------------------------------
def _f(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def parse_ctx(meta_resp) -> dict:
    """metaAndAssetCtxs -> [meta, [ctx, ...]]. Pull the XYZ100 row out by name."""
    if not isinstance(meta_resp, (list, tuple)) or len(meta_resp) < 2:
        raise FeedError(f"unexpected metaAndAssetCtxs shape: {str(meta_resp)[:200]}")
    meta, ctxs = meta_resp[0], meta_resp[1]
    universe = (meta or {}).get("universe") or []
    names = [str(u.get("name")) for u in universe]

    def _is_ours(name: str) -> bool:
        # The documented HIP-3 name is "xyz:XYZ100". Some payloads use the bare coin.
        return name == COIN or name == f"{DEX}:{COIN}" or name.endswith(":" + COIN)

    matches = [i for i, name in enumerate(names) if _is_ours(name)]
    if not matches:
        raise FeedError(
            f"{COIN} not in the {DEX!r} universe. Found: {names[:25]}. "
            "If Liquid lists it under another coin name, set COIN at the top of this file."
        )
    idx = matches[0]
    if idx >= len(ctxs):
        raise FeedError(f"universe has {len(names)} assets but only {len(ctxs)} ctx rows")
    ctx = ctxs[idx] or {}
    uni = universe[idx] or {}

    mark = _f(ctx.get("markPx"))
    oracle = _f(ctx.get("oraclePx"))
    mid = _f(ctx.get("midPx"))
    prev = _f(ctx.get("prevDayPx"))
    oi = _f(ctx.get("openInterest"))          # base units, not notional
    funding = _f(ctx.get("funding"))          # hourly rate as a decimal fraction

    last = mark if mark is not None else (mid if mid is not None else oracle)
    return {
        "coin": COIN,
        "dex": DEX,
        "last": last,
        "mark": mark,
        "oracle": oracle,
        "mid": mid,
        "prev_day_px": prev,
        "change_24h_pct": (100.0 * (last / prev - 1)) if (last and prev) else None,
        # Hyperliquid funding is an hourly decimal fraction -> express in %/hr
        "funding_pct_per_hr": (funding * 100.0) if funding is not None else None,
        "funding_decimal_per_hr": funding,
        "open_interest_units": oi,
        "open_interest_usd": (oi * (mark or oracle or last)) if (oi is not None and last) else None,
        "day_ntl_vlm_usd": _f(ctx.get("dayNtlVlm")),
        "max_leverage": uni.get("maxLeverage"),
        "sz_decimals": uni.get("szDecimals"),
        "impact_pxs": ctx.get("impactPxs"),
        "fetched_utc": datetime.now(UTC).isoformat(timespec="seconds"),
    }


def parse_range(candles, start_utc: datetime, end_utc: datetime) -> dict:
    """High/low of the candles overlapping the range window."""
    if not candles:
        return {"printed": False, "high": None, "low": None, "width_pts": None,
                "candles": 0, "window_eat": f"{to_eat(start_utc)}-{to_eat(end_utc)}",
                "note": "no candles returned — window may not have started, or the dex/coin name differs"}
    lo_s, hi_e = int(start_utc.timestamp() * 1000), int(end_utc.timestamp() * 1000)
    inside = []
    for c in candles:
        t_open = int(_f(c.get("t"), 0) or 0)
        t_close = int(_f(c.get("T"), 0) or 0)
        if t_open >= lo_s - 1 and (t_close or t_open) <= hi_e + 1:
            inside.append(c)
    use = inside or candles
    highs = [_f(c.get("h")) for c in use if _f(c.get("h")) is not None]
    lows = [_f(c.get("l")) for c in use if _f(c.get("l")) is not None]
    if not highs or not lows:
        return {"printed": False, "high": None, "low": None, "width_pts": None,
                "candles": len(use), "window_eat": f"{to_eat(start_utc)}-{to_eat(end_utc)}",
                "note": "candles returned but had no h/l fields"}
    hi, lo = max(highs), min(lows)
    fully_printed = datetime.now(UTC) >= end_utc and len(use) * RANGE_TF_MINUTES >= RANGE_WINDOW_MINUTES
    return {
        "printed": bool(fully_printed),
        "high": hi,
        "low": lo,
        "width_pts": hi - lo,
        "candles": len(use),
        "window_eat": f"{to_eat(start_utc)}-{to_eat(end_utc)}",
        "window_utc": f"{start_utc.strftime('%H:%M')}-{end_utc.strftime('%H:%M')}",
        "long_trigger": hi + 5.0,
        "short_trigger": lo - 5.0,
        "note": None if fully_printed else
                "window has not fully printed yet — the gate is at 16:45 EAT, do not trade a partial range",
    }


def parse_book(book) -> dict:
    """Summarise L2 depth. Order-book walls are NOT stops — this exists to show that."""
    levels = book.get("levels") if isinstance(book, dict) else None
    if not levels or len(levels) < 2:
        return {"error": "unexpected l2Book shape"}
    bids, asks = levels[0], levels[1]

    def agg(side, n=10):
        out, cum = [], 0.0
        for lv in side[:n]:
            px, sz = _f(lv.get("px")), _f(lv.get("n") or lv.get("sz"))
            if px is None or sz is None:
                continue
            cum += px * sz
            out.append({"px": px, "sz": sz, "notional_usd": px * sz})
        return out, cum

    b, b_not = agg(bids)
    a, a_not = agg(asks)
    top_bid = b[0]["px"] if b else None
    top_ask = a[0]["px"] if a else None
    return {
        "top_bid": top_bid, "top_ask": top_ask,
        "spread_pts": (top_ask - top_bid) if (top_bid and top_ask) else None,
        "bid_notional_10": b_not, "ask_notional_10": a_not,
        "imbalance": (b_not - a_not) / (b_not + a_not) if (b_not + a_not) else None,
        "largest_bid": max(b, key=lambda x: x["notional_usd"]) if b else None,
        "largest_ask": max(a, key=lambda x: x["notional_usd"]) if a else None,
        "warning": "resting size is not support and not a stop — $1M+ walls vanish on headlines",
    }


# --------------------------------------------------------------------------
# High-level fetches
# --------------------------------------------------------------------------
def fetch_candles(start_ms: int, end_ms: int, interval: str = "1m"):
    """Try the documented HIP-3 coin name, then the bare one. Empty is not an error."""
    notes = []
    for coin in (f"{DEX}:{COIN}", COIN):
        body = build_request("candleSnapshot", coin=coin, interval=interval,
                             start_ms=start_ms, end_ms=end_ms)
        try:
            resp = post(body)
        except FeedError as exc:
            notes.append(f"{coin}: {exc}")
            continue
        if isinstance(resp, list) and resp:
            return resp, coin
        notes.append(f"{coin}: {type(resp).__name__} empty-or-unexpected")
    return [], "; ".join(notes)


def write_tape(scan: dict, directory: str = "data/tape") -> str:
    """One public snapshot. No account, no position, no order."""
    os.makedirs(directory, exist_ok=True)
    payload = {
        "source": "liquid_feed.py",
        "orders": False,
        "host": INFO_URL,
        "as_of_utc": scan.get("as_of_utc"),
        "as_of_eat": scan.get("as_of_eat"),
        "context": scan.get("context"),
        "range": scan.get("range"),
        "basis": scan.get("basis"),
    }
    latest = os.path.join(directory, "latest.json")
    tmp = latest + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
        fh.write("\n")
    os.replace(tmp, latest)
    day = str(scan.get("as_of_eat") or "")[:10] or datetime.now(EAT).strftime("%Y-%m-%d")
    with open(os.path.join(directory, f"{day}.jsonl"), "a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload) + "\n")
    return latest


def fetch_history(days: int, out_path: str, pause: float = 0.4) -> dict:
    """1-minute bars for each weekday session, 13:25-20:05 UTC (16:25-23:05 EAT).

    That window is the range, the management, and the 23:00 flat. Nothing else.
    """
    now = datetime.now(UTC)
    candles: list[dict] = []
    gaps: list[str] = []
    coin_used = None
    pulled = 0
    for back in range(int(days) - 1, -1, -1):
        day = (now - timedelta(days=back)).astimezone(EAT)
        if day.weekday() >= 5:
            continue
        start = day.replace(hour=16, minute=25, second=0, microsecond=0).astimezone(UTC)
        end = day.replace(hour=23, minute=5, second=0, microsecond=0).astimezone(UTC)
        if end > now:
            end = now
        if start >= end:
            continue
        rows, coin = fetch_candles(int(start.timestamp() * 1000), int(end.timestamp() * 1000), "1m")
        pulled += 1
        if coin:
            coin_used = coin
        if not rows:
            gaps.append(day.strftime("%Y-%m-%d"))
        else:
            candles.extend(rows)
        label = day.strftime("%Y-%m-%d")
        print(f"  {label}  {len(rows):4} bars  coin={coin or '-'}", file=sys.stderr)
        time.sleep(pause)
    candles.sort(key=lambda c: int(c.get("t", 0)))
    deduped = []
    for c in candles:
        if deduped and int(deduped[-1].get("t", 0)) == int(c.get("t", 0)):
            deduped[-1] = c
        else:
            deduped.append(c)
    payload = {
        "meta": {
            "source": "liquid_feed.py --history",
            "orders": False,
            "coin_used": coin_used,
            "interval": "1m",
            "window_eat": "16:25-23:05",
            "days_requested": int(days),
            "weekdays_pulled": pulled,
            "gaps": gaps,
            "candles": len(deduped),
            "fetched_utc": datetime.now(UTC).isoformat(timespec="seconds"),
        },
        "candles": deduped,
    }
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh)
        fh.write("\n")
    return payload["meta"]


def snapshot(dry_run: bool = False) -> dict:
    return parse_ctx(post(build_request("metaAndAssetCtxs"), dry_run)) if not dry_run \
        else post(build_request("metaAndAssetCtxs"), dry_run=True)


def full_scan(dry_run: bool = False) -> dict:
    """One pass: quote context + the range window + implied NQ basis."""
    if dry_run:
        start, end, printed = range_window()
        return {
            "_dry_run": True,
            "requests": [
                build_request("metaAndAssetCtxs"),
                build_request("candleSnapshot", interval=f"{RANGE_TF_MINUTES}m",
                              start_ms=int(start.timestamp() * 1000) - 3_600_000,
                              end_ms=int(end.timestamp() * 1000) + 3_600_000),
            ],
            "range_window_eat": f"{to_eat(start)}-{to_eat(end)}",
            "range_window_utc": f"{start.strftime('%H:%M')}-{end.strftime('%H:%M')}",
            "note": "nothing was sent. Run without --dry-run on a machine that can reach the endpoint.",
        }

    ctx = snapshot()
    start, end, printed = range_window()
    candles, coin_used = fetch_candles(
        int(start.timestamp() * 1000) - 3_600_000,
        int(end.timestamp() * 1000) + 3_600_000,
        f"{RANGE_TF_MINUTES}m")
    rng = parse_range(candles, start, end)
    rng["coin_used"] = coin_used

    last = ctx.get("last")
    return {
        "context": ctx,
        "range": rng,
        "basis": {
            "nq_discount_pct": NQ_DISCOUNT_PCT,
            "implied_nq_equivalent": (last / (1 - NQ_DISCOUNT_PCT / 100.0)) if last else None,
            "rule": "XYZ100 prints ~0.7% under NQ futures — Liquid levels trigger, futures bias only",
        },
        "funding_cost": {
            "per_hour_on_5000_usd": (abs(ctx.get("funding_pct_per_hr") or 0) / 100.0) * 5000,
            "per_hour_on_12548_usd": (abs(ctx.get("funding_pct_per_hr") or 0) / 100.0) * 12548,
            "note": "hourly funding x notional; a paid long bleeds this every hour it is held",
        },
        "as_of_utc": datetime.now(UTC).isoformat(timespec="seconds"),
        "as_of_eat": datetime.now(UTC).astimezone(EAT).strftime("%Y-%m-%d %H:%M EAT"),
    }


def state_patch(scan: dict) -> dict:
    """Shape a full_scan() result into the config/state.yaml Part 3 structure."""
    ctx, rng = scan.get("context", {}), scan.get("range", {})
    return {
        "meta": {"date": datetime.now(EAT).strftime("%Y-%m-%d"),
                 "updated_eat": datetime.now(EAT).strftime("%H:%M"),
                 "stale": False, "filled_by": "liquid_feed.py"},
        "account": {"position_status": None},   # NEVER inferred from market data
        "market": {
            "symbol": COIN,
            "last": ctx.get("last"),
            "change_24h_pct": ctx.get("change_24h_pct"),
            "funding_pct_per_hr": ctx.get("funding_pct_per_hr"),
            "open_interest_usd": ctx.get("open_interest_usd"),
            "as_of_eat": scan.get("as_of_eat"),
        },
        "range_5m": {
            "printed": rng.get("printed"),
            "high": rng.get("high"),
            "low": rng.get("low"),
            "width_pts": rng.get("width_pts"),
        },
    }


# --------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Read-only Liquid XYZ100 market data adapter.")
    ap.add_argument("--dry-run", action="store_true", help="print the requests, send nothing")
    ap.add_argument("--probe", action="store_true", help="raw meta + allMids JSON")
    ap.add_argument("--scan", action="store_true", help="full snapshot (context + range + basis)")
    ap.add_argument("--range", action="store_true", help="just the 16:30-16:45 EAT range")
    ap.add_argument("--book", action="store_true", help="L2 depth summary")
    ap.add_argument("--state-patch", action="store_true", help="print the config/state.yaml patch")
    ap.add_argument("--json", action="store_true", help="raw JSON instead of a summary")
    ap.add_argument("--write-tape", action="store_true",
                    help="write data/tape/latest.json — public snapshot, no account, no order")
    ap.add_argument("--history", action="store_true",
                    help="pull 1-minute session bars for the backtest")
    ap.add_argument("--days", type=int, default=40, help="weekdays-or-calendar lookback for --history")
    ap.add_argument("--out", default=None, help="output path for --history or --write-tape")
    args = ap.parse_args(argv)

    try:
        if args.dry_run:
            print(json.dumps(full_scan(dry_run=True), indent=2))
            print("\nNothing was sent. This adapter has no mutating vocabulary: "
                  f"{sorted(ALLOWED_TYPES)}.")
            return 0
        if args.probe:
            meta = post(build_request("meta"))
            mids = post(build_request("allMids"))
            print(json.dumps({"meta": meta, "allMids": mids}, indent=2)[:4000])
            return 0
        if args.book:
            book = post(build_request("l2Book", n_sig_figs=5))
            print(json.dumps(parse_book(book), indent=2))
            return 0

        start, end, printed = range_window()
        if args.range:
            candles = post(build_request(
                "candleSnapshot", interval=f"{RANGE_TF_MINUTES}m",
                start_ms=int(start.timestamp() * 1000) - 3_600_000,
                end_ms=int(end.timestamp() * 1000) + 3_600_000))
            out = parse_range(candles if isinstance(candles, list) else [], start, end)
            print(json.dumps(out, indent=2))
            return 0

        if args.history:
            out = args.out or "data/history/xyz100-1m.json"
            meta = fetch_history(args.days, out)
            print(json.dumps(meta, indent=2))
            return 0
        if args.write_tape:
            scan = full_scan()
            path = write_tape(scan, args.out or "data/tape")
            print(path)
            print(json.dumps({"as_of_eat": scan.get("as_of_eat"),
                              "last": (scan.get("context") or {}).get("last"),
                              "orders": False}, indent=2))
            return 0

        scan = full_scan()
        if args.state_patch:
            print(json.dumps(state_patch(scan), indent=2))
            return 0
        if args.json:
            print(json.dumps(scan, indent=2))
            return 0

        ctx, rng = scan["context"], scan["range"]
        print("=" * 74)
        print(f"LIQUID {COIN} SCAN — {scan['as_of_eat']}  (read-only, dex={DEX})")
        print("=" * 74)
        print(f"  last/mark     {ctx.get('last')}   (oracle {ctx.get('oracle')}, mid {ctx.get('mid')})")
        print(f"  24h change    {ctx.get('change_24h_pct'):.3f}%" if ctx.get("change_24h_pct") is not None
              else "  24h change    n/a")
        print(f"  funding       {ctx.get('funding_pct_per_hr'):.5f}%/hr" if ctx.get("funding_pct_per_hr") is not None
              else "  funding       n/a")
        print(f"  open interest {ctx.get('open_interest_usd'):,.0f} USDC  ({ctx.get('open_interest_units')} units)"
              if ctx.get("open_interest_usd") else "  open interest n/a")
        print(f"  24h volume    {ctx.get('day_ntl_vlm_usd'):,.0f} USDC" if ctx.get("day_ntl_vlm_usd") else "")
        print(f"  max leverage  {ctx.get('max_leverage')}x")
        print()
        print(f"  range window  {rng.get('window_eat')} EAT  ({rng.get('window_utc')} UTC)")
        print(f"  printed       {rng.get('printed')}   candles used: {rng.get('candles')}")
        if rng.get("high") is not None:
            print(f"  HIGH / LOW    {rng['high']} / {rng['low']}   width {rng['width_pts']:.1f} pts")
            print(f"  long trigger  1-min close above {rng['long_trigger']}")
            print(f"  short trigger 1-min close below {rng['short_trigger']}")
        if rng.get("note"):
            print(f"  note          {rng['note']}")
        print()
        b = scan["basis"]
        if b.get("implied_nq_equivalent"):
            print(f"  implied NQ    {b['implied_nq_equivalent']:.2f}  "
                  f"(XYZ100 + {NQ_DISCOUNT_PCT}% = the futures equivalent; use Liquid levels to trigger)")
        fc = scan["funding_cost"]
        print(f"  funding cost  ${fc['per_hour_on_5000_usd']:.4f}/hr on $5,000 · "
              f"${fc['per_hour_on_12548_usd']:.4f}/hr on $12,548")
        print("=" * 74)
        print("Feed data is context, never a trigger. Run: python3 scan.py --live  then  python3 gate.py")
        return 0
    except FeedError as exc:
        print(f"FEED ERROR: {exc}", file=sys.stderr)
        return 4
    except Exception as exc:  # noqa: BLE001
        print(f"UNEXPECTED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
