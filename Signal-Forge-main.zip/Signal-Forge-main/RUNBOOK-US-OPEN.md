# RUNBOOK-US-OPEN.md — the 4-minute version

Print this. Everything else is reference. Times are **EAT (Nairobi, UTC+3)**.

**Educational material only — not financial advice.**

---

## 16:20 — PRE-OPEN (60 seconds, arm only)

```bash
python3 dashboard.py              # one screen: verdict, ticket, zones, band, alerts
python3 scan.py --at 16:20        # the same numbers, in the terminal
python3 gate.py --show-inputs     # which Part 1 brackets are still blank
```

The dashboard is the CLI rendered — it calls the same functions, so the two cannot disagree. If a
`data/tape/latest.json` exists, the screen shows that snapshot and its age. The tape is public
market data written by a scheduled job. It is not your position, and it is not a fill. You still
place the order in the Liquid app.

On a machine that can reach `api.hyperliquid.xyz`, `python3 scan.py --live` pulls last / funding /
OI / 24h% and the range window for you via `liquid_feed.py` (read-only, no keys, cannot place
anything). Position status and equity are **never** inferred from a feed — read them off the app.

Read off the app and fill `config/state.yaml`:

- [ ] **Equity** $______ (confirm in app — do not reuse yesterday's number)
- [ ] **Position:** FLAT / LONG / SHORT ______  ← *if UNCONFIRMED, stop here and confirm it*
- [ ] XYZ100 last ______ · 24h% ______ · funding/hr ______ · OI $______
- [ ] NQ futures ______% · 10Y ______% · macro today: ______________

**Arm, do not send:**

```bash
python3 size.py --swing          # the swing ticket, pre-built
```

Swing gate = **daily CLOSE above 31,366**. Wicks don't count. If last is far below it, the swing
is not happening today — the day trade is the only live plan.

> ❗ **Rule 6 gate:** if a position is already open, or its status is UNCONFIRMED, there are
> **no new entries today**. `gate.py` will refuse. Manage what you have.

---

## 16:30–16:45 — THE RANGE PRINTS (do nothing)

- [ ] Mark the **HIGH** and **LOW** of the first 5-minute range. Write them down.
- [ ] **No trades while it prints.** Rising OI into the open = leveraged and whippy.
- [ ] Note how many minutes price chops *inside* the range: ______ min

| H | L | Width |
|---|---|---|
| ________ | ________ | ________ pts |

**Pre-decide now, before you have a position:** at +1R do I take half and go to breakeven, or hold
the full size to target? Write the answer: ______________

---

## 16:45 — THE GATE (90 seconds)

```bash
python3 gate.py --now 16:45 --flat \
    --range-high <H> --range-low <L> \
    --break <long|short|omit> --last <price>
```

Omit `--break` until a **1-minute candle CLOSES** beyond an edge (+5 / −5 pts). A touch is not a break.

### Instant disqualifiers — skip and walk away

- [ ] Range **> 150 pts** wide → **SKIP**
- [ ] Chop inside the range **> 15 min** → **SKIP**
- [ ] Macro (FOMC/CPI/Fed) **within 1 hour** and size > $2,500 → **SKIP or cap at $2,500**
- [ ] No 1-min close beyond an edge → **SKIP**
- [ ] `gate.py` says **FEE FILTER** → see the fee toll below

### If it fires

`gate.py` prints the ticket. Read it back out loud before you touch the app:

```
entry ____  stop ____ (____ pts / ____%)  size $____  margin $____
risk  $____  target ____ (____R)  est. liq ____
```

**Order construction — every single time:**

1. **Leverage 5x ISOLATED first.** Then size. (margin = notional ÷ 5)
2. **Market or Limit only.** If you see "Running Time / Randomize" that is **TWAP** — switch back.
3. Reduce Only **OFF** for the entry.
4. **TP and SL sent with the entry.**
5. Open **Open Orders** and *see the stop resting there*. A chart drawing is not a stop.
6. Size: **$5,000** standard · $7,500–10,000 only if the range is ≤80 pts and clean ·
   **HARD CAP $10,000**. If the stop costs more than **$40**, cut the size — never widen the stop.

---

## LIVE — management

- [ ] **+1R** → execute the plan you pre-decided at 16:44. Half off + stop to BE, or hold to target.
- [ ] **Long:** first target 31,039–31,050 · partial zone 31,080–31,100 · trail under 31,000 once +1R
- [ ] **Short:** partial zone 30,900–30,918 · trail above 31,000 once +1R
- [ ] **Time stop:** no progress in **45 min** → flat. Do not hope.
- [ ] **Never widen a stop. Never add to a loser. One index position at a time.**
- [ ] Macro print coming? Flat or ≤$2,500 with a breakeven+ stop **5 minutes BEFORE**.

```bash
python3 gate.py --mode position --mark <price>     # mark-to-market + zone map
python3 size.py --position --side long --notional 12548 --entry 30918 --mark <price>
```

---

## 23:00 — FLAT, no exceptions

- [ ] **Flat.** If a position is open, close it. Overnight holds mix swing and day theses.
- [ ] Log every fill:

```bash
python3 journal.py log   --date <YYYY-MM-DD> --side <long|short> --size <usd> \
                         --entry <px> --stop <px> --target <px> --opened <HH:MM>
python3 journal.py close --id <n> --exit <px> --closed <HH:MM> --reason <reason>
python3 journal.py summary      # R proof + rule-violation scan
python3 journal.py debrief
```

- [ ] Check **price R** vs **R achieved**. The gap is what fees and slippage cost you.
- [ ] Update `config/state.yaml` (Part 3) with the fresh numbers.
- [ ] Re-check `config/levels.yaml` if the 20-day-high gate moved (weekly).
- [ ] `git add -A && git commit -m "debrief <date>" && git push`

**Three questions, answered honestly in the notes field:**

1. Did I follow the plan, or did I improvise? (The R tells you — not the PnL.)
2. Where did I give profit back? Which zone should have taken the partial?
3. Which rule did I bend? Name it, then size down next session until it is clean.

---

## The fee toll (read this once, remember it forever)

The minimum target is **2.0R** — raised from 1.5R on 8 Oct 2026, because at 1.5R rule 4's
"fees ≤20% of target" needs a **186-pt stop** while rule 4's own 150-pt width cap only allows
**165 pts**. **186 > 165**: the two rules could never both be satisfied, at any ticket size.
The fee ratio is **size-invariant** — you cannot out-size a bad ratio.

| Minimum target | Range needed to clear rule 4 | Verdict |
|---|---|---|
| 1.5R (legacy) | 171+ pts | ✗ forbidden by rule 4 — unsatisfiable |
| **2.0R (enforced)** | **125–150 pts** | ✓ the legal band |

So the operative rule is: **trade only a 125–150 pt range, at a 2.0R target, sized to the $40
budget ($7,514–$8,551 — the budget binds before the $10,000 cap).** Break-even win rate ~38%.
Outside that band the answer is SKIP. Full derivation: `PLAYBOOK.md` §5.

**A SKIP is a successful day.** The plan working looks like nothing happening.

### Break-even win rates (`python3 scan.py` prints this table live)

net_R = target_R − fee_drag, where fee_drag = `2 × taker × entry / stop_pts` — **size-invariant**.
Break-even win rate = `1 / (1 + net_R)`.

| Range width | Stop pts | Fee drag | net R @1.5 | BE win rate @1.5 | net R @2.0 | BE @2.0 | Max size for $40 | Legal @2R |
|---|---|---|---|---|---|---|---|---|
| 60 | 75 | 0.74R | +0.76 | 57% | +1.26 | 44% | $10,000 | ✗ |
| 80 | 95 | 0.59R | +0.91 | 52% | +1.41 | 41% | $10,000 | ✗ |
| 120 | 135 | 0.41R | +1.09 | 48% | +1.59 | 39% | $9,184 | ✗ |
| 130 | 145 | 0.38R | +1.12 | 47% | +1.62 | 38% | $8,551 | ✓ |
| 150 | 165 | 0.34R | +1.16 | 46% | +1.66 | 38% | $7,514 | ✓ |

*(at entry ≈ 31,000. A $5,000 ticket that hits exactly +1R on a 60-pt range nets **+0.26R**.)*
