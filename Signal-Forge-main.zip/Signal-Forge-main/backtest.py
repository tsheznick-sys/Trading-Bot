#!/usr/bin/env python3
"""
backtest.py — the written rulebook, replayed on 1-minute candles. Network-free.

It trades only rule 2, exactly as config/risk.yaml states it:

  * range = high/low of 16:30-16:45 EAT
  * entry signal = a 1-minute CLOSE beyond the edge by 5 pts, within 15 minutes
  * fill = the NEXT bar's open (you see the close, then you tap)
  * stop = the opposite edge ∓ 10 pts, target = the ticket's 2.0R price
  * size = $5,000, cut to the $40 budget, never above $10,000
  * a bar that trades both stop and target is a stop
  * a gap through the stop exits at the open, not at the stop
  * no progress in 45 minutes -> flat; hard flat at 23:00 EAT
  * one trade a day, weekdays only, no overnight, no swing mixed in

A 5-minute file is refused. The rule is a 1-minute close, and this will not
pretend a coarser bar is that close.

The report is allowed to say the rules lose. Fewer than 30 taken trades is
INSUFFICIENT, never an edge. Macro blackouts and the 10Y headwind are NOT
applied — a CPI day is treated as a normal day, which flatters the result.

  python3 backtest.py --demo
  python3 backtest.py --candles data/history/xyz100-1m.json
  python3 backtest.py --candles data/history/xyz100-1m.json --out data/history/backtest-latest.txt

Educational tooling only — not financial advice.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone

import size as sizelib
from opslib import OpsConfig, money, price, risk_usd, taker_fees_round_trip, units

EAT = timezone(timedelta(hours=3), "EAT")
UTC = timezone.utc
MIN_TRADES_FOR_A_CLAIM = 30


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _open_eat(candle: dict) -> datetime:
    return datetime.fromtimestamp(int(candle["t"]) / 1000, tz=UTC).astimezone(EAT)


def load_candles(path: str) -> tuple[list[dict], dict]:
    raw = json.loads(open(path, encoding="utf-8").read())
    meta = raw.get("meta", {}) if isinstance(raw, dict) else {}
    rows = raw["candles"] if isinstance(raw, dict) else raw
    out = []
    for c in rows:
        o, h, l, cl = _num(c.get("o")), _num(c.get("h")), _num(c.get("l")), _num(c.get("c"))
        if None in (o, h, l, cl) or "t" not in c:
            continue
        out.append({"t": int(c["t"]), "T": int(c.get("T") or int(c["t"]) + 60_000),
                    "o": o, "h": h, "l": l, "c": cl})
    out.sort(key=lambda c: c["t"])
    deduped = []
    for c in out:
        if deduped and deduped[-1]["t"] == c["t"]:
            deduped[-1] = c
        else:
            deduped.append(c)
    return deduped, meta


def assert_one_minute(candles: list[dict]) -> None:
    if len(candles) < 3:
        raise SystemExit("not enough candles to judge an interval")
    deltas = sorted(candles[i + 1]["t"] - candles[i]["t"] for i in range(len(candles) - 1))
    step = deltas[len(deltas) // 2]
    if not (55_000 <= step <= 65_000):
        raise SystemExit(
            f"refusing a {step / 1000:.0f}s file. Rule 2 is a 1-minute close. "
            "A coarser bar is not that close, and this backtest will not pretend it is."
        )


def _day_key(dt: datetime) -> str:
    return dt.astimezone(EAT).strftime("%Y-%m-%d")


def _at(day: str, hhmm: str) -> datetime:
    hh, mm = [int(x) for x in hhmm.split(":")]
    y, m, d = [int(x) for x in day.split("-")]
    return datetime(y, m, d, hh, mm, tzinfo=EAT)


def walk_exit(side: str, stop: float, target: float, after: list[dict],
              fill_time: datetime, time_stop_min: int) -> tuple[str, float]:
    """Bars after the fill. Stop wins a tie. A gap through the stop exits at the open."""
    deadline = fill_time + timedelta(minutes=time_stop_min)
    flat_at = fill_time.replace(hour=23, minute=0, second=0, microsecond=0)
    last_close = after[-1]["c"] if after else None
    for c in after:
        opened = _open_eat(c)
        if opened >= flat_at:
            return "flat", c["o"]
        if side == "long" and c["o"] <= stop:
            return "stop", c["o"]
        if side == "short" and c["o"] >= stop:
            return "stop", c["o"]
        if side == "long" and c["o"] >= target:
            return "target", c["o"]
        if side == "short" and c["o"] <= target:
            return "target", c["o"]
        hit_stop = c["l"] <= stop if side == "long" else c["h"] >= stop
        hit_target = c["h"] >= target if side == "long" else c["l"] <= target
        if hit_stop:
            return "stop", stop
        if hit_target:
            return "target", target
        if opened + timedelta(minutes=1) >= deadline:
            return "time", c["c"]
        last_close = c["c"]
    return "flat", last_close


def _skip(day: str, reason: str, **extra) -> dict:
    row = {"date": day, "taken": False, "reason": reason}
    row.update(extra)
    return row


def replay_day(cfg: OpsConfig, day: str, bars: list[dict]) -> dict:
    d = cfg.get("day", {})
    window = int(d.get("range_window_minutes", 15))
    chop_limit = int(d.get("skip_chop_inside_range_minutes", 15))
    wide = float(d.get("skip_range_wider_than_pts", 150))
    time_stop = int(d.get("time_stop_minutes", 45))
    start = _at(day, "16:30")
    end = start + timedelta(minutes=window)
    flat_at = _at(day, "23:00")

    rng = [c for c in bars if start <= _open_eat(c) < end]
    if len(rng) < window - 3:
        return _skip(day, "incomplete_range", bars=len(rng))
    hi = max(c["h"] for c in rng)
    lo = min(c["l"] for c in rng)
    width = hi - lo
    if width <= 0:
        return _skip(day, "empty_range")
    if width > wide:
        return _skip(day, "width", width=round(width, 1))

    # Legality does not depend on which side breaks. Probe the long ticket;
    # the fee ratio is size-invariant and nearly identical the other way.
    try:
        probe = sizelib.build_day_ticket(cfg, "long", hi, lo, None, None)
    except sizelib.TicketBlocked as exc:
        return _skip(day, "blocked", width=round(width, 1), detail=str(exc))
    if not probe["legal"]:
        return _skip(day, "fee_filter", width=round(width, 1),
                     detail=probe["blocks"][0] if probe["blocks"] else "illegal")

    after = [c for c in bars if end <= _open_eat(c) < flat_at]
    long_trig = hi + float(d.get("entry_buffer_pts", 5))
    short_trig = lo - float(d.get("entry_buffer_pts", 5))
    signal = None
    for c in after:
        opened = _open_eat(c)
        waited = (opened - end).total_seconds() / 60.0
        if c["c"] > long_trig:
            side = "long"
        elif c["c"] < short_trig:
            side = "short"
        else:
            continue
        if waited > chop_limit:
            return _skip(day, "chop", width=round(width, 1), waited_min=round(waited, 1))
        signal = (side, c, opened)
        break
    if signal is None:
        return _skip(day, "no_break", width=round(width, 1))

    side, sig, sig_open = signal
    nxt = [c for c in after if c["t"] > sig["t"]]
    if not nxt:
        return _skip(day, "no_fill_bar", width=round(width, 1))
    fill_bar = nxt[0]
    fill = fill_bar["o"]
    fill_time = _open_eat(fill_bar)

    ticket = sizelib.build_day_ticket(cfg, side, hi, lo, None, None)
    stop = ticket["stop"]
    target = ticket["target"]
    size = ticket["size_usd"]
    reason, exit_px = walk_exit(side, stop, target, nxt, fill_time, time_stop)
    if exit_px is None:
        return _skip(day, "no_exit", width=round(width, 1))

    qty = units(size, fill)
    gross = qty * ((exit_px - fill) if side == "long" else (fill - exit_px))
    fees = taker_fees_round_trip(size, float(cfg.get("venue.taker_fee_pct", 0.09)))
    net = gross - fees
    actual_risk = abs(fill - stop) * qty
    return {
        "date": day, "taken": True, "reason": reason, "side": side,
        "width": round(width, 1), "fill": fill, "exit": exit_px,
        "stop": stop, "target": target, "size_usd": round(size, 2),
        "planned_entry": ticket["entry"], "planned_risk": ticket["risk_usd"],
        "gross": gross, "fees": fees, "net": net,
        "r": (net / actual_risk) if actual_risk else None,
        "signal_eat": sig_open.strftime("%H:%M"),
        "fill_eat": fill_time.strftime("%H:%M"),
    }


def run_backtest(candles: list[dict], cfg: OpsConfig | None = None) -> dict:
    cfg = cfg or OpsConfig()
    assert_one_minute(candles)
    by_day: dict[str, list] = {}
    for c in candles:
        opened = _open_eat(c)
        if opened.weekday() >= 5:
            continue
        by_day.setdefault(_day_key(opened), []).append(c)
    days = [replay_day(cfg, day, bars) for day, bars in sorted(by_day.items())]
    taken = [d for d in days if d["taken"]]
    skips: dict[str, int] = {}
    for d in days:
        if not d["taken"]:
            skips[d["reason"]] = skips.get(d["reason"], 0) + 1
    nets = [d["net"] for d in taken]
    rs = [d["r"] for d in taken if d["r"] is not None]
    targets = sum(1 for d in taken if d["reason"] == "target")
    stops = sum(1 for d in taken if d["reason"] == "stop")
    decisive = targets + stops
    total_net = sum(nets) if nets else 0.0
    if len(taken) < MIN_TRADES_FOR_A_CLAIM:
        verdict = "INSUFFICIENT"
    elif total_net > 0:
        verdict = "EDGE"
    else:
        verdict = "NO EDGE"
    return {
        "verdict": verdict,
        "sessions": len(days),
        "taken": len(taken),
        "targets": targets,
        "stops": stops,
        "scratches": len(taken) - decisive,
        "target_rate_decisive": (targets / decisive) if decisive else None,
        "total_net": total_net,
        "total_r": sum(rs) if rs else 0.0,
        "fees": sum(d["fees"] for d in taken),
        "skips": skips,
        "days": days,
        "min_trades": MIN_TRADES_FOR_A_CLAIM,
        "assumptions": [
            "fill is the next 1-minute open after the signal close — you tap, you do not get the close",
            "a bar that trades both stop and target is booked as a stop",
            "a gap through the stop exits at the open",
            "macro blackouts and the 10Y headwind are not applied, which flatters the result",
            "weekends are skipped; the rulebook is the US cash open, not the 24/7 tape",
            "the swing gate is not simulated here",
            f"fewer than {MIN_TRADES_FOR_A_CLAIM} taken trades is INSUFFICIENT, never an edge",
        ],
    }


def render(report: dict) -> str:
    lines = [
        "RULEBOOK BACKTEST — day trade only, 1-minute candles",
        f"VERDICT: {report['verdict']}",
        "",
    ]
    if report["verdict"] == "INSUFFICIENT":
        lines.append(
            f"  {report['taken']} taken trades. A claim needs {report['min_trades']}. "
            "This is not an edge and it is not a rejection. It is too small."
        )
    elif report["verdict"] == "NO EDGE":
        lines.append(
            f"  {report['taken']} trades, net {money(report['total_net'])}, "
            f"{report['total_r']:+.2f}R. The rules lost money on this sample."
        )
    else:
        lines.append(
            f"  {report['taken']} trades, net {money(report['total_net'])}, "
            f"{report['total_r']:+.2f}R. Positive on this sample. It is not a promise about the next one."
        )
    rate = report["target_rate_decisive"]
    rate_txt = f"{100 * rate:.0f}%" if rate is not None else "n/a"
    lines += [
        "",
        f"  sessions seen     {report['sessions']}",
        f"  taken             {report['taken']}",
        f"  target / stop     {report['targets']} / {report['stops']}   "
        f"(target rate of decisive trades {rate_txt}; the fee-toll break-even is ~38%)",
        f"  scratches         {report['scratches']}   (time stop or 23:00 flat)",
        f"  fees paid         {money(report['fees'])}",
        f"  skipped           {report['skips'] or 'none'}",
        "",
        "Assumptions — read these before the number:",
    ]
    for a in report["assumptions"]:
        lines.append(f"  - {a}")
    lines.append("")
    lines.append("Taken trades:")
    shown = [d for d in report["days"] if d["taken"]]
    if not shown:
        lines.append("  none")
    for d in shown[:40]:
        lines.append(
            f"  {d['date']} {d['side'].upper():5} fill {price(d['fill'])} -> {d['reason']:6} "
            f"{price(d['exit'])}  net {money(d['net'])}  {d['r']:+.2f}R  "
            f"width {d['width']:.0f}  signal {d['signal_eat']}"
        )
    if len(shown) > 40:
        lines.append(f"  … {len(shown) - 40} more")
    lines.append("")
    lines.append("Educational tooling only — not financial advice. This replay places no orders.")
    return "\n".join(lines)


def _demo_candles() -> list[dict]:
    """Three scripted Thursdays. Not a sample. A check that the harness books what it claims."""
    def bar(day, hh, mm, o, h, l, c):
        y, mo, d = [int(x) for x in day.split("-")]
        t = int(datetime(y, mo, d, hh, mm, tzinfo=EAT).timestamp() * 1000)
        return {"t": t, "T": t + 60_000, "o": o, "h": h, "l": l, "c": c}

    def flat_range(day, hi, lo):
        mid = (hi + lo) / 2
        return [bar(day, 16, 30 + i, mid, hi if i == 0 else mid + 1, lo if i == 0 else mid - 1, mid)
                for i in range(15)]

    out = []
    # 2026-10-08: 140-pt range, break long at 16:47, next open, then target.
    out += flat_range("2026-10-08", 31140, 31000)
    out.append(bar("2026-10-08", 16, 46, 31120, 31130, 31110, 31125))
    out.append(bar("2026-10-08", 16, 47, 31130, 31150, 31128, 31146))  # close beyond 31145
    out.append(bar("2026-10-08", 16, 48, 31150, 31160, 31148, 31155))  # fill
    out.append(bar("2026-10-08", 16, 49, 31155, 31460, 31150, 31455))  # target 31455, stop not touched
    # 2026-10-01: same range, break, then a stop.
    out += flat_range("2026-10-01", 31140, 31000)
    out.append(bar("2026-10-01", 16, 47, 31130, 31150, 31128, 31146))
    out.append(bar("2026-10-01", 16, 48, 31150, 31155, 31140, 31145))
    out.append(bar("2026-10-01", 16, 49, 31145, 31148, 30980, 30990))  # through 30990
    # 2026-10-02: 60-pt range, fee filter, must not be taken even if it "breaks".
    out += flat_range("2026-10-02", 31060, 31000)
    out.append(bar("2026-10-02", 16, 47, 31050, 31070, 31048, 31066))
    out.append(bar("2026-10-02", 16, 48, 31066, 31200, 31066, 31180))
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Replay the written day-trade rulebook. Places no orders.")
    ap.add_argument("--candles", help="JSON or {candles: [...]} file of 1-minute bars")
    ap.add_argument("--out", help="write the report here as well as stdout")
    ap.add_argument("--demo", action="store_true", help="scripted bars, to prove the harness")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    if args.demo:
        candles, meta = _demo_candles(), {"source": "demo"}
    elif args.candles:
        candles, meta = load_candles(args.candles)
    else:
        ap.error("pass --candles or --demo")
    report = run_backtest(candles)
    report["source"] = meta.get("source") or args.candles
    text = json.dumps({k: v for k, v in report.items() if k != "days"}, indent=2) if args.json else render(report)
    print(text)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        open(args.out, "w", encoding="utf-8").write(text + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
